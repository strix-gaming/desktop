Strix 0.3.21

Os jogos do catálogo podem controlar o mouse dentro da Strix e na janela separada, com a interação do usuário. A liberação é restrita aos endereços aprovados; jogos externos continuam sem acesso a microfone, câmera, captura da tela, área de transferência ou recursos nativos.

Tela cheia e a janela para outro monitor preservam a chamada na janela principal. Não há nova permissão persistente nem mudança nas preferências de áudio.

Instalador Windows x64 de teste, ainda sem assinatura digital. A instalação continua após confirmação e fora das chamadas.
