// Real Chromium gesture/iframe attribution test. All HTTPS content is intercepted locally;
// it never fetches the provider or touches a Strix account/device permission.
const electron=require('electron');const {app,BrowserWindow,session}=electron;
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {installPermissions}=require('../app/permissions.cjs');
const {approvedGameURLs}=require('../app/game-permissions.cjs');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'strix-games-electron-'));app.setPath('userData',temp);
const origin='https://strix-gaming.web.app',approved=approvedGameURLs[1],foreign=approved.replace('index.html','unapproved.html');
const deadline=setTimeout(()=>{console.error('Game iframe permission test timed out');app.exit(1);},35000);
let owner,child;
app.whenReady().then(async()=>{
 const ses=session.fromPartition('strix-game-permission-fixture-'+Date.now());
 await ses.protocol.handle('https',request=>new Response(request.url.startsWith(origin+'/')?'<html><body style="margin:0;background:#222"><div id="wrapper"></div></body></html>':'<html><body style="margin:0;background:#333;color:white">Local isolated game fixture</body></html>',{headers:{'content-type':'text/html'}}));
 owner=new BrowserWindow({show:true,width:900,height:640,webPreferences:{session:ses,sandbox:true,contextIsolation:true,nodeIntegration:false}});
 const permissions=installPermissions(electron,owner,origin);
 async function frameIn(window,url){
  await window.webContents.executeJavaScript(`new Promise(resolve=>{document.querySelector('iframe')?.remove();const frame=document.createElement('iframe');frame.src=${JSON.stringify(url)};frame.style='width:800px;height:500px;border:0';frame.allow='fullscreen';frame.sandbox='allow-scripts allow-same-origin allow-pointer-lock';frame.onload=resolve;document.getElementById('wrapper').append(frame);})`);
  window.show();window.focus();window.webContents.focus();return window.webContents.mainFrame.frames[0];
 }
 const lock=(frame,gesture)=>frame.executeJavaScript("document.body.requestPointerLock().then(()=>!!document.pointerLockElement,()=>false)",gesture);
 const fullscreen=(frame,gesture)=>frame.executeJavaScript("document.body.requestFullscreen().then(()=>!!document.fullscreenElement,()=>false)",gesture);
 const unlock=frame=>frame.executeJavaScript("new Promise(resolve=>{if(!document.pointerLockElement)return resolve();document.addEventListener('pointerlockchange',()=>resolve(),{once:true});document.exitPointerLock();})");
 await owner.loadURL(origin+'/app');let frame=await frameIn(owner,approved);
 assert.equal(await fullscreen(frame,false),false,'fullscreen must require real user activation');
 assert.equal(await lock(frame,false),false,'first pointer lock must require real user activation');
 assert.equal(await lock(frame,true),true,'approved game receives a gesture-scoped pointer lock');await unlock(frame);
 assert.equal(await frame.executeJavaScript("(async()=>{try{await navigator.mediaDevices.getUserMedia({audio:true});return 'granted';}catch{return 'denied';}})()",true),'denied');
 frame=await frameIn(owner,foreign);assert.equal(await lock(frame,true),false,'other provider documents stay denied even after a gesture');
 owner.webContents.setWindowOpenHandler(()=>({action:'allow',overrideBrowserWindowOptions:{show:true,webPreferences:{session:ses,sandbox:true,contextIsolation:true,nodeIntegration:false}}}));
 const created=new Promise(resolve=>owner.webContents.once('did-create-window',(window,details)=>{permissions.allowStreamWindow(window,details.url);resolve(window);}));
 await owner.webContents.executeJavaScript(`window.open('${origin}/stream-window.html','','popup=yes,width=900,height=640');true`,true);child=await created;
 if(child.webContents.isLoading())await new Promise(resolve=>child.webContents.once('did-finish-load',resolve));
 frame=await frameIn(child,approved);assert.equal(await lock(frame,true),true,'registered detached game window supports pointer lock');await unlock(frame);
 assert.equal(await child.webContents.executeJavaScript("document.getElementById('wrapper').requestFullscreen().then(()=>!!document.fullscreenElement,()=>false)",true),true,'same-origin detached wrapper supports fullscreen');
 await child.webContents.executeJavaScript('document.exitFullscreen()',true);
 console.log('PASS: catalogue iframe pointer lock with gesture in main and detached windows; no gesture, foreign URL and media denied; wrapper fullscreen preserved');
 child.destroy();owner.destroy();clearTimeout(deadline);fs.rmSync(temp,{recursive:true,force:true});app.exit(0);
}).catch(error=>{console.error(error);child?.destroy();owner?.destroy();clearTimeout(deadline);app.exit(1);});
