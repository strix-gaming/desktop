const electron=require('electron');
const {app,BrowserWindow,Menu,shell,dialog,desktopCapturer,systemPreferences,ipcMain,screen,globalShortcut}=electron;
const {savedWindow,installDesktopControls,installLifecycle}=require('./desktop-runtime.cjs');
const {installStartup}=require('./startup.cjs');
const {installPermissions}=require('./permissions.cjs');
const path=require('node:path');
const fs=require('node:fs');
const config=require('./runtime.json');
const base=new URL(config.origin);
if(base.protocol!=='https:')throw new Error('A Strix exige HTTPS.');
app.setName('Strix');
app.setAppUserModelId('app.strix.desktop');
if(process.env.STRIX_TEST_DATA)app.setPath('userData',process.env.STRIX_TEST_DATA);
const lock=app.requestSingleInstanceLock();if(!lock)app.quit();
let win,picker;
const authHosts=new Set(['accounts.google.com']);
const permitted=url=>{try{const u=new URL(url);return u.protocol==='https:'&&(u.origin===base.origin||authHosts.has(u.hostname));}catch{return false;}};
const isApp=url=>{try{return new URL(url).origin===base.origin;}catch{return false;}};
// This picker has no process-isolated audio source. Never grant global loopback,
// which would recapture the call. Native-picker audio is verified by the web client.
async function capture(request,callback){if(!request.frame||!isApp(request.frame.url)||!request.userGesture){callback({});return;}
 try{const sources=await desktopCapturer.getSources({types:['screen','window'],thumbnailSize:{width:360,height:220},fetchWindowIcons:true});
 if(picker&&!picker.isDestroyed()){callback({});return;}
 picker=new BrowserWindow({width:980,height:700,minWidth:680,minHeight:480,parent:win,modal:true,...(process.platform==='win32'?{titleBarStyle:'hidden',titleBarOverlay:{color:'#08090d',symbolColor:'#d4d8e4',height:36}}:{}),title:'Strix — compartilhar tela',backgroundColor:'#101118',webPreferences:{preload:path.join(__dirname,'picker-preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true}});
 let completed=false;const finish=id=>{if(completed)return;completed=true;ipcMain.removeListener('strix:choose-source',choose);const selected=isApp(win.webContents.getURL())?sources.find(s=>s.id===id):null;callback(selected?{video:selected}:{});if(picker&&!picker.isDestroyed())picker.close();};
 const choose=(event,id)=>{if(event.sender!==picker?.webContents||event.senderFrame!==picker.webContents.mainFrame)return;finish(typeof id==='string'?id:null);};ipcMain.on('strix:choose-source',choose);
 picker.webContents.on('did-finish-load',()=>picker.webContents.send('strix:sources',sources.map(s=>({id:s.id,name:s.name,kind:s.id.startsWith('screen:')?'screen':'window',thumbnail:s.thumbnail.toDataURL(),icon:s.appIcon?.toDataURL()||''}))));
 picker.on('closed',()=>{finish(null);picker=null;});await picker.loadFile('picker.html');
 }catch{callback({});}}
function createWindow(){const saved=savedWindow(app,screen);win=new BrowserWindow({...saved,minWidth:920,minHeight:620,backgroundColor:'#0c0c12',title:'Strix',...(process.platform==='win32'?{titleBarStyle:'hidden',titleBarOverlay:{color:'#08090d',symbolColor:'#d4d8e4',height:36}}:{}),icon:path.join(__dirname,'icon.png'),show:false,autoHideMenuBar:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,spellcheck:true,partition:'persist:strix'}});
 installDesktopControls(electron,win,base.origin);
 installStartup(electron,win,base.origin);
 if(saved.maximized)win.maximize();
 const ses=win.webContents.session;
 const permissions=installPermissions(electron,win,base.origin);
 ses.setDisplayMediaRequestHandler(capture,{useSystemPicker:process.platform!=='win32'});
 const guard=(event,url)=>{if(!permitted(url)){event.preventDefault();if(/^https?:\/\//.test(url))shell.openExternal(url);}};
 win.webContents.on('will-navigate',guard);win.webContents.on('will-redirect',guard);
 win.webContents.setWindowOpenHandler(({url})=>{if(permitted(url))return {action:'allow',overrideBrowserWindowOptions:{autoHideMenuBar:true,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}}};if(/^https?:\/\//.test(url))shell.openExternal(url);return {action:'deny'};});
 win.webContents.on('will-attach-webview',e=>e.preventDefault());
 win.webContents.on('did-fail-load',(_e,code,_description,_url,isMain)=>{if(isMain&&code!==-3)win.loadFile('offline.html');});
 win.once('ready-to-show',()=>{win.show();void permissions.prepare().catch(()=>{});});
 const testURL=!app.isPackaged&&process.env.STRIX_LOCAL_TEST==='1'?'http://localhost:4318/app':base.origin+'/app';
 win.loadURL(testURL).catch(()=>win.loadFile('offline.html'));
 win.on('closed',()=>win=null);
 Menu.setApplicationMenu(Menu.buildFromTemplate([...(process.platform==='darwin'?[{label:'Strix',submenu:[{role:'about'},{type:'separator'},{role:'hide'},{role:'hideOthers'},{type:'separator'},{role:'quit'}]}]:[]),{label:'Editar',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},{label:'Visualizar',submenu:[{role:'reload'},{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'},{role:'togglefullscreen'}]},{label:'Ajuda',submenu:[{label:'Site da Strix',click:()=>shell.openExternal(base.origin)},{label:'Permissões de microfone e câmera',click:()=>void permissions.review().catch(()=>{})},{label:'Reconectar',click:()=>win?.loadURL(base.origin+'/app')},{label:'Sobre esta distribuição',click:()=>dialog.showMessageBox(win,{title:'Strix '+app.getVersion(),message:'Strix Desktop',detail:'Cliente de desktop conectado ao serviço Strix. Distribuição sem assinatura de desenvolvedor. Recursos de chamada dependem da conectividade e infraestrutura. Não há atualização automática configurada.'})}]}]));
}
installLifecycle(app,globalShortcut);
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.show();win.focus();}});
if(lock)app.whenReady().then(createWindow);app.on('activate',()=>{if(!win)createWindow();});app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
