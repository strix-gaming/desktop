Strix Desktop 0.3.2 — versão de testes

- Barra escura integrada, com navegação e destino centralizado.
- Permissão de microfone e câmera lembrada entre chamadas e reinicializações; revisão disponível em Áudio e no menu Ajuda.
- Seletor de compartilhamento com miniaturas, abas e confirmação.
- Mesmas contas da web. Sons, personalizações e interface recebem as atualizações publicadas no Firebase.

Instalador sem assinatura digital e sem atualizador automático. O seletor de compartilhamento ainda não captura o áudio do jogo. Construção e testes automatizados não substituem a validação em um PC Windows real.
