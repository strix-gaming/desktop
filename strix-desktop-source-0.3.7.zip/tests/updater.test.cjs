const {test}=require('node:test');const assert=require('node:assert/strict');const {EventEmitter}=require('node:events');const {installUpdater}=require('../app/updater.cjs');
test('updates defer download during calls, require explicit restart and reject foreign IPC',async()=>{
 const ipc=new EventEmitter(),handlers=new Map();ipc.handle=(k,v)=>handlers.set(k,v);ipc.removeHandler=k=>handlers.delete(k);
 const win=new EventEmitter(),wc=new EventEmitter(),frame={url:'https://strix-gaming.web.app/app'};wc.isDestroyed=()=>false;wc.mainFrame=frame;wc.getURL=()=>frame.url;wc.send=()=>{};win.webContents=wc;win.isDestroyed=()=>false;
 const updater=new EventEmitter();let downloads=0,installs=0;updater.checkForUpdates=async()=>{};updater.downloadUpdate=async()=>{downloads++;};updater.quitAndInstall=()=>installs++;
 installUpdater({app:{isPackaged:true,getVersion:()=> '0.3.3'},ipcMain:ipc},win,'https://strix-gaming.web.app',updater);
 const event={sender:wc,senderFrame:frame};const invoke=handlers.get('strix:updater');
 ipc.emit('strix:call-state',event,{connected:true});updater.emit('update-available',{version:'0.3.4'});assert.equal(downloads,0);
 await assert.rejects(invoke({...event,senderFrame:{url:'https://bad.test'}},'install'));
 ipc.emit('strix:call-state',event,{connected:false});await new Promise(setImmediate);assert.equal(downloads,1);
 updater.emit('update-downloaded',{version:'0.3.4'});assert.equal(installs,0);assert.equal((await invoke(event,'status')).status,'ready');
 ipc.emit('strix:call-state',event,{connected:true});await assert.rejects(invoke(event,'install'));
 ipc.emit('strix:call-state',event,{connected:false});await invoke(event,'install');await new Promise(setImmediate);assert.equal(installs,1);assert.equal(updater.autoInstallOnAppQuit,false);win.emit('closed');
});
