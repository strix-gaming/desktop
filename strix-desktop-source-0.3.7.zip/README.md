# Strix para Windows

Instalador NSIS 0.3.0 para Windows x64, com Electron 44.4.5, janela própria, atalhos, sessão persistente e login na mesma conta do Firebase. A interface é carregada de https://strix-gaming.web.app e requer internet.

`npm run build:windows` gera `../strix-downloads/windows/Strix-Setup-0.3.0-Windows-x64.exe`. O `electronDist` da configuração aponta para o ZIP oficial já armazenado no cache deste workspace; em outro ambiente, remova essa opção para baixar o Electron correspondente. A criação do instalador segue a [documentação NSIS](https://www.electron.build/v26/docs/targets/nsis/).

- Sandbox e isolamento de contexto; Node desativado no conteúdo remoto.
- Instalação por usuário, diretório selecionável, atalhos no menu Iniciar e área de trabalho; dados de login preservados ao atualizar/desinstalar.
- Captura com seletor nativo quando disponível e seletor próprio como alternativa; sem loopback global que recapture a call.
- Sem assinatura Authenticode e sem atualizador automático. O Windows pode identificar o editor como desconhecido.
- Instalador e conteúdo x64 verificados estaticamente. A execução e instalação no Windows, login no executável e chamadas entre redes diferentes ainda não foram homologados.

A compilação anterior de macOS permanece somente como artefato histórico local. Não é oferecida no site.

A versão 0.3.0 acrescenta controles de microfone e fone pela bandeja, atalhos globais Ctrl+Shift+M/D somente durante chamadas, restauração do tamanho da janela e fechamento para a bandeja quando houver uma chamada ativa. O menu Sair encerra o aplicativo. A ponte entre interface e desktop valida a origem e o frame principal.

Download de testes: https://github.com/strix-gaming/desktop/releases/tag/v0.3.0

O instalador publicado foi baixado e comparado com o SHA-256 do arquivo local. Isso comprova a integridade do download, não a homologação em Windows.
