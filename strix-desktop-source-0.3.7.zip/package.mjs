import {packager} from '@electron/packager';
import fs from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=process.cwd();
const site=path.resolve('../aurora');
const output=path.resolve('../strix-downloads');await fs.mkdir(output,{recursive:true});
const configurations=[{platform:'darwin',arch:'arm64',id:'mac-arm64',file:'Strix-macOS-Apple-Silicon.zip',label:'macOS · Apple Silicon'},{platform:'win32',arch:'x64',id:'windows-x64',file:'Strix-Windows-x64.zip',label:'Windows · 64 bits'}];
const manifest=[];
for(const c of configurations){
 const built=await packager({dir:path.join(root,'app'),out:path.join(root,'build'),overwrite:true,name:'Strix',platform:c.platform,arch:c.arch,electronVersion:'44.4.5',asar:true,appBundleId:'app.strix.desktop',appCategoryType:'public.app-category.social-networking',icon:c.platform==='darwin'?path.join(root,'app/icon.icns'):undefined,download:{cacheRoot:path.resolve('../../work/electron-cache')},extendInfo:{NSMicrophoneUsageDescription:'A Strix usa o microfone quando você participa de uma chamada.',NSCameraUsageDescription:'A Strix usa a câmera quando você ativa o vídeo em uma chamada.',NSAudioCaptureUsageDescription:'A Strix captura áudio quando você compartilha a tela com som.'}});
 const folder=built[0];const archive=path.join(output,c.file);await fs.rm(archive,{force:true});
 const localeDirs=c.platform==='darwin'?[path.join(folder,'Strix.app/Contents/Resources'),path.join(folder,'Strix.app/Contents/Frameworks/Electron Framework.framework/Versions/A/Resources')]:[path.join(folder,'locales')];
 for(const dir of localeDirs)for(const name of await fs.readdir(dir)){const language=name.replace(/\.(lproj|pak)$/,'');if((name.endsWith('.lproj')||(c.platform==='win32'&&name.endsWith('.pak')))&&!['en','en_US','en-US','pt','pt_BR','pt-BR','Base'].includes(language))await fs.rm(path.join(dir,name),{recursive:true});}
 if(c.platform==='darwin'){const temp=await fs.mkdtemp('/private/tmp/strix-package-');const clean=path.join(temp,'Strix.app');await fs.cp(path.join(folder,'Strix.app'),clean,{recursive:true,verbatimSymlinks:true});execFileSync('codesign',['--force','--deep','--sign','-',clean]);execFileSync('codesign',['--verify','--deep','--strict',clean]);execFileSync('ditto',['-c','-k','--keepParent',clean,archive]);await fs.rm(temp,{recursive:true});}else execFileSync('zip',['-qr',archive,'.'],{cwd:folder});
 const bytes=await fs.readFile(archive);const hash=createHash('sha256').update(bytes).digest('hex');const parts=[];const chunkSize=20*1024*1024;const releaseDir=path.join(site,'public/releases',c.id);await fs.rm(releaseDir,{recursive:true,force:true});await fs.mkdir(releaseDir,{recursive:true});for(let start=0,i=0;start<bytes.length;start+=chunkSize,i++){const part=bytes.subarray(start,start+chunkSize),name=`part-${String(i).padStart(3,'0')}.bin`;await fs.writeFile(path.join(releaseDir,name),part);parts.push({url:`/releases/${c.id}/${name}`,size:part.length,sha256:createHash('sha256').update(part).digest('hex')});}
 manifest.push({id:c.id,label:c.label,filename:c.file,version:'0.1.0',size:bytes.length,sha256:hash,signed:false,parts});console.log(JSON.stringify({platform:c.platform,path:archive,bytes:bytes.length,sha256:hash}));
}
await fs.writeFile(path.join(site,'public/releases/manifest.json'),JSON.stringify(manifest,null,2));await fs.writeFile(path.join(output,'SHA256SUMS.txt'),manifest.map(r=>r.sha256+'  '+r.filename).join('\n')+'\n');
