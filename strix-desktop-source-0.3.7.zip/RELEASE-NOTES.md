Atividade opcional de jogos compatíveis e músicas do aplicativo Spotify no Windows. Não exige Spotify Premium nem vinculação de conta. Desativada por padrão; controles em Conexões e atividade, com visibilidade somente para amigos ou pessoas na Strix. Invisível oculta a atividade. A música depende das informações de mídia fornecidas pelo Spotify ao Windows.

Inclui as correções anteriores de captura de áudio, cancelamento da seleção de tela e tela cheia nativa.
