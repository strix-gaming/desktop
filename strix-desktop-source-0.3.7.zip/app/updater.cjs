const {trustedFrame}=require('./desktop-controls.cjs');
function installUpdater(electron,win,origin,updater){
 const {app,ipcMain}=electron;
 let state={status:'idle',version:app.getVersion(),progress:0},connected=false,checking=false,downloading=false;
 const send=patch=>{state={...state,...patch};if(!win.isDestroyed()&&win.webContents.getURL().startsWith(origin+'/'))win.webContents.send('strix:update-state',state);};
 updater.autoDownload=false;updater.autoInstallOnAppQuit=false;updater.allowPrerelease=true;updater.allowDowngrade=false;
 const download=async()=>{if(connected||downloading||state.status!=='available')return;downloading=true;send({status:'downloading'});try{await updater.downloadUpdate();}catch{send({status:'error',message:'Não foi possível baixar a atualização. Tente novamente.'});}finally{downloading=false;}};
 const check=async()=>{if(checking||downloading||state.status==='ready'||!app.isPackaged)return state;checking=true;send({status:'checking',message:''});try{await updater.checkForUpdates();}catch{send({status:'error',message:'Não foi possível consultar atualizações.'});}finally{checking=false;}return state;};
 const listeners={
  'update-available':info=>{send({status:'available',version:info.version});void download();},
  'update-not-available':()=>send({status:'current',version:app.getVersion()}),
  'download-progress':info=>send({status:'downloading',progress:Math.round(info.percent)}),
  'update-downloaded':info=>send({status:'ready',version:info.version,progress:100}),
  'error':()=>send({status:'error',message:'Atualização indisponível no momento. Sua Strix continua funcionando.'})
 };
 for(const [event,listener]of Object.entries(listeners))updater.on(event,listener);
 const call=(event,value)=>{if(!trustedFrame(event,win.webContents,origin))return;connected=value?.connected===true;if(!connected)void download();};
 ipcMain.on('strix:call-state',call);
 ipcMain.handle('strix:updater',async(event,action)=>{
  if(!trustedFrame(event,win.webContents,origin))throw Error('Origem não autorizada.');
  if(action==='check')return check();
  if(action==='install'){
   if(connected)throw Error('Saia da chamada antes de reiniciar para atualizar.');
   if(state.status!=='ready')throw Error('A atualização ainda não está pronta.');
   setImmediate(()=>updater.quitAndInstall(false,true));
  }
  return state;
 });
 const first=setTimeout(()=>{if(!connected)void check();},30000),repeat=setInterval(()=>{if(!connected)void check();},4*60*60*1000);first.unref?.();repeat.unref?.();
 win.on('closed',()=>{clearTimeout(first);clearInterval(repeat);ipcMain.removeHandler('strix:updater');ipcMain.removeListener('strix:call-state',call);for(const [event,listener]of Object.entries(listeners))updater.removeListener(event,listener);});
 return {check};
}
module.exports={installUpdater};
