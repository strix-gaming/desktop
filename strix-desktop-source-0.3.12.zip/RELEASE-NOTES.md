# Strix Desktop 0.3.12

- Biblioteca: reconhece capas com nomes atuais do cache Steam e busca arte oficial ausente, com cache local e limite de tempo em redes indisponiveis.
- Atualizador: corrige acesso a janela destruida no encerramento e trata eventos tardios do download.
- Recuperacao da janela: evita promessas rejeitadas durante fechamento e carregamento offline.
- Mantem deteccao de jogos e aplicativos, permissoes de captura e instalacao fora de chamadas.

Validacao local: 54 testes passaram, incluindo regressao do encerramento e capas. A pipeline Windows executa as verificacoes nativas e gera instalador, blockmap e feed.
