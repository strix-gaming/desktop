Strix Desktop 0.3.16

A biblioteca aparece sem aguardar capas ou ícones. Arte local é carregada sob demanda e a interface mostra uma prévia leve enquanto o banner HD chega.

Jogos Steam abertos, inclusive fora da Strix, são identificados pelos executáveis dentro da instalação detectada. O botão Fechar solicita o encerramento da janela sem forçar o processo; confirmações de salvamento permanecem no jogo.

Publicação de teste sem assinatura. Requer validação física em um computador Windows.
