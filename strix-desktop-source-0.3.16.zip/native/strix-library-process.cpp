// Local library status only. The renderer never receives paths, PIDs or window titles.
#include <windows.h>
#include <tlhelp32.h>
#include <winrt/Windows.Data.Json.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <cwctype>
#include <unordered_set>
using namespace winrt;
using namespace Windows::Data::Json;
std::wstring lower(std::wstring s){std::transform(s.begin(),s.end(),s.begin(),::towlower);return s;}
std::wstring stamp(FILETIME t){ULARGE_INTEGER n{};n.HighPart=t.dwHighDateTime;n.LowPart=t.dwLowDateTime;return std::to_wstring(n.QuadPart);}
bool identity(HANDLE p,std::wstring& file,std::wstring& started){wchar_t buffer[32768];DWORD size=32768;FILETIME c,e,k,u;if(!QueryFullProcessImageNameW(p,0,buffer,&size)||!GetProcessTimes(p,&c,&e,&k,&u))return false;file.assign(buffer,size);started=stamp(c);return true;}
struct Windows{DWORD pid;bool close=false;int count=0;};
BOOL CALLBACK visit(HWND window,LPARAM data){auto& state=*reinterpret_cast<Windows*>(data);DWORD pid=0;GetWindowThreadProcessId(window,&pid);if(pid==state.pid&&IsWindowVisible(window)&&GetWindow(window,GW_OWNER)==nullptr){if(!state.close||PostMessageW(window,WM_CLOSE,0,0))state.count++;}return TRUE;}
BOOL CALLBACK collect(HWND window,LPARAM data){if(IsWindowVisible(window)&&GetWindow(window,GW_OWNER)==nullptr){DWORD pid=0;GetWindowThreadProcessId(window,&pid);reinterpret_cast<std::unordered_set<DWORD>*>(data)->insert(pid);}return TRUE;}
int wmain(int argc,wchar_t** argv){try{
 init_apartment(apartment_type::multi_threaded);
 DWORD session=0;ProcessIdToSessionId(GetCurrentProcessId(),&session);
 if(argc==5&&std::wstring(argv[1])==L"--close"){
  std::wstring raw=argv[2];if(raw.empty()||raw.find_first_not_of(L"0123456789")!=std::wstring::npos)return 2;
  auto number=std::stoull(raw);if(number==0||number>MAXDWORD)return 2;DWORD pid=static_cast<DWORD>(number),targetSession=0;
  bool ok=false;HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid);
  if(process){std::wstring file,started;if(ProcessIdToSessionId(pid,&targetSession)&&targetSession==session&&identity(process,file,started)&&lower(file)==lower(argv[3])&&started==argv[4]&&WaitForSingleObject(process,0)==WAIT_TIMEOUT){Windows windows{pid,true,0};EnumWindows(visit,reinterpret_cast<LPARAM>(&windows));ok=windows.count>0;}CloseHandle(process);}
  std::cout<<(ok?"{\"ok\":true}":"{\"ok\":false}");return 0;
 }
 if(argc!=2||std::wstring(argv[1])!=L"--list")return 2;
 std::unordered_set<DWORD> windows;EnumWindows(collect,reinterpret_cast<LPARAM>(&windows));
 JsonArray output;HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snapshot==INVALID_HANDLE_VALUE)return 3;
 PROCESSENTRY32W entry{};entry.dwSize=sizeof(entry);
 if(Process32FirstW(snapshot,&entry))do{
  DWORD targetSession=0;if(output.Size()>=1024)break;if(!ProcessIdToSessionId(entry.th32ProcessID,&targetSession)||targetSession!=session)continue;
  HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,entry.th32ProcessID);if(!process)continue;
  std::wstring file,started;if(identity(process,file,started)){JsonObject item;item.Insert(L"pid",JsonValue::CreateNumberValue(entry.th32ProcessID));item.Insert(L"path",JsonValue::CreateStringValue(file));item.Insert(L"started",JsonValue::CreateStringValue(started));item.Insert(L"windowed",JsonValue::CreateBooleanValue(windows.count(entry.th32ProcessID)>0));output.Append(item);}CloseHandle(process);
 }while(Process32NextW(snapshot,&entry));
 CloseHandle(snapshot);std::cout<<to_string(output.Stringify());return 0;
 }catch(...){return 4;}}
