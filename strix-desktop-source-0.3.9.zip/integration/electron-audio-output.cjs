const electron=require('electron'),{app,BrowserWindow}=electron;
const {installPermissions}=require('../app/permissions.cjs');
const http=require('node:http'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const data=fs.mkdtempSync(path.join(os.tmpdir(),'strix-output-integration-'));app.setPath('userData',data);
const deadline=setTimeout(()=>{console.error('Audio output test timed out');app.exit(1);},25000);
app.whenReady().then(async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><body>Strix audio output</body></html>');});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
 const owner=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true}});
 const permissions=installPermissions({...electron,dialog:{showMessageBox:async()=>({response:1})}},owner,origin,'win32');
 await owner.loadURL(origin+'/app');
 const query=()=>owner.webContents.executeJavaScript("navigator.permissions.query({name:'speaker-selection'}).then(p=>p.state)");
 assert.equal(await query(),'denied');await permissions.prepare();assert.equal(await query(),'granted');
 const playback=await owner.webContents.executeJavaScript("(async()=>{const audio=document.createElement('audio');await audio.setSinkId('');return audio.sinkId;})()");assert.equal(playback,'');
 console.log('PASS: real Electron speaker-selection follows existing media consent and default output is selectable');
 owner.destroy();server.close();clearTimeout(deadline);app.exit(0);
}).catch(error=>{console.error(error);app.exit(1);});
