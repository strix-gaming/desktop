# Strix Desktop 0.3.9

- Corrige a seleção da saída de áudio no aplicativo Windows: a janela principal da Strix pode selecionar o fone ou alto-falante após o consentimento de mídia já concedido.
- Janelas destacadas, subframes, origens externas e sessões sem consentimento continuam sem essa permissão.
- Mantém os atalhos globais opcionais e o adiamento de atualização durante chamadas da versão 0.3.8.

Instalador de testes para Windows x64; sem assinatura Authenticode.
