const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {installGameAudio}=require('../app/game-audio-script.cjs');
const {prepareGameAudioExtension,installGameAudioExtension}=require('../app/game-audio.cjs');
const origin='https://strix-gaming.web.app',game='https://www.onlinegames.io/games/2024/unity/drift-king/index.html';
function fixture({url=game,parentOrigin=origin,topLevel=false}={}){
 const media=[],masters=[],listeners={},reports=[];
 class Param{constructor(){this.value=1;}cancelScheduledValues(){}setValueAtTime(value){this.value=value;}}
 class AudioNode{constructor(context){this.context=context;this.edges=[];}connect(node){this.edges.push(node);return node;}disconnect(node){this.edges=this.edges.filter(edge=>edge!==node);}}
 class BaseAudioContext{constructor(){this.destination=new AudioNode(this);this.currentTime=0;this.state='suspended';}createGain(){const gain=new AudioNode(this);gain.gain=new Param();masters.push(gain);return gain;}addEventListener(){} }
 class AudioContext extends BaseAudioContext{createMediaElementSource(){return new AudioNode(this);}}
 class HTMLMediaElement{constructor(){this.actual=1;this.isConnected=true;this.paused=true;media.push(this);}get volume(){return this.actual;}set volume(value){this.actual=value;}play(){this.playedAt=this.actual;this.paused=false;return Promise.resolve();}}
 class Audio extends HTMLMediaElement{}
 class Document{constructor(){this.referrer=origin+'/app';}createElement(name){return /^(audio|video)$/.test(name)?new HTMLMediaElement():{};}createElementNS(ns,name){return this.createElement(name);}querySelectorAll(){return [];}addEventListener(){} }
 const parent={postMessage:(value,target)=>reports.push({value,target})},document=new Document();
 const window={parent,top:topLevel?null:parent,AudioNode,BaseAudioContext,AudioContext,HTMLMediaElement,Audio,addEventListener:(type,fn)=>listeners[type]=fn};if(topLevel)window.top=window;
 const context=vm.createContext({window,location:{href:url,ancestorOrigins:[parentOrigin]},document,Document,AudioNode,BaseAudioContext,AudioContext,HTMLMediaElement,Audio,MutationObserver:class{observe(){}},URL,DOMException});
 vm.runInContext('('+installGameAudio.toString()+')('+JSON.stringify({appOrigin:origin,documents:[game]})+')',context);
 return {window,document,masters,media,reports,AudioNode,AudioContext,HTMLMediaElement,send(data,source=parent,eventOrigin=origin,isTrusted=true){listeners.message?.({data,source,origin:eventOrigin,isTrusted});}};
}
test('first WebAudio connection receives 15%, keeps native destination return and disconnect semantics',()=>{
 const f=fixture(),ctx=new f.AudioContext(),source=new f.AudioNode(ctx);
 assert.equal(source.connect(ctx.destination),ctx.destination);
 assert.equal(f.masters.length,1);assert.equal(f.masters[0].gain.value,.15);
 assert.equal(source.edges[0],f.masters[0]);assert.equal(f.masters[0].edges[0],ctx.destination);
 source.disconnect(ctx.destination);assert.equal(source.edges.length,0);
 source.connect(ctx.destination);assert.equal(f.masters.length,1);
 f.send({type:'strix-game-audio:set',volume:.4,muted:false});assert.equal(f.masters[0].gain.value,.4);
 f.send({type:'strix-game-audio:set',volume:.4,muted:true});assert.equal(f.masters[0].gain.value,0);
});
test('HTMLMedia starts low, preserves game volume and avoids double attenuation through WebAudio',async()=>{
 const f=fixture(),audio=new f.window.Audio();assert.equal(audio.actual,.15);assert.equal(audio.volume,1);
 audio.volume=.8;assert.ok(Math.abs(audio.actual-.12)<1e-9);await audio.play();assert.ok(Math.abs(audio.playedAt-.12)<1e-9);
 const video=f.document.createElement('video');assert.equal(video.actual,.15);
 f.send({type:'strix-game-audio:set',volume:.4,muted:false});assert.ok(Math.abs(audio.actual-.32)<1e-9);
 const ctx=new f.AudioContext(),source=ctx.createMediaElementSource(audio);source.connect(ctx.destination);
 assert.equal(audio.actual,.8);assert.equal(f.masters[0].gain.value,.4);
 assert.throws(()=>{audio.volume=3;},{name:'IndexSizeError'});
});
test('only matching child game documents are modified; Strix and unrelated frames stay untouched',()=>{
 for(const config of [{topLevel:true},{url:'https://strix-gaming.web.app/app'},{url:game+'?arbitrary=1'},{url:game.replace('index.html','other.html')},{parentOrigin:'https://evil.example'}]){
  const f=fixture(config),ctx=new f.AudioContext(),source=new f.AudioNode(ctx);source.connect(ctx.destination);
  assert.equal(f.masters.length,0);assert.equal(source.edges[0],ctx.destination);assert.equal(new f.window.Audio().actual,1);assert.equal(f.reports.length,0);
 }
});
test('forged senders, origins and malformed volumes cannot change game audio',()=>{
 const f=fixture(),ctx=new f.AudioContext();new f.AudioNode(ctx).connect(ctx.destination);
 f.send({type:'strix-game-audio:set',volume:1,muted:false},{},origin);
 f.send({type:'strix-game-audio:set',volume:1,muted:false},f.window.parent,'https://evil.example');
 f.send({type:'strix-game-audio:set',volume:1,muted:false},f.window.parent,origin,false);
 for(const volume of [NaN,Infinity,-1,2,'1',null])f.send({type:'strix-game-audio:set',volume,muted:false});
 f.send({type:'strix-game-audio:set',volume:1,muted:'false'});
 assert.equal(f.masters[0].gain.value,.15);
 f.send({type:'strix-game-audio:get'});assert.deepEqual(JSON.parse(JSON.stringify(f.reports.at(-1))),{value:{type:'strix-game-audio:ready',version:1,volume:.15,muted:false},target:origin});
});
test('bundled manifest has only exact catalogue matches and no privileged extension permissions',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-audio-manifest-'));
 try{
  const result=prepareGameAudioExtension(dir,origin,[game,game]);assert.equal(result.count,1);
  const manifest=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
  assert.equal(manifest.manifest_version,3);assert.equal(manifest.permissions,undefined);assert.equal(manifest.host_permissions,undefined);
  assert.deepEqual(manifest.content_scripts,[{matches:[game],js:['game-audio.js'],run_at:'document_start',world:'MAIN',all_frames:true}]);
  assert.throws(()=>prepareGameAudioExtension(dir,origin,['https://www.onlinegames.io/games/*']));
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('native capability only becomes true after the extension load succeeds',async()=>{
 let resolve,loads=0;const session={extensions:{loadExtension(){loads++;return new Promise(done=>resolve=done);}}};
 const pending=installGameAudioExtension(session,'/approved/extension');assert.equal(loads,1);resolve({id:'test'});assert.equal(await pending,true);
 assert.equal(await installGameAudioExtension(session,'/approved/extension'),true);assert.equal(loads,1);
 assert.equal(await installGameAudioExtension({},'/approved/extension'),false);
});
