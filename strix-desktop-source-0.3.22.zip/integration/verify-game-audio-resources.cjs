// Packaging check: Chromium cannot load an unpacked extension from inside ASAR.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const source=path.resolve(__dirname,'../app/game-audio-extension');
const packaged=path.resolve(__dirname,'../release/win-unpacked/resources/game-audio-extension');
for(const name of ['manifest.json','game-audio.js']){
 const output=path.join(packaged,name);
 assert.ok(fs.existsSync(output),`Missing unpacked game audio resource: ${name}`);
 assert.deepEqual(fs.readFileSync(output),fs.readFileSync(path.join(source,name)),`Packaged ${name} must match validated source`);
}
console.log('PASS: verified exact game audio extension resources outside ASAR.');
