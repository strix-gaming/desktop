Strix 0.3.22

Os jogos do catálogo podem controlar o mouse dentro da Strix e na janela separada, com a interação do usuário. A liberação é restrita aos endereços aprovados; jogos externos continuam sem acesso a microfone, câmera, captura da tela, área de transferência ou recursos nativos.

O áudio dos jogos aprovados começa em 15%, com volume e silenciar independentes. Uma extensão interna, restrita aos documentos do catálogo dentro da Strix, ajusta Web Audio e elementos de mídia antes da inicialização do jogo. O áudio da chamada e o volume do sistema são preservados.

Tela cheia e a janela para outro monitor preservam a chamada na janela principal. Não há nova permissão persistente para o provedor dos jogos.

Instalador Windows x64 de teste, ainda sem assinatura digital. A instalação continua após confirmação e fora das chamadas.
