# Strix Desktop 0.3.22 — Windows x64

Shell Electron da Strix. A interface é carregada de https://strix-gaming.web.app.

## Compilar no Windows

Requisitos: Node.js 24, Visual Studio Build Tools com C++/Windows SDK e PowerShell.

```powershell
npm ci --no-audit --no-fund
npm ci --prefix app --omit=dev --no-audit --no-fund
node --test tests/*.cjs
./native/build.ps1
node integration/native-activity.cjs
npx electron integration/electron-capture.cjs
npx electron integration/electron-fullscreen.cjs
npx electron integration/electron-game-permissions.cjs
npx electron integration/electron-game-audio.cjs
npm run build:windows -- --publish never
```

O instalador NSIS e os metadados de atualização são gerados em `release/`. As dependências ficam fixadas nos dois lockfiles. O Electron é baixado oficialmente pelo builder; não há dependência de cache ou caminho local.

O workflow GitHub Actions compila, verifica e publica um prerelease após disparo manual. O atualizador dos aplicativos existentes aceita prereleases. Executar esse workflow publica uma atualização real; o comando de build local acima não publica.

Instalação por usuário sem elevação. O executável não tem assinatura Authenticode. Build e testes automatizados não substituem instalação/upgrade e teste de call em Windows físico.

## Biblioteca local de jogos e aplicativos

A biblioteca descobre jogos instalados do Steam a partir dos manifests locais, incluindo as bibliotecas adicionais cadastradas no próprio Steam. No Windows, também lê atalhos de executáveis nos Menus Iniciar do usuário e do sistema. No macOS, lê bundles `.app` em `/Applications` e `~/Applications`, com até dois níveis de subpastas. Não varre o disco inteiro, não segue pastas vinculadas para fora dessas raízes e não procura executáveis arbitrários. Linux retorna `supported: false`. Aplicativos da Microsoft Store sem atalho de executável, outros launchers e pastas diferentes dessas não estão cobertos nesta versão.

Os ícones vêm do sistema; as capas do Steam usam somente o cache local disponível. Não há download de capas, telemetria da biblioteca ou envio dessa lista a um servidor pelo módulo nativo. Ausência de uma imagem é um resultado válido. Cada descoberta fica limitada a 256 itens, ícones de 64 px, capas de 240 px e até 8 MiB agregados em imagens retornadas.

Contrato da ponte isolada:

```ts
getLibrary(options?: { refresh?: boolean }): Promise<{
  supported: boolean;
  items: Array<{
    id: string;
    name: string;
    kind: 'game' | 'app';
    source: string;
    icon?: string; // data URL de imagem local
    cover?: string;
  }>;
  scannedAt: number;
}>;
launchLibraryItem(id: string): Promise<{ ok: boolean; error?: string }>;
```

A descoberta começa quando a interface solicita a biblioteca, usa cache de 60 segundos e compartilha uma única varredura entre solicitações simultâneas. `refresh: true` permite atualização manual com intervalo mínimo de dois segundos. As imagens permanecem apenas no cache em memória da janela.

A interface recebe identificadores opacos, nunca caminhos ou argumentos de execução. O processo principal mantém uma lista permitida e confere novamente a origem da janela e a existência/identidade do item antes de abrir. Atalhos modificados desde a descoberta são rejeitados. Abrir exige chamar explicitamente `launchLibraryItem`; descobrir ou atualizar a biblioteca nunca inicia jogos. Os testes usam pastas temporárias e lançadores simulados, sem abrir aplicativos reais.

Essas APIs fazem parte da distribuição desktop 0.3.12. Versões anteriores precisam instalar a atualização nativa; recarregar a interface web não adiciona a ponte. Detecção e abertura em um Windows físico ainda precisam de validação na distribuição correspondente.


## Jogos incorporados e permissões

`app/game-permissions.cjs` lista documentos HTTPS exatos do catálogo hospedado, sem curingas de domínio, parâmetros de URL ou IPC vindo do jogo. Só `pointerLock` e `fullscreen` são elegíveis, em subframes conhecidos da janela principal Strix ou da janela registrada `/stream-window.html`. Navegar a janela ou fechar o popout revoga a elegibilidade. Câmera, microfone, captura, clipboard e keyboardLock continuam negados aos jogos. Não se grava concessão para o provedor.

O Electron 44.4.5 expõe `requestingUrl` e `isMainFrame` em PermissionRequest, não `userGesture`. O gate real de ativação do Chromium é preservado; `automatic-fullscreen` não é permitido. O teste `integration/electron-game-permissions.cjs` verifica isso com documentos interceptados localmente em uma sessão isolada (nenhum jogo externo ou conta real é acessado).

A interface hospedada pode abrir a janela e o fullscreen do wrapper em 0.3.20; pointer lock do iframe depende da atualização nativa 0.3.22. Novos documentos do catálogo que precisem dessa permissão exigem revisão da allowlist nativa. O guard de navegação legado continua bloqueando redirects externos; jogos que mudarem seu documento precisam revisão explícita, não liberação geral de origens.

## Áudio independente do catálogo

A extensão interna em `game-audio-extension` é carregada antes da janela inicial e fica em `extraResources`, fora do ASAR. Seu content script MAIN/document_start aplica ganho inicial de 15% apenas nos documentos HTTPS exatos do catálogo que tenham a Strix como origem pai. Não recebe permissões de Electron, Node ou IPC. A interface só usa o controle após receber confirmação do iframe correto. O volume da chamada e do sistema não muda. Anúncios em subframes de outros documentos não são interceptados.

`integration/electron-game-audio.cjs` é obrigatório no CI, junto dos testes de permissões e das validações existentes, antes de empacotar e publicar.
