// Serialized into a bundled, document_start MAIN-world content script. No Electron,
// Node, IPC, network, filesystem, recording or call APIs are exposed to game pages.
function installGameAudio(config) {
  if (window.top === window) return;
  let current;
  try {
    current = new URL(location.href);
    if (current.search || current.username || current.password) return;
    current.hash = '';
    if (!config.documents.includes(current.href)) return;
    const parentOrigin = location.ancestorOrigins?.[0] || new URL(document.referrer).origin;
    if (parentOrigin !== config.appOrigin) return;
  } catch { return; }

  let volume = .15, muted = false;
  const masters = new WeakMap(), liveMasters = new Set();
  const requestedVolumes = new WeakMap(), trackedMedia = new Set(), routedMedia = new WeakSet();
  const mediaPrototype = window.HTMLMediaElement?.prototype;
  const volumeDescriptor = mediaPrototype && Object.getOwnPropertyDescriptor(mediaPrototype, 'volume');
  const nodePrototype = window.AudioNode?.prototype;
  const originalConnect = nodePrototype?.connect, originalDisconnect = nodePrototype?.disconnect;
  const createGain = window.BaseAudioContext?.prototype.createGain;
  const outputGain = () => muted ? 0 : volume;

  function applyMedia(media) {
    if (!volumeDescriptor || !(media instanceof HTMLMediaElement)) return;
    if (!requestedVolumes.has(media)) requestedVolumes.set(media, volumeDescriptor.get.call(media));
    trackedMedia.add(media);
    // Media routed through Web Audio is attenuated by its context's master only.
    volumeDescriptor.set.call(media, requestedVolumes.get(media) * (routedMedia.has(media) ? 1 : outputGain()));
  }
  function masterFor(context) {
    let master = masters.get(context);
    if (master) return master;
    master = createGain.call(context);
    master.gain.value = outputGain();
    originalConnect.call(master, context.destination);
    masters.set(context, master);
    liveMasters.add(master);
    context.addEventListener('statechange', () => {
      if (context.state === 'closed') liveMasters.delete(master);
    });
    return master;
  }
  function isLiveDestination(node, destination) {
    return node.context && typeof node.context.startRendering !== 'function' && destination === node.context.destination;
  }
  if (originalConnect && originalDisconnect && createGain) {
    nodePrototype.connect = function (...args) {
      if (isLiveDestination(this, args[0])) {
        const requestedDestination = args[0];
        args[0] = masterFor(this.context);
        originalConnect.apply(this, args);
        return requestedDestination;
      }
      return originalConnect.apply(this, args);
    };
    nodePrototype.disconnect = function (...args) {
      if (isLiveDestination(this, args[0]) && masters.has(this.context)) args[0] = masters.get(this.context);
      return originalDisconnect.apply(this, args);
    };
  }
  if (volumeDescriptor?.get && volumeDescriptor?.set) {
    Object.defineProperty(mediaPrototype, 'volume', {
      ...volumeDescriptor,
      get() { return requestedVolumes.has(this) ? requestedVolumes.get(this) : volumeDescriptor.get.call(this); },
      set(value) {
        const numeric = Number(value);
        if (!Number.isFinite(numeric) || numeric < 0 || numeric > 1) throw new DOMException('Volume must be between 0 and 1.', 'IndexSizeError');
        requestedVolumes.set(this, numeric);
        applyMedia(this);
      },
    });
    const play = mediaPrototype.play;
    mediaPrototype.play = function (...args) { applyMedia(this); return play.apply(this, args); };
    const createElement = Document.prototype.createElement, createElementNS = Document.prototype.createElementNS;
    Document.prototype.createElement = function (...args) { const element = createElement.apply(this, args); applyMedia(element); return element; };
    Document.prototype.createElementNS = function (...args) { const element = createElementNS.apply(this, args); applyMedia(element); return element; };
    const NativeAudio = window.Audio;
    if (NativeAudio) window.Audio = new Proxy(NativeAudio, {
      construct(target, args, newTarget) { const media = Reflect.construct(target, args, newTarget); applyMedia(media); return media; },
      apply(target, receiver, args) { const media = Reflect.construct(target, args); applyMedia(media); return media; },
    });
    function inspectTree(node) {
      applyMedia(node);
      node.querySelectorAll?.('audio,video').forEach(applyMedia);
    }
    new MutationObserver(records => {
      for (const record of records) for (const node of record.addedNodes) inspectTree(node);
    }).observe(document, {childList:true, subtree:true});
    document.addEventListener('play', event => applyMedia(event.target), true);
    inspectTree(document);
    const audioContextPrototype = window.AudioContext?.prototype;
    const createMediaSource = audioContextPrototype?.createMediaElementSource;
    if (createMediaSource) audioContextPrototype.createMediaElementSource = function (media) {
      const source = createMediaSource.call(this, media);
      routedMedia.add(media);
      applyMedia(media);
      return source;
    };
  }
  function applyVolume() {
    for (const master of liveMasters) {
      if (master.context.state === 'closed') { liveMasters.delete(master); continue; }
      master.gain.cancelScheduledValues(master.context.currentTime);
      master.gain.setValueAtTime(outputGain(), master.context.currentTime);
    }
    for (const media of trackedMedia) {
      if (!media.isConnected && media.paused && !media.src && !media.srcObject) trackedMedia.delete(media);
      else applyMedia(media);
    }
  }
  const report = () => window.parent.postMessage({type:'strix-game-audio:ready', version:1, volume, muted}, config.appOrigin);
  window.addEventListener('message', event => {
    if (!event.isTrusted || event.source !== window.parent || event.origin !== config.appOrigin) return;
    const data = event.data;
    if (!data || typeof data !== 'object') return;
    if (data.type === 'strix-game-audio:get') { report(); return; }
    if (data.type !== 'strix-game-audio:set' || typeof data.volume !== 'number' || !Number.isFinite(data.volume) || data.volume < 0 || data.volume > 1 || typeof data.muted !== 'boolean') return;
    volume = data.volume; muted = data.muted;
    applyVolume(); report();
  });
  report();
}
module.exports = {installGameAudio};
