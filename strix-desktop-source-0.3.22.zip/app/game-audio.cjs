const fs = require('node:fs');
const path = require('node:path');
const {installGameAudio} = require('./game-audio-script.cjs');
const {approvedGameURLs} = require('./game-permissions.cjs');

function prepareGameAudioExtension(directory, appOrigin, documents = approvedGameURLs) {
  const origin = new URL(appOrigin);
  if (origin.protocol !== 'https:' && !(origin.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(origin.hostname))) throw Error('Invalid Strix origin');
  const urls = [...new Set(documents)].map(value => {
    const url = new URL(value);
    if (url.protocol !== 'https:' || !['www.onlinegames.io', 'cloud.onlinegames.io'].includes(url.hostname) || !url.pathname.startsWith('/games/') || url.search || url.hash || url.username || url.password || value.includes('*')) throw Error('Unapproved game document');
    return url.href;
  });
  if (!urls.length) throw Error('The game audio extension needs an explicit catalogue');
  const manifest = {
    manifest_version:3,
    name:'Strix · áudio dos jogos',
    version:'1.0.0',
    description:'Volume independente apenas nos jogos do catálogo Strix.',
    minimum_chrome_version:'111',
    content_scripts:[{matches:urls, js:['game-audio.js'], run_at:'document_start', world:'MAIN', all_frames:true}],
  };
  fs.mkdirSync(directory, {recursive:true});
  fs.writeFileSync(path.join(directory, 'manifest.json'), JSON.stringify(manifest, null, 2)+'\n');
  fs.writeFileSync(path.join(directory, 'game-audio.js'), '('+installGameAudio.toString()+')('+JSON.stringify({appOrigin:origin.origin, documents:urls})+');\n');
  return {count:urls.length, directory};
}

const installed = new WeakMap();
function installGameAudioExtension(session, directory) {
  if (!session.extensions?.loadExtension) return Promise.resolve(false);
  if (!installed.has(session)) installed.set(session, session.extensions.loadExtension(directory, {allowFileAccess:false}).then(() => true).catch(error => { console.error('Strix game audio extension failed:', error.message); return false; }));
  return installed.get(session);
}
module.exports = {prepareGameAudioExtension, installGameAudioExtension};
