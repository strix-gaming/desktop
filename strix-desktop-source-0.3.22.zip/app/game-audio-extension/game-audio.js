(function installGameAudio(config) {
  if (window.top === window) return;
  let current;
  try {
    current = new URL(location.href);
    if (current.search || current.username || current.password) return;
    current.hash = '';
    if (!config.documents.includes(current.href)) return;
    const parentOrigin = location.ancestorOrigins?.[0] || new URL(document.referrer).origin;
    if (parentOrigin !== config.appOrigin) return;
  } catch { return; }

  let volume = .15, muted = false;
  const masters = new WeakMap(), liveMasters = new Set();
  const requestedVolumes = new WeakMap(), trackedMedia = new Set(), routedMedia = new WeakSet();
  const mediaPrototype = window.HTMLMediaElement?.prototype;
  const volumeDescriptor = mediaPrototype && Object.getOwnPropertyDescriptor(mediaPrototype, 'volume');
  const nodePrototype = window.AudioNode?.prototype;
  const originalConnect = nodePrototype?.connect, originalDisconnect = nodePrototype?.disconnect;
  const createGain = window.BaseAudioContext?.prototype.createGain;
  const outputGain = () => muted ? 0 : volume;

  function applyMedia(media) {
    if (!volumeDescriptor || !(media instanceof HTMLMediaElement)) return;
    if (!requestedVolumes.has(media)) requestedVolumes.set(media, volumeDescriptor.get.call(media));
    trackedMedia.add(media);
    // Media routed through Web Audio is attenuated by its context's master only.
    volumeDescriptor.set.call(media, requestedVolumes.get(media) * (routedMedia.has(media) ? 1 : outputGain()));
  }
  function masterFor(context) {
    let master = masters.get(context);
    if (master) return master;
    master = createGain.call(context);
    master.gain.value = outputGain();
    originalConnect.call(master, context.destination);
    masters.set(context, master);
    liveMasters.add(master);
    context.addEventListener('statechange', () => {
      if (context.state === 'closed') liveMasters.delete(master);
    });
    return master;
  }
  function isLiveDestination(node, destination) {
    return node.context && typeof node.context.startRendering !== 'function' && destination === node.context.destination;
  }
  if (originalConnect && originalDisconnect && createGain) {
    nodePrototype.connect = function (...args) {
      if (isLiveDestination(this, args[0])) {
        const requestedDestination = args[0];
        args[0] = masterFor(this.context);
        originalConnect.apply(this, args);
        return requestedDestination;
      }
      return originalConnect.apply(this, args);
    };
    nodePrototype.disconnect = function (...args) {
      if (isLiveDestination(this, args[0]) && masters.has(this.context)) args[0] = masters.get(this.context);
      return originalDisconnect.apply(this, args);
    };
  }
  if (volumeDescriptor?.get && volumeDescriptor?.set) {
    Object.defineProperty(mediaPrototype, 'volume', {
      ...volumeDescriptor,
      get() { return requestedVolumes.has(this) ? requestedVolumes.get(this) : volumeDescriptor.get.call(this); },
      set(value) {
        const numeric = Number(value);
        if (!Number.isFinite(numeric) || numeric < 0 || numeric > 1) throw new DOMException('Volume must be between 0 and 1.', 'IndexSizeError');
        requestedVolumes.set(this, numeric);
        applyMedia(this);
      },
    });
    const play = mediaPrototype.play;
    mediaPrototype.play = function (...args) { applyMedia(this); return play.apply(this, args); };
    const createElement = Document.prototype.createElement, createElementNS = Document.prototype.createElementNS;
    Document.prototype.createElement = function (...args) { const element = createElement.apply(this, args); applyMedia(element); return element; };
    Document.prototype.createElementNS = function (...args) { const element = createElementNS.apply(this, args); applyMedia(element); return element; };
    const NativeAudio = window.Audio;
    if (NativeAudio) window.Audio = new Proxy(NativeAudio, {
      construct(target, args, newTarget) { const media = Reflect.construct(target, args, newTarget); applyMedia(media); return media; },
      apply(target, receiver, args) { const media = Reflect.construct(target, args); applyMedia(media); return media; },
    });
    function inspectTree(node) {
      applyMedia(node);
      node.querySelectorAll?.('audio,video').forEach(applyMedia);
    }
    new MutationObserver(records => {
      for (const record of records) for (const node of record.addedNodes) inspectTree(node);
    }).observe(document, {childList:true, subtree:true});
    document.addEventListener('play', event => applyMedia(event.target), true);
    inspectTree(document);
    const audioContextPrototype = window.AudioContext?.prototype;
    const createMediaSource = audioContextPrototype?.createMediaElementSource;
    if (createMediaSource) audioContextPrototype.createMediaElementSource = function (media) {
      const source = createMediaSource.call(this, media);
      routedMedia.add(media);
      applyMedia(media);
      return source;
    };
  }
  function applyVolume() {
    for (const master of liveMasters) {
      if (master.context.state === 'closed') { liveMasters.delete(master); continue; }
      master.gain.cancelScheduledValues(master.context.currentTime);
      master.gain.setValueAtTime(outputGain(), master.context.currentTime);
    }
    for (const media of trackedMedia) {
      if (!media.isConnected && media.paused && !media.src && !media.srcObject) trackedMedia.delete(media);
      else applyMedia(media);
    }
  }
  const report = () => window.parent.postMessage({type:'strix-game-audio:ready', version:1, volume, muted}, config.appOrigin);
  window.addEventListener('message', event => {
    if (!event.isTrusted || event.source !== window.parent || event.origin !== config.appOrigin) return;
    const data = event.data;
    if (!data || typeof data !== 'object') return;
    if (data.type === 'strix-game-audio:get') { report(); return; }
    if (data.type !== 'strix-game-audio:set' || typeof data.volume !== 'number' || !Number.isFinite(data.volume) || data.volume < 0 || data.volume > 1 || typeof data.muted !== 'boolean') return;
    volume = data.volume; muted = data.muted;
    applyVolume(); report();
  });
  report();
})({"appOrigin":"https://strix-gaming.web.app","documents":["https://www.onlinegames.io/games/2024/unity/drift-king/index.html","https://www.onlinegames.io/games/2022/unity2/masked-special-forces/index.html","https://www.onlinegames.io/games/2024/unity/crazy-karts/index.html","https://www.onlinegames.io/games/2023/unity/drift-hunters-pro/index.html","https://www.onlinegames.io/games/2024/unity/highway-racer-pro/index.html","https://www.onlinegames.io/games/2021/unity2/wasteland-shooters/index.html","https://www.onlinegames.io/games/2023/unity/madalin-stunt-cars-pro/index.html","https://cloud.onlinegames.io/games/2024/construct/219/stickman-parkour/index-og.html","https://cloud.onlinegames.io/games/2025/unity/monster-survivors/index-og.html","https://cloud.onlinegames.io/games/2026/construct/328/golf-bit/game.html","https://cloud.onlinegames.io/games/2023/unity2/real-flight-simulator/index.html","https://www.onlinegames.io/games/2021/unity/stack-fire-ball/index.html","https://cloud.onlinegames.io/games/2025/unity/checkout-frenzy/index-og.html","https://cloud.onlinegames.io/games/2024/construct/311/basket-hoop/index-og.html","https://cloud.onlinegames.io/games/2024/unity/kawaii-shooter/index-og.html","https://www.onlinegames.io/games/2023/q2/capybara-clicker-pro/index.html","https://www.onlinegames.io/games/2021/unity3/stunt-simulator-2/index.html","https://cloud.onlinegames.io/games/2024/unity3/warstrike/index-og.html","https://www.onlinegames.io/games/2022/unity3/basketball-io/index.html","https://www.onlinegames.io/games/2022/unity4/cat-simulator/index.html","https://cloud.onlinegames.io/games/2025/unity3/crazy-cattle-3d/index-og.html","https://cloud.onlinegames.io/games/2024/unity2/super-car-driving/index-og.html","https://cloud.onlinegames.io/games/2026/unity/backflip-challenge/game.html","https://cloud.onlinegames.io/games/2024/unity3/cake-match-puzzle/index-og.html","https://cloud.onlinegames.io/games/2025/unity/tile-match/index-og.html","https://cloud.onlinegames.io/games/2026/galatrix/marble-run/game.html","https://www.onlinegames.io/games/2021/unity/army-combat/index.html","https://www.onlinegames.io/games/2021/unity3/legendary-sniper/index.html","https://www.onlinegames.io/games/2022/unity2/urban-sniper/index.html","https://www.onlinegames.io/games/2022/unity3/crazy-drifter/index.html","https://www.onlinegames.io/games/2022/unity4/subway-idle-3d/index.html","https://cloud.onlinegames.io/games/2024/unity3/block-blast/index-og.html","https://www.onlinegames.io/games/2023/construct/211/highway-cars/index.html","https://cloud.onlinegames.io/games/2024/unity2/troll-level/index-og.html","https://www.onlinegames.io/games/2022/construct/129/secret-sniper-agent/index.html","https://cloud.onlinegames.io/games/2025/unity4/fast-food-manager/index-og.html","https://www.onlinegames.io/games/2021/4/draw-the-bridge/index.html","https://www.onlinegames.io/games/2023/unity3/city-stunts/index.html","https://www.onlinegames.io/games/2023/unity3/drift-rider/index.html","https://cloud.onlinegames.io/games/2025/unity/fast-food-rush/index-og.html","https://www.onlinegames.io/games/2022/unity/taxi-simulator/index.html","https://www.onlinegames.io/games/2021/unity/rome-simulator/index.html","https://www.onlinegames.io/games/2021/unity/police-traffic/index.html","https://cloud.onlinegames.io/games/2021/1/julie-beauty-salon/index-og.html","https://www.onlinegames.io/games/2021/1/deer-hunter/index.html","https://www.onlinegames.io/games/2021/unity2/pinball-simulator/index.html","https://cloud.onlinegames.io/games/2025/html/solitaire/index-og.html","https://cloud.onlinegames.io/games/2026/construct/339/jungle-mart/game.html","https://www.onlinegames.io/games/2024/q2/darkness-survivors/index.html","https://www.onlinegames.io/games/2022/unity/tractor-farming-simulator/index.html","https://www.onlinegames.io/games/2023/unity3/supercars-drift/index.html","https://www.onlinegames.io/games/2021/unity/motorbike-traffic/index.html","https://www.onlinegames.io/games/2022/unity3/fort-drifter/index.html","https://www.onlinegames.io/games/2021/unity3/alien-sky-invasion/index.html","https://cloud.onlinegames.io/games/2025/unity/mahjong/index-og.html","https://www.onlinegames.io/games/2021/4/neon-racer/index.html","https://www.onlinegames.io/games/2023/unity/hero-rush-tower-defense/index.html","https://www.onlinegames.io/games/2022/construct/124/speed-drift-racing/index.html","https://www.onlinegames.io/games/2023/unity3/idle-dev-startup/index.html","https://www.onlinegames.io/games/2022/unity/highway-traffic/index.html","https://www.onlinegames.io/games/2022/construct/116/zombie-sniper/index.html","https://www.onlinegames.io/games/2021/2/wedding-beauty-salon/index.html","https://cloud.onlinegames.io/games/2025/unity/nuts-and-bolts-puzzle/index-og.html","https://www.onlinegames.io/games/2021/4/fun-party-makeup/index.html","https://www.onlinegames.io/games/2021/4/paradise-girls/index.html","https://www.onlinegames.io/games/2023/unity2/offroad-rally/index.html","https://www.onlinegames.io/games/2021/4/limousine-simulator/index.html","https://cloud.onlinegames.io/games/2021/2/city-police-cars/index-og.html","https://www.onlinegames.io/games/2023/unity/dark-ninja-hanjo/index.html","https://www.onlinegames.io/games/2021/3/perfect-first-date/index.html","https://www.onlinegames.io/games/2021/3/princess-influencer-salon/index.html","https://cloud.onlinegames.io/games/2021/2/monster-truck-mountain-climb/index-og.html","https://www.onlinegames.io/games/2021/unity/hover-racer-pro/index.html","https://www.onlinegames.io/games/2023/construct/185/crazy-stickman-physics/index.html","https://www.onlinegames.io/games/2021/unity/jacks-village/index.html","https://cloud.onlinegames.io/games/2025/construct/302/davo/index-og.html","https://www.onlinegames.io/games/2022/construct/145/speedrun-parkour/index.html","https://www.onlinegames.io/games/2023/construct/235/trains-io/index.html","https://cloud.onlinegames.io/games/2025/unity/farming-island/index-og.html","https://www.onlinegames.io/games/2022/unity3/battle-royale-simulator/index.html","https://cloud.onlinegames.io/games/2021/unity3/pixel-driver/index-og.html","https://cloud.onlinegames.io/games/2024/unity/highway-moto/index-og.html","https://www.onlinegames.io/games/2021/1/princess-beauty-salon/index.html","https://www.onlinegames.io/games/2023/unity/archer-hero/index.html","https://www.onlinegames.io/games/2021/unity3/kingdom-attack/index.html","https://cloud.onlinegames.io/games/2021/4/draw-the-car-path/index-og.html","https://www.onlinegames.io/games/2021/2/pets-beauty-salon/index.html","https://www.onlinegames.io/games/2021/2/owl-and-rabbit-fashion/index.html","https://www.onlinegames.io/games/2021/1/unicorn-beauty-salon/index.html","https://cloud.onlinegames.io/games/2021/2/ultimate-moto/index-og.html","https://www.onlinegames.io/games/2021/2/witch-beauty-salon/index.html","https://www.onlinegames.io/games/2023/unity2/idle-restaurant/index.html","https://www.onlinegames.io/games/2021/3/first-day-of-school/index.html","https://www.onlinegames.io/games/2021/2/rescue-helicopter/index.html","https://www.onlinegames.io/games/2021/unity/atv-highway-traffic/index.html","https://www.onlinegames.io/games/2022/unity/zombie-war-defense/index.html","https://www.onlinegames.io/games/2023/unity3/hook-wars/index.html","https://www.onlinegames.io/games/2022/unity/the-farmer/index.html","https://www.onlinegames.io/games/2021/1/racing-cars/index.html","https://www.onlinegames.io/games/2021/unity/dockyard-tank-parking/index.html","https://www.onlinegames.io/games/2021/unity/monster-truck-city-parking/index.html","https://www.onlinegames.io/games/2022/construct/147/draw-the-bird-path/index.html","https://www.onlinegames.io/games/2022/unity/edys-car-simulator/index.html","https://www.onlinegames.io/games/2022/unity3/blocky-blast/index.html","https://cloud.onlinegames.io/games/2026/unity/velocity-rush/game.html","https://cloud.onlinegames.io/games/2021/unity/motorbike-stunt-simulator/index-og.html","https://cloud.onlinegames.io/games/2024/more2/nova-craft/index.html","https://www.onlinegames.io/games/2021/unity/moto-trials/index.html","https://www.onlinegames.io/games/2024/unity/stunt-rider/index.html","https://www.onlinegames.io/games/2023/unity/drift-fury/index.html","https://www.onlinegames.io/games/2024/construct/233/state-io-wars/index.html","https://www.onlinegames.io/games/2021/3/princesses-prom-night/index.html","https://www.onlinegames.io/games/2021/3/hill-climb-cars/index.html","https://cloud.onlinegames.io/games/2025/construct/337/crown-defense/index-og.html","https://cloud.onlinegames.io/games/2021/1/jeep-driver/index-og.html","https://www.onlinegames.io/games/2022/unity2/soul-essence-adventure/index.html","https://cloud.onlinegames.io/games/2024/unity2/survival-island/index-og.html","https://www.onlinegames.io/games/2022/unity3/powerslide-kart-simulator/index.html","https://www.onlinegames.io/games/2023/unity/hero-dragon-power/index.html","https://www.onlinegames.io/games/2022/unity4/solitaire-adventure/index.html","https://www.onlinegames.io/games/2022/unity/survival-craft/index.html","https://www.onlinegames.io/games/2021/unity2/crazy-ball-adventures/index.html","https://www.onlinegames.io/games/2022/unity3/crazy-car-arena/index.html","https://www.onlinegames.io/games/2022/unity3/stick-guys-defense/index.html","https://www.onlinegames.io/games/2023/construct/237/shortcut-race/index.html","https://www.onlinegames.io/games/2022/construct/63/army-driver/index.html","https://cloud.onlinegames.io/games/2026/unity/age-of-battle/game.html","https://www.onlinegames.io/games/2022/unity/sweet-sugar-match/index.html","https://www.onlinegames.io/games/2021/unity2/zombie-road/index.html","https://cloud.onlinegames.io/games/2024/construct/223/monster-truck-booster/index-og.html","https://www.onlinegames.io/games/2022/unity/storm-city-mafia/index.html","https://cloud.onlinegames.io/games/2025/unity/find-it/index-og.html","https://cloud.onlinegames.io/games/2025/unity2/kingdom-battle-3d/index-og.html","https://www.onlinegames.io/games/2021/2/galactic-sniper/index.html","https://www.onlinegames.io/games/2021/unity2/war-simulator/index.html","https://cloud.onlinegames.io/games/2025/construct/208/kings-io/index-og.html","https://cloud.onlinegames.io/games/2025/construct/331/paw-clicker/index-og.html","https://www.onlinegames.io/games/2023/unity3/dino-chaos-idle/index.html","https://cloud.onlinegames.io/games/2021/3/monster-truck-race-arena/index-og.html","https://www.onlinegames.io/games/2021/unity2/draw-here/index.html","https://cloud.onlinegames.io/games/2022/unity3/crazy-moto-racing/index-og.html","https://www.onlinegames.io/games/2021/unity3/hover-racer/index.html","https://cloud.onlinegames.io/games/2021/1/apocalypse-truck/index-og.html","https://www.onlinegames.io/games/2022/construct/149/draw-the-truck-bridge/index.html","https://www.onlinegames.io/games/2021/1/monster-truck-racing/index.html","https://www.onlinegames.io/games/2024/unity/funny-shooter-bro/index.html","https://www.onlinegames.io/games/2022/construct/144/truck-racing/index.html","https://www.onlinegames.io/games/2021/4/mr-space-bullet/index.html","https://www.onlinegames.io/games/2022/construct/65/galactic-driver/index.html","https://cloud.onlinegames.io/games/2021/2/futuristic-racer/index-og.html","https://www.onlinegames.io/games/2021/2/baby-beauty-salon/index.html","https://www.onlinegames.io/games/2022/construct/164/treasure-hunter/index.html","https://www.onlinegames.io/games/2022/unity2/egg-helix/index.html","https://www.onlinegames.io/games/2021/4/racing-cars-2/index.html","https://www.onlinegames.io/games/2023/unity/crazy-strike-force/index.html","https://www.onlinegames.io/games/2022/unity4/burnout-drift-hunter/index.html","https://www.onlinegames.io/games/2022/unity2/highway-racer-2/index.html"]});
