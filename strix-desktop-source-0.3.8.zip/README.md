# Strix Desktop 0.3.8 — Windows x64

Shell Electron da Strix. A interface é carregada de https://strix-gaming.web.app.

## Compilar no Windows

Requisitos: Node.js 24, Visual Studio Build Tools com C++/Windows SDK e PowerShell.

```powershell
npm ci --no-audit --no-fund
npm ci --prefix app --omit=dev --no-audit --no-fund
node --test tests/*.cjs
./native/build.ps1
node integration/native-activity.cjs
npx electron integration/electron-capture.cjs
npx electron integration/electron-fullscreen.cjs
npm run build:windows -- --publish never
```

O instalador NSIS e os metadados de atualização são gerados em `release/`. As dependências ficam fixadas nos dois lockfiles. O Electron é baixado oficialmente pelo builder; não há dependência de cache ou caminho local.

O workflow GitHub Actions compila, verifica e publica um prerelease após disparo manual. O atualizador dos aplicativos existentes aceita prereleases. Executar esse workflow publica uma atualização real; o comando de build local acima não publica.

Instalação por usuário sem elevação. O executável não tem assinatura Authenticode. Build e testes automatizados não substituem instalação/upgrade e teste de call em Windows físico.
