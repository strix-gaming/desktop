# Strix Desktop 0.3.8

- Atalhos globais de microfone e fone passam a ser opcionais, desativados por padrão. Quando ativados em Configurações → Atalhos, funcionam somente durante uma chamada.
- Evita comandos duplicados ao segurar a tecla ou quando o aplicativo está em foco; comandos da bandeja continuam independentes.
- Interrompe o download de atualização quando uma chamada começa e retoma depois dela. Não reinicia durante conexão ou chamada ativa.
- Corrige estado antigo do atualizador após recarregar a interface e exige ação explícita para reiniciar e instalar.

Mantém captura de tela com áudio, tela cheia nativa e atividade opcional de jogos/Spotify. Instalador de testes para Windows x64; sem assinatura Authenticode.
