Strix 0.3.15

Biblioteca com consulta somente de leitura do perfil Steam local mais recente, tempo de jogo local e conquistas públicas. Perfis privados e erros da Steam não geram conquistas ou estatísticas fictícias. Inclui os controles reversíveis de energia da versão 0.3.14.
