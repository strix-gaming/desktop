const fs=require('node:fs/promises');
const path=require('node:path');
const MAX=1024*1024;
const decode=value=>String(value||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/&(?:amp|lt|gt|quot|apos|#\d+|#x[\da-f]+);/gi,entity=>{const map={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'"};if(map[entity])return map[entity];const n=entity[2]==='x'?parseInt(entity.slice(3,-1),16):Number(entity.slice(2,-1));return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).trim();
const tag=(xml,name)=>decode(new RegExp('<'+name+'(?:\\s[^>]*)?>([\\s\\S]*?)</'+name+'>','i').exec(xml)?.[1]);
function parseAchievements(xml){
 if(typeof xml!=='string'||Buffer.byteLength(xml)>MAX||/<!DOCTYPE|<!ENTITY/i.test(xml)||!/<playerstats[\s>]/i.test(xml))return null;
 if(!/<achievements[\s>]/i.test(xml)&&!/<achievements\s*\//i.test(xml))return null;
 const result=[];
 for(const match of xml.matchAll(/<achievement\b([^>]*)>([\s\S]*?)<\/achievement>/gi)){
  const unlocked=/\bclosed\s*=\s*["']1["']/.test(match[1]),name=tag(match[2],'name')||tag(match[2],'apiname');if(!name)continue;
  let icon=tag(match[2],unlocked?'iconClosed':'iconOpen');try{const u=new URL(icon);if(u.protocol!=='https:'||!['steamstatic.com','steamcommunity.com','steampowered.com'].some(host=>u.hostname===host||u.hostname.endsWith('.'+host)))icon=undefined;}catch{icon=undefined;}
  result.push({id:tag(match[2],'apiname')||String(result.length),name:name.slice(0,200),description:tag(match[2],'description').slice(0,1000),icon,unlocked});if(result.length===1000)break;
 }
 return result;
}
async function publicXml(url,fetcher=fetch){
 const response=await fetcher(url,{redirect:'error',signal:AbortSignal.timeout(8000),headers:{Accept:'application/xml,text/xml'}});
 if(!response.ok)throw Error('Steam indisponível');
 if(Number(response.headers.get('content-length'))>MAX)throw Error('Resposta extensa');
 const reader=response.body.getReader();let size=0;const chunks=[];
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX)throw Error('Resposta extensa');chunks.push(Buffer.from(value));}}finally{await reader.cancel().catch(()=>{});}
 return Buffer.concat(chunks).toString('utf8');
}
function createSteamProfile({parseVdf,readFile=async file=>{const stat=await fs.stat(file);if(stat.size>MAX)throw Error('Arquivo extenso');return fs.readFile(file,'utf8');},fetchXml=publicXml,now=Date.now}){
 const cache=new Map(),pending=new Map();
 return {async read(record){
  if(!/^[1-9]\d{0,9}$/.test(record.appId))return {message:'Jogo Steam indisponível.'};
  let owner=null,root='';
  for(const cacheRoot of (record.cacheRoots||[]).slice(0,8)){
   const client=path.resolve(cacheRoot,'../..');
   try{const users=parseVdf(await readFile(path.join(client,'config','loginusers.vdf'))).users||{};const account=Object.entries(users).filter(([id])=>/^7656119\d{10}$/.test(id)).sort((a,b)=>Number(b[1].MostRecent||0)-Number(a[1].MostRecent||0)||Number(b[1].Timestamp||0)-Number(a[1].Timestamp||0))[0];if(account){owner=account[0];root=client;break;}}catch{}
  }
  if(!owner)return {message:'Entre na Steam neste computador para consultar seu perfil.'};
  const key=owner+':'+record.appId,previous=cache.get(key);if(previous&&now()-previous.at<300000)return previous.value;if(pending.has(key))return pending.get(key);
  const request=(async()=>{
   const profileUrl='https://steamcommunity.com/profiles/'+owner;
   const result={profileUrl};
   try{const account=(BigInt(owner)-76561197960265728n).toString();const local=parseVdf(await readFile(path.join(root,'userdata',account,'config','localconfig.vdf')));const minutes=Number(local.UserLocalConfigStore?.Software?.Valve?.Steam?.apps?.[record.appId]?.Playtime);if(Number.isFinite(minutes)&&minutes>=0)result.playtimeMinutes=minutes;}catch{}
   try{const achievements=parseAchievements(await fetchXml(profileUrl+'/stats/'+record.appId+'/?xml=1'));if(achievements)result.achievements=achievements;else result.message='A Steam não disponibilizou as conquistas. Confira se seu perfil e detalhes dos jogos são públicos.';}catch{result.message='Não foi possível consultar as conquistas na Steam agora.';}
   cache.set(key,{at:now(),value:result});if(cache.size>64)cache.delete(cache.keys().next().value);return result;
  })().finally(()=>pending.delete(key));pending.set(key,request);return request;
 }};
}
module.exports={createSteamProfile,parseAchievements,publicXml};
