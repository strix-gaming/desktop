Strix Desktop 0.3.1 — versão de testes

- Opção Iniciar com o Windows nas configurações de áudio do aplicativo. Desligada por padrão.
- Usa as contas já criadas em https://strix-gaming.web.app/app.
- Interface e áudio recebem os ajustes publicados no Firebase.

Distribuição sem assinatura digital e sem atualização automática. Ainda requer teste de instalação, login, chamadas e compartilhamento de jogos em computadores Windows reais. O seletor próprio de tela não captura o áudio do jogo; não há promessa de equivalência ao Discord.
