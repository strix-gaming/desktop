// Keep the remote renderer's desktop access deliberately small.
const COMMANDS = new Set(['microphone', 'deafen', 'leave']);
const IDLE = Object.freeze({connected:false, mic:false, deaf:false, canPublish:false, busy:false});
function sanitizeCall(value) {
  if (!value || typeof value !== 'object' || value.connected !== true) return {...IDLE};
  return {connected:true, mic:value.mic === true, deaf:value.deaf === true,
    canPublish:value.canPublish === true, busy:value.busy === true};
}
function trustedFrame(event, contents, origin) {
  if (!contents || contents.isDestroyed() || event.sender !== contents || event.senderFrame !== contents.mainFrame) return false;
  try { return new URL(event.senderFrame.url).origin === origin; } catch { return false; }
}
function canCommand(command, state) {
  return COMMANDS.has(command) && state.connected &&
    (command !== 'microphone' || (state.canPublish && !state.busy));
}
function windowBounds(saved, displays) {
  const fallback = {width:1440, height:920};
  if (!saved || !['x','y','width','height'].every(key => Number.isFinite(saved[key]))) return fallback;
  // A removed monitor must not leave the application inaccessible offscreen.
  const area = displays.map(display => display.workArea).find(area =>
    saved.x < area.x + area.width && saved.x + saved.width > area.x &&
    saved.y < area.y + area.height && saved.y + saved.height > area.y);
  if (!area) return fallback;
  const width = Math.min(area.width, Math.max(920, saved.width));
  const height = Math.min(area.height, Math.max(620, saved.height));
  return {width, height, x:Math.max(area.x, Math.min(saved.x, area.x + area.width - width)),
    y:Math.max(area.y, Math.min(saved.y, area.y + area.height - height))};
}
module.exports = {IDLE, sanitizeCall, trustedFrame, canCommand, windowBounds};
