const {contextBridge, ipcRenderer} = require('electron');
// Never expose IPC itself, Electron objects, paths, or arbitrary channel names.
if (process.isMainFrame) {
  contextBridge.exposeInMainWorld('strixDesktop', Object.freeze({
    version: '0.3.1',
    getStartup:()=>ipcRenderer.invoke('strix:startup'),
    setStartup:value=>typeof value==='boolean'?ipcRenderer.invoke('strix:startup',value):Promise.reject(new Error('Valor inválido')),
    updateCallState(value) {
      if (!value || typeof value !== 'object') return;
      ipcRenderer.send('strix:call-state', {
        connected:value.connected === true, mic:value.mic === true, deaf:value.deaf === true,
        canPublish:value.canPublish === true, busy:value.busy === true
      });
    },
    onCommand(callback) {
      if (typeof callback !== 'function') return () => {};
      const listener = (_event, command) => {
        if (['microphone','deafen','leave'].includes(command)) callback(command);
      };
      ipcRenderer.on('strix:call-command', listener);
      return () => ipcRenderer.removeListener('strix:call-command', listener);
    },
    onVisibility(callback) {
      if (typeof callback !== 'function') return () => {};
      const listener = (_event, visible) => callback(visible === true);
      ipcRenderer.on('strix:window-visible', listener);
      return () => ipcRenderer.removeListener('strix:window-visible', listener);
    }
  }));
}
