const {app,shell}=require('electron');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const assert=require('node:assert/strict');
const {refreshWindowsIdentity,APP_ID}=require('../app/windows-identity.cjs');
app.whenReady().then(async()=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'strix-identity-native-'));
 try{
  const file=path.join(root,'Strix antigo.lnk'),other=path.join(root,'Outra instalacao.lnk');
  const icon=path.resolve(__dirname,'../app/icon.ico');
  assert.ok(shell.writeShortcutLink(file,'create',{target:process.execPath,args:'--native-test',cwd:root,icon:process.execPath,iconIndex:0,appUserModelId:APP_ID}));
  assert.ok(shell.writeShortcutLink(other,'create',{target:'C:\\Other\\Strix.exe',icon:process.execPath,iconIndex:0}));
  const identityApp={isPackaged:true,getPath:name=>name==='exe'?process.execPath:app.getPath(name)};
  assert.deepEqual(await refreshWindowsIdentity({app:identityApp,shell},{platform:'win32',roots:[[root,0]],icon}),{updated:1,failed:0});
  const repaired=shell.readShortcutLink(file);
  assert.equal(repaired.icon,icon);assert.equal(repaired.iconIndex,0);assert.equal(repaired.appUserModelId,APP_ID);
  assert.equal(repaired.args,'--native-test');assert.equal(repaired.cwd,root);assert.equal(repaired.target,process.execPath);
  assert.equal(shell.readShortcutLink(other).icon,process.execPath);
  assert.deepEqual(await refreshWindowsIdentity({app:identityApp,shell},{platform:'win32',roots:[[root,0]],icon}),{updated:0,failed:0});
  console.log('Native Windows shortcut identity verified, including argument preservation and other-install isolation.');
 }finally{await fs.rm(root,{recursive:true,force:true});}
 app.exit(0);
}).catch(error=>{console.error(error);app.exit(1);});
