const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
function icoImages(bytes){
 assert.equal(bytes.readUInt16LE(0),0);assert.equal(bytes.readUInt16LE(2),1);
 return Array.from({length:bytes.readUInt16LE(4)},(_,i)=>{
  const at=6+i*16,size=bytes.readUInt32LE(at+8),offset=bytes.readUInt32LE(at+12);
  assert.ok(offset+size<=bytes.length);return bytes.subarray(offset,offset+size);
 });
}
function peIcons(bytes){
 assert.equal(bytes.toString('ascii',0,2),'MZ');const pe=bytes.readUInt32LE(0x3c);assert.equal(bytes.toString('ascii',pe,pe+4),'PE\0\0');
 const sections=bytes.readUInt16LE(pe+6),optional=pe+24,optSize=bytes.readUInt16LE(pe+20),magic=bytes.readUInt16LE(optional);
 assert.ok([0x10b,0x20b].includes(magic));const data=optional+(magic===0x20b?112:96),resourceRva=bytes.readUInt32LE(data+16);
 const rvaOffset=rva=>{for(let i=0;i<sections;i++){const at=optional+optSize+i*40,virtual=bytes.readUInt32LE(at+12),size=Math.max(bytes.readUInt32LE(at+8),bytes.readUInt32LE(at+16));if(rva>=virtual&&rva<virtual+size)return bytes.readUInt32LE(at+20)+rva-virtual;}throw Error('Resource RVA outside PE sections');};
 const base=rvaOffset(resourceRva),icons=[];
 function directory(offset,depth,type){
  assert.ok(depth<5);const at=base+offset,count=bytes.readUInt16LE(at+12)+bytes.readUInt16LE(at+14);
  for(let i=0;i<count;i++){
   const entry=at+16+i*8,id=bytes.readUInt32LE(entry),child=bytes.readUInt32LE(entry+4),nextType=depth===0?id:type;
   if(depth===0&&nextType!==3)continue;
   if(child&0x80000000)directory(child&0x7fffffff,depth+1,nextType);
   else if(nextType===3){const leaf=base+child,start=rvaOffset(bytes.readUInt32LE(leaf)),size=bytes.readUInt32LE(leaf+4);assert.ok(start+size<=bytes.length);icons.push(bytes.subarray(start,start+size));}
  }
 }
 directory(0,0,undefined);return icons;
}
const root=path.resolve(__dirname,'..'),version=require('../package.json').version;
const source=fs.readFileSync(path.join(root,'app/icon.ico')),expected=icoImages(source);
assert.ok(expected.length>=5,'multi-resolution icon required');
const files=process.argv.slice(2);
if(!files.length)files.push(path.join(root,'release/win-unpacked/Strix.exe'),path.join(root,`release/Strix-Setup-${version}-Windows-x64.exe`));
for(const file of files){
 const actual=peIcons(fs.readFileSync(file));
 for(const image of expected)assert.ok(actual.some(candidate=>candidate.equals(image)),`${path.basename(file)} missing an S icon resolution (${image.length} bytes)`);
 console.log(JSON.stringify({file:path.basename(file),icon:'Strix S',resolutions:expected.length,sourceSha256:crypto.createHash('sha256').update(source).digest('hex')}));
}
const copied=path.join(root,'release/win-unpacked/resources/strix-S-20261008.ico');
assert.ok(fs.existsSync(copied),'shortcut ICO missing from packaged resources');
assert.ok(fs.readFileSync(copied).equals(source),'shortcut ICO must match embedded application icon');
