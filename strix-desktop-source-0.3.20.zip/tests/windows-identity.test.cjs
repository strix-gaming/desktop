const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {refreshWindowsIdentity, sameTarget, APP_ID} = require('../app/windows-identity.cjs');
test('Windows target comparison handles case and separators without matching another installation', () => {
 assert.ok(sameTarget('C:/Users/A/Strix/Strix.exe','c:\\users\\a\\strix\\strix.exe'));
 assert.ok(!sameTarget('C:/Other/Strix.exe','C:/Users/A/Strix/Strix.exe'));
 assert.ok(!sameTarget(null,'C:/Strix.exe'));
});
test('identity repair updates only existing shortcuts for this install and preserves launch details', async t => {
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'strix-identity-'));
 t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const icon=path.join(root,'new-S.ico'); await fs.writeFile(icon,'ico');
 const records=new Map(), updates=[];
 for(const [name,record] of Object.entries({
  'Strix.lnk':{target:'C:\\Apps\\Strix\\Strix.exe',args:'--custom',cwd:'C:\\Apps\\Strix',description:'Mine',icon:'C:\\Apps\\Strix\\Strix.exe'},
  'Pinned.lnk':{target:'c:/apps/strix/strix.exe'},
  'Different install.lnk':{target:'C:\\OldStrix\\Strix.exe'},
  'Browser.lnk':{target:'C:\\Apps\\Browser.exe'},
 })){const file=path.join(root,name);await fs.writeFile(file,'lnk');records.set(file,record);}
 const shell={readShortcutLink:file=>records.get(file),writeShortcutLink:(file,operation,patch)=>{assert.equal(operation,'update');updates.push({file,patch});records.set(file,{...records.get(file),...patch});return true;}};
 const app={isPackaged:true,getPath:key=>key==='exe'?'C:\\Apps\\Strix\\Strix.exe':root};
 const options={platform:'win32',roots:[[root,0]],icon};
 assert.deepEqual(await refreshWindowsIdentity({app,shell},options),{updated:2,failed:0});
 assert.equal(records.get(path.join(root,'Strix.lnk')).args,'--custom');
 assert.equal(records.get(path.join(root,'Strix.lnk')).cwd,'C:\\Apps\\Strix');
 assert.deepEqual(Object.keys(updates[0].patch).sort(),['appUserModelId','icon','iconIndex']);
 assert.equal(updates[0].patch.appUserModelId,APP_ID);
 assert.deepEqual(await refreshWindowsIdentity({app,shell},options),{updated:0,failed:0});
 assert.equal(records.size,4);
});
test('missing icon, unreadable shortcuts and other platforms do not block startup', async t => {
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'strix-identity-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const app={isPackaged:true,getPath:()=>root};const shell={readShortcutLink:()=>{throw Error('unreadable');},writeShortcutLink:()=>{throw Error('must not write');}};
 assert.deepEqual(await refreshWindowsIdentity({app,shell},{platform:'darwin'}),{updated:0,failed:0});
 assert.deepEqual(await refreshWindowsIdentity({app,shell},{platform:'win32',icon:path.join(root,'missing'),roots:[[root,0]]}),{updated:0,failed:1});
 const icon=path.join(root,'icon.ico');await fs.writeFile(icon,'ico');await fs.writeFile(path.join(root,'bad.lnk'),'bad');
 assert.deepEqual(await refreshWindowsIdentity({app,shell},{platform:'win32',icon,roots:[[root,0]]}),{updated:0,failed:1});
});
