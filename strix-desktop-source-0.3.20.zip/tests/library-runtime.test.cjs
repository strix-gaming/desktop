const {test}=require('node:test'),assert=require('node:assert/strict');
const {matches,createLibraryRuntime}=require('../app/library-runtime.cjs');
const game={id:'library:'+'a'.repeat(32),type:'steam',installed:'C:\\Steam\\common\\Game'};
const proc={pid:42,path:'C:\\Steam\\common\\Game\\bin\\game.exe',started:'12345',windowed:true};
test('running state uses the installed directory boundary, never a title or executable name alone',()=>{
 assert.equal(matches(game,proc),true);assert.equal(matches(game,{...proc,path:'c:\\steam\\common\\game\\bin\\GAME.EXE'}),true);
 for(const path of ['C:\\Other\\game.exe','C:\\Steam\\common\\Game copy\\game.exe','C:\\Steam\\common\\Game\\..\\Other\\game.exe','C:\\Steam\\common\\Game\\crashhandler.exe','C:\\Steam\\common\\Game\\setup.exe'])assert.equal(matches(game,{...proc,path}),false,path);
 assert.equal(matches({...game,type:'shortcut'},proc),false);assert.equal(matches(game,{...proc,pid:'42'}),false);
});
test('external launch is detected, duplicate processes collapse to one game and no native identity reaches UI',async()=>{
 const runtime=createLibraryRuntime({list:async()=>[proc,{...proc,pid:43}],close:async()=>assert.fail('read must not close')});
 assert.deepEqual(await runtime.status([game]),[{id:game.id,running:true,canClose:true}]);
});
test('close re-reads processes so an exited/replaced game cannot target a stale PID',async()=>{
 let values=[proc],now=0,calls=0;const runtime=createLibraryRuntime({list:async()=>values,close:async()=>{calls++;return {ok:true};},now:()=>now});
 await runtime.status([game]);values=[{...proc,path:'C:\\Other\\editor.exe'}];assert.equal((await runtime.close(game)).ok,false);assert.equal(calls,0);
});
test('close checks authorization after the process read and preserves identity for native revalidation',async()=>{
 let authorized=true,calls=[];const runtime=createLibraryRuntime({list:async()=>{authorized=false;return [proc];},close:async p=>{calls.push(p);return {ok:true};}});
 assert.equal((await runtime.close(game,()=>authorized)).ok,false);assert.equal(calls.length,0);
 const active=createLibraryRuntime({list:async()=>[proc],close:async p=>{calls.push(p);return {ok:true};}});assert.equal((await active.close(game)).ok,true);assert.deepEqual(calls,[proc]);
});
test('headless game is marked open without inventing a closable window',async()=>{
 const runtime=createLibraryRuntime({list:async()=>[{...proc,windowed:false}],close:async()=>assert.fail('no window')});assert.deepEqual(await runtime.status([game]),[{id:game.id,running:true,canClose:false}]);assert.equal((await runtime.close(game)).ok,false);
});
test('status failure is not cached as an authoritative stopped game and concurrent reads coalesce',async()=>{
 let calls=0;const runtime=createLibraryRuntime({list:async()=>{if(++calls===1)throw Error('unavailable');return [proc];},close:async()=>({ok:true})});await assert.rejects(runtime.status([game]));const results=await Promise.all([runtime.status([game]),runtime.status([game])]);assert.equal(calls,2);assert.deepEqual(results[0],results[1]);
});
