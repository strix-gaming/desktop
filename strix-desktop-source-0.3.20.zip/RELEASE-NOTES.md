Strix 0.3.20

Corrige o ícone do Windows após atualizar: o S da Strix passa a ter um arquivo próprio, os atalhos da área de trabalho, do menu Iniciar e os atalhos já fixados para esta instalação são reparados ao abrir o aplicativo. Nenhum cache global ou dado pessoal é removido.

O ícone do aplicativo e do instalador é conferido diretamente nos executáveis gerados. Atualizações continuam sendo instaladas apenas após confirmação e fora das chamadas.

Instalador Windows x64 de teste, ainda sem assinatura digital.
