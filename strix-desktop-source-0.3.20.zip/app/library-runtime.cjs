const path=require('node:path');
const {execFile}=require('node:child_process');
const normalize=value=>path.win32.normalize(value).toLowerCase();
function matches(record,process){
 if(record?.type!=='steam'||typeof record.installed!=='string'||!Number.isSafeInteger(process?.pid)||process.pid<=0||typeof process.path!=='string'||typeof process.started!=='string'||!/^\d{1,20}$/.test(process.started))return false;
 const file=normalize(process.path),root=normalize(record.installed).replace(/\\$/,'')+'\\';
 if(!file.startsWith(root)||!file.endsWith('.exe'))return false;
 // Installers, crash reporters and anti-cheat helpers are not the game session.
 return !/(?:crash|unins|redist|setup|install|update|launcher|anticheat|anti.cheat|unitycrash|notification|cefsubprocess|webhelper)/i.test(path.win32.basename(file));
}
function createLibraryRuntime({list,close,now=Date.now}){
 let pending=null,cached=[],sampled=-Infinity,closing=new Set();
 async function snapshot(force=false){if(pending)return pending;if(!force&&now()-sampled<2500)return cached;pending=Promise.resolve().then(list).then(value=>{if(!Array.isArray(value))throw Error('Estado inválido');cached=value.slice(0,1024);sampled=now();return cached;}).finally(()=>{pending=null;});return pending;}
 return {
  async status(records){const processes=await snapshot();return records.filter(record=>processes.some(p=>matches(record,p))).map(record=>({id:record.id,running:true,canClose:processes.some(p=>matches(record,p)&&p.windowed===true)}));},
  async close(record,authorized=()=>true){
   if(!record||closing.has(record.id)||!authorized())return {ok:false,error:'Jogo indisponível.'};closing.add(record.id);
   try{const targets=(await snapshot(true)).filter(p=>matches(record,p)&&p.windowed===true);if(!authorized()||!targets.length)return {ok:false,error:'Nenhuma janela deste jogo está disponível para fechar.'};let sent=0;for(const target of targets){if(!authorized())break;if((await close(target))?.ok)sent++;}sampled=-Infinity;return sent?{ok:true}:{ok:false,error:'Não foi possível solicitar o fechamento. Feche pelo próprio jogo.'};}
   catch{return {ok:false,error:'Não foi possível consultar o jogo. Tente novamente.'};}finally{closing.delete(record.id);}
  }
 };
}
function nativeRuntime(app){
 const binary=app.isPackaged?path.join(process.resourcesPath,'strix-library-process.exe'):path.join(__dirname,'../native/bin/strix-library-process.exe');
 const run=args=>new Promise((resolve,reject)=>execFile(binary,args,{timeout:5000,maxBuffer:1024*1024,windowsHide:true,shell:false},(error,stdout)=>{if(error)return reject(error);try{resolve(JSON.parse(stdout));}catch(e){reject(e);}}));
 return createLibraryRuntime({list:()=>run(['--list']),close:p=>run(['--close',String(p.pid),p.path,p.started])});
}
module.exports={matches,createLibraryRuntime,nativeRuntime};
