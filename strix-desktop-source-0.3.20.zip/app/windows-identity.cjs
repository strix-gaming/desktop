const fs = require('node:fs/promises');
const path = require('node:path');
const APP_ID = 'app.strix.desktop';
// A new filename bypasses Explorer's cached icon for the unchanged Strix.exe path.
const ICON_FILE = 'strix-S-20261008.ico';
const sameTarget = (left, right) => typeof left === 'string' && typeof right === 'string' && path.win32.normalize(left).toLowerCase() === path.win32.normalize(right).toLowerCase();
async function shortcutFiles(root, depth = 0) {
  let entries;
  try { entries = await fs.readdir(root, {withFileTypes:true}); } catch { return []; }
  const files = [];
  for (const entry of entries) {
    const file = path.join(root, entry.name);
    if (entry.isFile() && /\.lnk$/i.test(entry.name)) files.push(file);
    else if (entry.isDirectory() && depth > 0) files.push(...await shortcutFiles(file, depth - 1));
  }
  return files;
}
async function refreshWindowsIdentity({app, shell}, options = {}) {
  if ((options.platform || process.platform) !== 'win32' || !app.isPackaged) return {updated:0,failed:0};
  const executable = options.executable || app.getPath('exe');
  const icon = options.icon || path.join(process.resourcesPath, ICON_FILE);
  const roots = options.roots || [
    [app.getPath('desktop'), 0],
    [path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs'), 1],
    [path.join(app.getPath('appData'), 'Microsoft', 'Internet Explorer', 'Quick Launch', 'User Pinned', 'TaskBar'), 0],
  ];
  try { await fs.access(icon); } catch { return {updated:0,failed:1}; }
  let updated = 0, failed = 0;
  const seen = new Set();
  for (const [root, depth] of roots) {
    for (const file of await shortcutFiles(root, depth)) {
      if (seen.has(file)) continue;
      seen.add(file);
      try {
        const current = shell.readShortcutLink(file);
        // Never change another application, a renamed copy, or a different install.
        if (!sameTarget(current.target, executable)) continue;
        if (sameTarget(current.icon, icon) && current.iconIndex === 0 && current.appUserModelId === APP_ID) continue;
        // Updating only these fields preserves arguments, working directory and name.
        if (shell.writeShortcutLink(file, 'update', {icon,iconIndex:0,appUserModelId:APP_ID})) updated++;
        else failed++;
      } catch { failed++; }
    }
  }
  return {updated,failed};
}
module.exports = {APP_ID, ICON_FILE, refreshWindowsIdentity, sameTarget};
