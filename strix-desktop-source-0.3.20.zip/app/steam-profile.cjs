const fs=require('node:fs/promises');
const path=require('node:path');
const MAX=1024*1024;
const decode=value=>String(value||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/&(?:amp|lt|gt|quot|apos|#\d+|#x[\da-f]+);/gi,entity=>{const map={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'"};if(map[entity])return map[entity];const n=entity[2]==='x'?parseInt(entity.slice(3,-1),16):Number(entity.slice(2,-1));return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).trim();
const tag=(xml,name)=>decode(new RegExp('<'+name+'(?:\\s[^>]*)?>([\\s\\S]*?)</'+name+'>','i').exec(xml)?.[1]);
function parseAchievements(xml){
 if(typeof xml!=='string'||Buffer.byteLength(xml)>MAX||/<!DOCTYPE|<!ENTITY/i.test(xml)||!/<playerstats[\s>]/i.test(xml))return null;
 if(!/<achievements[\s>]/i.test(xml)&&!/<achievements\s*\//i.test(xml))return null;
 const result=[];
 for(const match of xml.matchAll(/<achievement\b([^>]*)>([\s\S]*?)<\/achievement>/gi)){
  const unlocked=/\bclosed\s*=\s*["']1["']/.test(match[1]),name=tag(match[2],'name')||tag(match[2],'apiname');if(!name)continue;
  let icon=tag(match[2],unlocked?'iconClosed':'iconOpen');try{const u=new URL(icon);if(u.protocol!=='https:'||!['steamstatic.com','steamcommunity.com','steampowered.com'].some(host=>u.hostname===host||u.hostname.endsWith('.'+host)))icon=undefined;}catch{icon=undefined;}
  result.push({id:tag(match[2],'apiname')||String(result.length),name:name.slice(0,200),description:tag(match[2],'description').slice(0,1000),icon,unlocked});if(result.length===1000)break;
 }
 return result;
}
function safeIcon(value){try{const u=new URL(value);if(u.protocol==='http:')u.protocol='https:';return u.protocol==='https:'&&!u.username&&!u.password&&['steamstatic.com','steamcommunity.com','steampowered.com'].some(host=>u.hostname===host||u.hostname.endsWith('.'+host))?u.href:undefined;}catch{return undefined;}}
// Current Steam Community pages no longer consistently honor xml=1. Parse only
// the personal achievements section and verify its counts against the summary.
function parseAchievementPage(html){
 if(typeof html!=='string'||Buffer.byteLength(html)>MAX||!/<[^>]+id=["']personalAchieve["']/i.test(html))return null;
 const summary=/<[^>]+id=["']topSummaryAchievements["'][^>]*>\s*(\d+)\s+of\s+(\d+)/i.exec(html);
 if(!summary)return null;
 const parts=html.slice(html.indexOf('id="personalAchieve"')).split(/<div\b[^>]*class=["']achieveRow["'][^>]*>/i).slice(1),rows=[];
 const text=value=>decode(value.replace(/<[^>]*>/g,'')).slice(0,1000);
 for(const part of parts.slice(0,1000)){
  const name=/<h3\b[^>]*>([\s\S]*?)<\/h3>/i.exec(part)?.[1];if(!name)return null;
  const icon=safeIcon(/<img\b[^>]*src=["']([^"']+)/i.exec(part)?.[1]);
  rows.push({id:require('node:crypto').createHash('sha256').update(text(name)).digest('hex').slice(0,20),name:text(name).slice(0,200),description:text(/<h5\b[^>]*>([\s\S]*?)<\/h5>/i.exec(part)?.[1]||''),icon,unlocked:/class=["']achieveUnlockTime["']/i.test(part)});
 }
 return rows.length===Number(summary[2])&&rows.filter(row=>row.unlocked).length===Number(summary[1])?rows:null;
}
async function publicXml(url,fetcher=fetch){
 const signal=AbortSignal.timeout(10000);
 let response;
 for(let hops=0;hops<4;hops++){
  const target=new URL(url);
  if(target.protocol!=='https:'||target.hostname!=='steamcommunity.com'||target.username||target.password||target.port)throw Error('Origem Steam inválida');
  response=await fetcher(target.href,{redirect:'manual',signal,headers:{Accept:'text/html,application/xml,text/xml'}});
  if(![301,302,303,307,308].includes(response.status))break;
  await response.body?.cancel();const next=response.headers.get('location');if(!next)throw Error('Redirecionamento inválido');url=new URL(next,target).href;response=null;
 }
 if(!response?.ok)throw Error('Steam indisponível');
 if(Number(response.headers.get('content-length'))>MAX)throw Error('Resposta extensa');
 const reader=response.body.getReader();let size=0;const chunks=[];
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX)throw Error('Resposta extensa');chunks.push(Buffer.from(value));}}finally{await reader.cancel().catch(()=>{});}
 return Buffer.concat(chunks).toString('utf8');
}
const field=(object,key)=>object?.[Object.keys(object||{}).find(k=>k.toLowerCase()===key.toLowerCase())];
function createSteamProfile({parseVdf,readFile=async file=>{const stat=await fs.stat(file);if(stat.size>MAX)throw Error('Arquivo extenso');return fs.readFile(file,'utf8');},fetchXml=publicXml,now=Date.now}){
 const cache=new Map(),pending=new Map();
 return {async read(record,options={}){
  if(!/^[1-9]\d{0,9}$/.test(record.appId))return {message:'Jogo Steam indisponível.'};
  let owner=null,root='';
  for(const cacheRoot of (record.cacheRoots||[]).slice(0,8)){
   const client=path.resolve(cacheRoot,'../..');
   try{const users=field(parseVdf(await readFile(path.join(client,'config','loginusers.vdf'))),'users')||{};const account=Object.entries(users).filter(([id])=>/^7656119\d{10}$/.test(id)).sort((a,b)=>Number(field(b[1],'MostRecent')||0)-Number(field(a[1],'MostRecent')||0)||Number(field(b[1],'Timestamp')||0)-Number(field(a[1],'Timestamp')||0))[0];if(account){owner=account[0];root=client;break;}}catch{}
  }
  if(!owner)return {message:'Entre na Steam neste computador para consultar seu perfil.'};
  const key=owner+':'+record.appId,previous=cache.get(key);if(previous&&!options.refresh&&now()-previous.at<(previous.value.achievements?60000:15000))return previous.value;if(pending.has(key))return pending.get(key);
  const request=(async()=>{
   const profileUrl='https://steamcommunity.com/profiles/'+owner;
   const result={profileUrl};
   try{const account=(BigInt(owner)-76561197960265728n).toString();const local=parseVdf(await readFile(path.join(root,'userdata',account,'config','localconfig.vdf')));const minutes=Number(['UserLocalConfigStore','Software','Valve','Steam','apps',record.appId,'Playtime'].reduce((value,key)=>field(value,key),local));if(Number.isFinite(minutes)&&minutes>=0)result.playtimeMinutes=minutes;}catch{}
   try{const page=await fetchXml(profileUrl+'/stats/'+record.appId+'/achievements/?l=english');const achievements=parseAchievementPage(page)||parseAchievements(page);if(achievements)result.achievements=achievements;else result.message='A Steam não disponibilizou as conquistas. Confira se seu perfil e detalhes dos jogos são públicos.';}catch{result.message='Não foi possível consultar as conquistas na Steam agora.';}
   cache.set(key,{at:now(),value:result});if(cache.size>64)cache.delete(cache.keys().next().value);return result;
  })().finally(()=>pending.delete(key));pending.set(key,request);return request;
 }};
}
module.exports={createSteamProfile,parseAchievements,parseAchievementPage,publicXml};
