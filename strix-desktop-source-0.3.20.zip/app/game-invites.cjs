'use strict';
const {trustedFrame}=require('./desktop-controls.cjs');
function lobbyUri(value){
 const g=value?.game,j=value?.join;
 const id=v=>typeof v==='string'&&/^[1-9]\d{16,19}$/.test(v)&&BigInt(v)<=18446744073709551615n;
 if(!g||typeof g.name!=='string'||!g.name.trim()||g.name.length>80||typeof g.appId!=='string'||!/^[1-9]\d{0,9}$/.test(g.appId)||!j||Object.keys(j).some(k=>!['kind','appId','lobbyId','hostId'].includes(k))||j.kind!=='steam-lobby'||j.appId!==g.appId||!id(j.lobbyId)||!id(j.hostId))throw Error('Convite de grupo inválido.');
 return `steam://joinlobby/${j.appId}/${j.lobbyId}/${j.hostId}`;
}
function installGameInvites(electron,win,origin){
 let last=0,busy=false;
 electron.ipcMain.handle('strix:join-game-lobby',async(event,value)=>{
  if(win.isDestroyed()||!trustedFrame(event,win.webContents,origin))throw Error('Origem não autorizada.');
  const uri=lobbyUri(value);if(busy||Date.now()-last<2000)return {ok:false,error:'A entrada no grupo já foi solicitada. Aguarde um instante.'};
  busy=true;last=Date.now();try{await electron.shell.openExternal(uri);return {ok:true};}catch{return {ok:false,error:'Não foi possível abrir a Steam. Verifique se ela está instalada.'};}finally{busy=false;}
 });
 win.once('closed',()=>electron.ipcMain.removeHandler('strix:join-game-lobby'));
}
module.exports={lobbyUri,installGameInvites};
