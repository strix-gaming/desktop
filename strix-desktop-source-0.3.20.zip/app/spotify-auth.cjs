const http=require('node:http');
const {trustedFrame}=require('./desktop-controls.cjs');
function validRequest(value){return value&&/^[a-f0-9]{32}$/i.test(value.clientId)&&/^[A-Za-z0-9_-]{43,128}$/.test(value.state)&&/^[A-Za-z0-9_-]{43}$/.test(value.challenge);}
function authorizeSpotify(value,openExternal){
 if(!validRequest(value))return {promise:Promise.reject(Error('Pedido Spotify inválido')),cancel:()=>{}};
 let cancel=()=>{};
 const promise=new Promise((resolve,reject)=>{
  let finished=false,timer;const server=http.createServer((req,res)=>{
   const url=new URL(req.url,'http://127.0.0.1');
   if(req.method!=='GET'||url.pathname!=='/spotify/callback'){res.writeHead(404);res.end();return;}
   if(url.searchParams.get('state')!==value.state){res.writeHead(400);res.end('Estado invalido.');return;}
   const code=url.searchParams.get('code'),error=url.searchParams.get('error');
   res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'"});res.end('Pode voltar para a Strix.');
   finish(error||!code?Error('Autorização cancelada.'):null,{code,redirectUri:'http://127.0.0.1:'+server.address().port+'/spotify/callback'});
  });
  const finish=(error,result)=>{if(finished)return;finished=true;clearTimeout(timer);server.close();server.closeAllConnections?.();error?reject(error):resolve(result);};cancel=()=>finish(Error('Autorização cancelada.'));
  server.on('error',()=>finish(Error('Não foi possível abrir a vinculação.')));
  server.listen(0,'127.0.0.1',()=>{if(finished){server.close();return;}const url=new URL('https://accounts.spotify.com/authorize');url.search=new URLSearchParams({client_id:value.clientId,response_type:'code',redirect_uri:'http://127.0.0.1:'+server.address().port+'/spotify/callback',scope:'user-read-private user-read-currently-playing',state:value.state,code_challenge_method:'S256',code_challenge:value.challenge,show_dialog:'true'}).toString();Promise.resolve(openExternal(url.href)).catch(()=>finish(Error('Não foi possível abrir o Spotify.')));});
  timer=setTimeout(()=>finish(Error('A vinculação expirou. Tente novamente.')),180000);timer.unref?.();
 });return {promise,cancel:()=>cancel()};
}
function installSpotifyAuth(electron,win,origin){let active;const authorized=e=>!win.isDestroyed()&&trustedFrame(e,win.webContents,origin);electron.ipcMain.handle('strix:spotify-authorize',async(e,value)=>{if(!authorized(e))throw Error('Origem não autorizada');if(active)throw Error('Já existe uma vinculação aberta.');active=authorizeSpotify(value,url=>electron.shell.openExternal(url));try{const result=await active.promise;if(!authorized(e))throw Error('Origem não autorizada');return result;}finally{active=undefined;}});win.once('closed',()=>{active?.cancel();electron.ipcMain.removeHandler('strix:spotify-authorize');});}
module.exports={validRequest,authorizeSpotify,installSpotifyAuth};
