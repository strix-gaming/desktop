const allowed=new Set(['shared.fastly.steamstatic.com','shared.akamai.steamstatic.com','shared.cloudflare.steamstatic.com','cdn.akamai.steamstatic.com','cdn.cloudflare.steamstatic.com','cdn.fastly.steamstatic.com']);
function steamImage(value,appId){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&allowed.has(u.hostname)&&new RegExp('^/(?:store_item_assets/steam|steam)/apps/'+appId+'/').test(u.pathname)?u.href:undefined;}catch{return undefined;}}
function createSteamArtwork(fetcher=fetch,now=Date.now){const cache=new Map(),pending=new Map();return async appId=>{
 if(!/^[1-9]\d{0,9}$/.test(appId))return {};
 const previous=cache.get(appId);if(previous&&previous.expires>now())return previous.value;if(pending.has(appId))return pending.get(appId);
 const task=(async()=>{let value={};try{
  const response=await fetcher('https://store.steampowered.com/api/appdetails?appids='+appId+'&filters=basic',{redirect:'error',signal:AbortSignal.timeout(6000)});
  if(!response.ok||Number(response.headers.get('content-length'))>2000000)throw Error('Unavailable');
  const reader=response.body.getReader(),chunks=[];let length=0;try{while(true){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>2000000)throw Error('Large');chunks.push(Buffer.from(value));}}finally{await reader.cancel().catch(()=>{});}
  const item=JSON.parse(Buffer.concat(chunks).toString('utf8'))[appId];if(item?.success&&String(item.data?.steam_appid)===appId)value={coverUrl:steamImage(item.data.header_image,appId),heroUrl:steamImage(item.data.background_raw,appId)};
 }catch{}cache.set(appId,{value,expires:now()+(value.coverUrl?3600000:60000)});while(cache.size>256)cache.delete(cache.keys().next().value);return value;})().finally(()=>pending.delete(appId));pending.set(appId,task);return task;
};}
module.exports={createSteamArtwork,steamImage};
