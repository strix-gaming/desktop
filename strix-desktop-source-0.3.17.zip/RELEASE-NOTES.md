Strix Desktop 0.3.17

- Corrige a consulta de conquistas Steam usando a página atual de progresso pessoal.
- Recupera capas oficiais da Steam quando os caminhos antigos deixam de funcionar.
- Prepara autorização Spotify via PKCE no navegador do sistema, sem senha ou segredo dentro da Strix. A ativação da conta depende do cadastro da aplicação Spotify.
- Mantém detecção e fechamento normal de jogos da versão 0.3.16.

Instalador de teste para Windows x64, ainda sem assinatura digital.
