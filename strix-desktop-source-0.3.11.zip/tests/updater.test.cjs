const {test}=require('node:test');const assert=require('node:assert/strict');const {EventEmitter}=require('node:events');const {installUpdater}=require('../app/updater.cjs');
test('updates defer download during calls, require explicit restart and reject foreign IPC',async()=>{
 const ipc=new EventEmitter(),handlers=new Map();ipc.handle=(k,v)=>handlers.set(k,v);ipc.removeHandler=k=>handlers.delete(k);
 const win=new EventEmitter(),wc=new EventEmitter(),frame={url:'https://strix-gaming.web.app/app'};wc.isDestroyed=()=>false;wc.mainFrame=frame;wc.getURL=()=>frame.url;wc.send=()=>{};win.webContents=wc;win.isDestroyed=()=>false;
 const updater=new EventEmitter();let downloads=0,installs=0;updater.checkForUpdates=async()=>{};updater.downloadUpdate=async()=>{downloads++;};updater.quitAndInstall=(silent,reopen)=>{assert.equal(silent,true);assert.equal(reopen,true);installs++;};
 installUpdater({app:{isPackaged:true,getVersion:()=> '0.3.3'},ipcMain:ipc},win,'https://strix-gaming.web.app',updater);
 const event={sender:wc,senderFrame:frame};const invoke=handlers.get('strix:updater');
 ipc.emit('strix:call-state',event,{connected:true});updater.emit('update-available',{version:'0.3.4'});assert.equal(downloads,0);
 await assert.rejects(invoke({...event,senderFrame:{url:'https://bad.test'}},'install'));
 ipc.emit('strix:call-state',event,{connected:false});await new Promise(setImmediate);assert.equal(downloads,1);
 updater.emit('update-downloaded',{version:'0.3.4'});assert.equal(installs,0);assert.equal((await invoke(event,'status')).status,'ready');
 ipc.emit('strix:call-state',event,{connected:true});await assert.rejects(invoke(event,'install'));
 ipc.emit('strix:call-state',event,{connected:false});await invoke(event,'install');await new Promise(setImmediate);assert.equal(installs,1);assert.equal(updater.autoInstallOnAppQuit,false);win.emit('closed');
});

function fixture(t){
 const ipc=new EventEmitter(),handlers=new Map();ipc.handle=(key,handler)=>handlers.set(key,handler);ipc.removeHandler=key=>handlers.delete(key);
 const win=new EventEmitter(),wc=new EventEmitter(),frame={url:'https://strix-gaming.web.app/app'},events=[];
 wc.isDestroyed=()=>false;wc.mainFrame=frame;wc.getURL=()=>frame.url;wc.send=(name,value)=>events.push({name,value});win.webContents=wc;win.isDestroyed=()=>false;
 const updater=new EventEmitter();let installs=0;updater.checkForUpdates=async()=>updater.emit('update-not-available');updater.downloadUpdate=async()=>{};updater.quitAndInstall=(silent,reopen)=>{assert.equal(silent,true);assert.equal(reopen,true);installs++;};
 installUpdater({app:{isPackaged:true,getVersion:()=> '0.3.7'},ipcMain:ipc},win,'https://strix-gaming.web.app',updater);
 const event={sender:wc,senderFrame:frame};t.after(()=>win.emit('closed'));
 return {updater,win,wc,events,invoke:action=>handlers.get('strix:updater')(event,action),call:value=>ipc.emit('strix:call-state',event,value),installs:()=>installs};
}
const settle=()=>new Promise(setImmediate);
test('an active download cancels for a call and resumes after a short call finishes',async t=>{
 const f=fixture(t),tokens=[];let finish;
 f.updater.downloadUpdate=token=>{tokens.push(token);return new Promise((resolve,reject)=>{finish=resolve;token.onCancel(()=>reject(Error('cancelled')));});};
 f.updater.emit('update-available',{version:'0.3.8'});assert.equal(tokens.length,1);
 f.call({connected:true});assert.equal(tokens[0].cancelled,true);assert.equal((await f.invoke('status')).status,'available');
 f.call({connected:false});await settle();assert.equal(tokens.length,2);assert.equal(tokens[1].cancelled,false);
 f.updater.emit('download-progress',{percent:150});assert.equal((await f.invoke('status')).progress,100);
 f.updater.emit('update-downloaded',{version:'0.3.8'});f.call({connected:true});finish();await settle();
 assert.equal((await f.invoke('status')).status,'ready');assert.equal(tokens[1].cancelled,false);assert.equal(f.installs(),0);
});
test('explicit restart is deduplicated and rechecks a call that starts after the click',async t=>{
 const f=fixture(t);f.updater.emit('update-downloaded',{version:'0.3.8'});
 const aborted=Promise.allSettled([f.invoke('install'),f.invoke('install')]);f.call({connected:false,busy:true});
 const results=await aborted;assert.ok(results.every(result=>result.status==='rejected'&&/chamada/.test(result.reason.message)));assert.equal(f.installs(),0);
 assert.equal((await f.invoke('status')).status,'ready');assert.match((await f.invoke('status')).message,/chamada/);
 await assert.rejects(f.invoke('install'),/chamada/);
 f.call({connected:false});await Promise.all([f.invoke('install'),f.invoke('install')]);assert.equal(f.installs(),1);assert.equal((await f.invoke('status')).message,'');
});
test('restart failure rejects the pending IPC request and allows a second explicit attempt',async t=>{
 const f=fixture(t);f.updater.emit('update-downloaded',{version:'0.3.8'});let attempts=0;
 f.updater.quitAndInstall=()=>{if(++attempts===1)throw Error('installer unavailable');};
 await assert.rejects(f.invoke('install'),/Não foi possível reiniciar/);assert.equal(attempts,1);
 assert.equal((await f.invoke('status')).status,'ready');assert.match(f.events.at(-1).value.message,/Não foi possível reiniciar/);
 await f.invoke('install');assert.equal(attempts,2);assert.equal((await f.invoke('status')).message,'');
});
test('an updater error after restart acknowledgement releases native install state without losing the ready download',async t=>{
 const f=fixture(t);f.updater.emit('update-downloaded',{version:'0.3.8'});
 await f.invoke('install');assert.equal(f.installs(),1);f.updater.emit('error',Error('installer spawn failed'));
 assert.equal((await f.invoke('status')).status,'ready');assert.match((await f.invoke('status')).message,/Não foi possível reiniciar/);
 await f.invoke('install');assert.equal(f.installs(),2);
});
test('renderer replacement releases stale call state and resends the update snapshot',async t=>{
 const f=fixture(t);let downloads=0;f.updater.downloadUpdate=async()=>{downloads++;f.updater.emit('update-downloaded',{version:'0.3.8'});};
 f.call({connected:true});f.updater.emit('update-available',{version:'0.3.8'});assert.equal(downloads,0);
 f.wc.emit('did-start-navigation',{},'https://strix-gaming.web.app/app',false,true);await settle();assert.equal(downloads,1);
 const count=f.events.length;f.wc.emit('did-finish-load');assert.equal(f.events.length,count+1);assert.equal(f.events.at(-1).value.status,'ready');
 f.call({connected:true});f.wc.emit('render-process-gone');await f.invoke('install');await settle();assert.equal(f.installs(),1);
});
test('metadata checks work during calls without downloading or retaining an old error',async t=>{
 const f=fixture(t);let checks=0,downloads=0;f.updater.checkForUpdates=async()=>{checks++;f.updater.emit('update-available',{version:'0.3.8'});};f.updater.downloadUpdate=async()=>{downloads++;};
 f.updater.emit('error',Error('offline'));f.call({connected:true});await f.invoke('check');assert.equal(checks,1);assert.equal(downloads,0);
 assert.equal((await f.invoke('status')).status,'available');assert.doesNotMatch((await f.invoke('status')).message,/indisponível/);
 f.call({connected:false});await settle();assert.equal(downloads,1);assert.equal(f.updater.autoInstallOnAppQuit,false);
});
