# Strix Desktop 0.3.11

A Home agora pode detectar os jogos Steam e os aplicativos instalados neste Windows. A versão anterior recebia a nova interface, mas ainda não possuía a integração nativa da biblioteca.

- Descobre jogos nas bibliotecas Steam locais e aplicativos pelos atalhos do Menu Iniciar.
- Permite pesquisar, atualizar a lista e abrir um item por ação do usuário. A detecção não abre programas nem envia o inventário ao servidor.
- Inclui a correção para liberar uma nova tentativa quando a instalação de uma atualização falha.
- Mantém as correções anteriores de áudio, chamadas e transmissão.

O atualizador baixa fora de chamadas e a interface inicia a instalação quando a atualização está pronta e não há call ativa. Esta distribuição Windows x64 permanece uma versão de teste, sem assinatura Authenticode. Jogos de outros launchers e apps da Microsoft Store sem atalho executável ainda não são detectados.
