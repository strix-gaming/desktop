# Strix 0.3.5

- Seleção de telas e aplicativos integrada ao diálogo da transmissão, com duas etapas e transição lateral.
- Voltar, cancelar e tentar novamente sem abrir outra janela no Windows.
- Prévia das fontes gerada apenas ao abrir a seleção, com miniaturas menores.
- A interface também recebe volume de transmissão até 200%, ajustes de perfil, busca e carregamento.

Atualize e reinicie a Strix para usar a seleção integrada. A atualização aguarda o fim da chamada.
