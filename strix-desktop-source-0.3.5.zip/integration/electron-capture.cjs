// Runs the actual Electron callback and sandbox, not a callback mock.
const {app,BrowserWindow,ipcMain,nativeImage}=require('electron');
const http=require('node:http'),path=require('node:path'),assert=require('node:assert/strict');
const {createCaptureController}=require('../app/capture-controller.cjs');
const {captureCapabilities}=require('../app/capture-audio.cjs');
const errors=[];process.on('uncaughtException',e=>{errors.push(e.message);console.error(e);});process.on('unhandledRejection',e=>{errors.push(String(e));console.error(e);});
const deadline=setTimeout(()=>{console.error('Electron regression test timed out');app.exit(1);},30000);
app.whenReady().then(async()=>{
 const server=http.createServer((req,res)=>res.end('<!doctype html><title>Strix capture regression</title>'));
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
 const caps=captureCapabilities(app);assert.equal(caps.supported,process.platform==='win32','Windows build must include its audio helper');
 const owner=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,preload:path.resolve(__dirname,'../app/preload.cjs'),additionalArguments:[`--strix-platform=${process.platform}`,'--strix-version=0.3.5',`--strix-capture-audio=${caps.supported?1:0}`]}});
 owner.webContents.session.setPermissionRequestHandler((_wc,_p,cb)=>cb(true));owner.webContents.session.setPermissionCheckHandler(()=>true);
 let picker,opened=0;class Picker extends BrowserWindow{constructor(opts){super({...opts,show:false});picker=this;opened++;setImmediate(()=>{if(!this.isDestroyed())this.close();});}}
 const controller=createCaptureController({BrowserWindow:Picker,ipcMain,desktopCapturer:{getSources:async()=>[{id:'screen:1:0',name:'Test source',thumbnail:nativeImage.createEmpty()}]}},owner,origin);
 owner.webContents.session.setDisplayMediaRequestHandler(controller.handler,{useSystemPicker:false});
 await owner.loadURL(origin);
 const bridge=await owner.webContents.executeJavaScript('({version:window.strixDesktop?.version,audio:window.strixDesktop?.nativeCaptureAudio,platform:window.strixDesktop?.platform})');
 assert.equal(bridge.version,'0.3.5');assert.equal(bridge.platform,process.platform);assert.equal(bridge.audio,caps.supported);console.log('Real sandbox bridge:',JSON.stringify(bridge));
 for(let i=0;i<3;i++){
 const result=await owner.webContents.executeJavaScript(`(async()=>{let cancelled=false;const off=window.strixDesktop.onCaptureCancelled(()=>cancelled=true);try{const s=await navigator.mediaDevices.getDisplayMedia({video:true,audio:true});s.getTracks().forEach(t=>t.stop());return {ok:true};}catch(e){return {ok:false,name:e.name,cancelled};}finally{off();}})()`,true);
 assert.equal(result.ok,false);assert.equal(result.cancelled,true);console.log('Close X then retry',i+1,JSON.stringify(result));
 }
 assert.equal(opened,3);
 if(process.platform==='win32')for(let i=0;i<3;i++){
 const result=await owner.webContents.executeJavaScript(`(async()=>{const d=window.strixDesktop;let sources=0;const off=d.onCaptureSources(async value=>{sources=value.sources.length;await d.selectCaptureSource(value.requestId,null);});try{if(!await d.prepareCapture())throw Error('prepare failed');await navigator.mediaDevices.getDisplayMedia({video:true});return {ok:true};}catch(e){return {ok:false,sources};}finally{off();}})()`,true);
 assert.equal(result.ok,false);assert.equal(result.sources,1);assert.equal(opened,3);console.log('Inline cancel and retry without popup',i+1);
 }
 assert.deepEqual(errors,[]);owner.destroy();server.close();clearTimeout(deadline);console.log('PASS: native X cancellation, repeated retry, sandbox capability');app.exit(0);
}).catch(error=>{console.error(error);app.exit(1);});
