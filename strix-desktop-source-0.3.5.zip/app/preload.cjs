const {contextBridge, ipcRenderer} = require('electron');
// Never expose IPC itself, Electron objects, paths, or arbitrary channel names.
if (process.isMainFrame) {
  const argument=name=>process.argv.find(value=>value.startsWith('--strix-'+name+'='))?.split('=').slice(1).join('=');
  const platform=argument('platform')||process.platform;
  const audioSupported=argument('capture-audio')==='1';
  contextBridge.exposeInMainWorld('strixDesktop', Object.freeze({
    version: argument('version')||'0.3.5',
    platform,
    captureAudioReason:argument('audio-reason')||'',
    getCaptureCapabilities:()=>ipcRenderer.invoke('strix:capture-capabilities'),
    onCaptureCancelled(callback){const listener=()=>callback();ipcRenderer.on('strix:capture-cancelled',listener);return()=>ipcRenderer.removeListener('strix:capture-cancelled',listener);},
    updateStatus:()=>ipcRenderer.invoke('strix:updater','status'),
    checkUpdate:()=>ipcRenderer.invoke('strix:updater','check'),
    installUpdate:()=>ipcRenderer.invoke('strix:updater','install'),
    onUpdate(callback){const listener=(_event,value)=>callback(value);ipcRenderer.on('strix:update-state',listener);return()=>ipcRenderer.removeListener('strix:update-state',listener);},
    windowChrome:platform==='win32'?'overlay':undefined,
    cancelCapture:()=>ipcRenderer.invoke('strix:cancel-capture'),
    ...(platform==='win32'?{
      prepareCapture:()=>ipcRenderer.invoke('strix:prepare-capture'),
      selectCaptureSource:(requestId,id)=>typeof requestId==='string'&&(id===null||typeof id==='string')?ipcRenderer.invoke('strix:select-capture',requestId,id):Promise.resolve(false),
      onCaptureSources(callback){if(typeof callback!=='function')return()=>{};const listener=(_event,value)=>callback(value);ipcRenderer.on('strix:capture-sources',listener);return()=>ipcRenderer.removeListener('strix:capture-sources',listener);}
    }:{}),
    nativeCaptureAudio:audioSupported,
    startCaptureAudio:()=>ipcRenderer.invoke('strix:capture-audio-start'),
    stopCaptureAudio:id=>ipcRenderer.invoke('strix:capture-audio-stop',id),
    onCaptureAudio(callback){
      const data=(_event,value)=>{try{callback(value);}finally{ipcRenderer.send('strix:capture-audio-ack',value.id);}};
      const ended=(_event,id)=>callback({id,ended:true});
      ipcRenderer.on('strix:capture-audio-data',data);ipcRenderer.on('strix:capture-audio-ended',ended);
      return()=>{ipcRenderer.removeListener('strix:capture-audio-data',data);ipcRenderer.removeListener('strix:capture-audio-ended',ended);};
    },
    reviewPermissions:()=>ipcRenderer.invoke('strix:review-permissions'),
    getStartup:()=>ipcRenderer.invoke('strix:startup'),
    setStartup:value=>typeof value==='boolean'?ipcRenderer.invoke('strix:startup',value):Promise.reject(new Error('Valor inválido')),
    updateCallState(value) {
      if (!value || typeof value !== 'object') return;
      ipcRenderer.send('strix:call-state', {
        connected:value.connected === true, mic:value.mic === true, deaf:value.deaf === true,
        canPublish:value.canPublish === true, busy:value.busy === true
      });
    },
    onCommand(callback) {
      if (typeof callback !== 'function') return () => {};
      const listener = (_event, command) => {
        if (['microphone','deafen','leave'].includes(command)) callback(command);
      };
      ipcRenderer.on('strix:call-command', listener);
      return () => ipcRenderer.removeListener('strix:call-command', listener);
    },
    onVisibility(callback) {
      if (typeof callback !== 'function') return () => {};
      const listener = (_event, visible) => callback(visible === true);
      ipcRenderer.on('strix:window-visible', listener);
      return () => ipcRenderer.removeListener('strix:window-visible', listener);
    }
  }));
}
