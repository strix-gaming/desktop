const path=require('node:path');
const {randomUUID}=require('node:crypto');
const {trustedFrame}=require('./desktop-controls.cjs');
// One completion per Chromium request, including close-before-load and failed load.
function createCaptureController({BrowserWindow,desktopCapturer,ipcMain},win,origin,onGrant=()=>{},platform=process.platform){
 let pending=null,prepared=null;
 const isOrigin=url=>{try{return new URL(url).origin===origin;}catch{return false;}};
 const trusted=request=>!win.isDestroyed()&&request.frame===win.webContents.mainFrame&&request.userGesture&&isOrigin(request.securityOrigin);
 const cancel=()=>{prepared=null;pending?.finish(null);};
 const handler=async(request,callback)=>{
  if(pending||!trusted(request)){callback(null);return;}
  const inline=platform==='win32'&&prepared?.frame===request.frame&&Date.now()-prepared.at<15000;prepared=null;
  let picker=null,done=false,choose,timeout;
  const requestFrame=request.frame;
  const job={finish(id){
   if(done)return;done=true;clearTimeout(timeout);if(choose)ipcMain.removeListener('strix:choose-source',choose);
   if(pending===job)pending=null;
   const selected=!win.isDestroyed()&&requestFrame===win.webContents.mainFrame&&isOrigin(win.webContents.getURL())?job.sources.find(s=>s.id===id):undefined;
   try{if(selected)onGrant({audio:request.audioRequested===true});else if(!win.isDestroyed()&&requestFrame===win.webContents.mainFrame)win.webContents.send('strix:capture-cancelled');callback(selected?{video:selected}:null);}catch(error){console.error('Capture completion failed:',error.message);}
   if(picker&&!picker.isDestroyed())picker.destroy();
  },sources:[],id:randomUUID(),inline};
  pending=job;timeout=setTimeout(()=>job.finish(null),120000);
  try{
   job.sources=await desktopCapturer.getSources({types:['screen','window'],thumbnailSize:{width:320,height:180},fetchWindowIcons:true});
   if(done)return;
   if(win.isDestroyed()||requestFrame!==win.webContents.mainFrame){job.finish(null);return;}
   if(inline){win.webContents.send('strix:capture-sources',{requestId:job.id,sources:job.sources.map(s=>({id:s.id,name:s.name,kind:s.id.startsWith('screen:')?'screen':'window',thumbnail:s.thumbnail.toDataURL(),icon:s.appIcon?.toDataURL()||''}))});return;}
   picker=new BrowserWindow({width:980,height:700,minWidth:680,minHeight:480,parent:win,modal:true,...(platform==='win32'?{titleBarStyle:'hidden',titleBarOverlay:{color:'#08090d',symbolColor:'#d4d8e4',height:36}}:{}),title:'Strix — compartilhar tela',backgroundColor:'#08090d',webPreferences:{preload:path.join(__dirname,'picker-preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true}});
   choose=(event,id)=>{if(event.sender!==picker.webContents||event.senderFrame!==picker.webContents.mainFrame)return;job.finish(typeof id==='string'?id:null);};
   ipcMain.on('strix:choose-source',choose);
   picker.once('closed',()=>job.finish(null));
   picker.webContents.once('did-finish-load',()=>{if(!done&&!picker.isDestroyed())picker.webContents.send('strix:sources',job.sources.map(s=>({id:s.id,name:s.name,kind:s.id.startsWith('screen:')?'screen':'window',thumbnail:s.thumbnail.toDataURL(),icon:s.appIcon?.toDataURL()||''})));});
   await picker.loadFile(path.join(__dirname,'picker.html'));
  }catch{job.finish(null);}
 };
 ipcMain.handle('strix:prepare-capture',event=>{if(platform!=='win32'||pending||!trustedFrame(event,win.webContents,origin))return false;prepared={frame:event.senderFrame,at:Date.now()};return true;});
 ipcMain.handle('strix:select-capture',(event,requestId,id)=>{if(!trustedFrame(event,win.webContents,origin)||!pending?.inline||pending.id!==requestId||!(id===null||typeof id==='string'&&pending.sources.some(s=>s.id===id)))return false;pending.finish(id);return true;});
 ipcMain.handle('strix:cancel-capture',event=>{if(!trustedFrame(event,win.webContents,origin))return false;cancel();return true;});
 win.webContents.on('did-start-navigation',(_event,_url,_inPlace,isMainFrame)=>{if(isMainFrame)cancel();});
 win.on('closed',()=>{cancel();ipcMain.removeHandler('strix:cancel-capture');ipcMain.removeHandler('strix:prepare-capture');ipcMain.removeHandler('strix:select-capture');});
 return {handler,cancel};
}
module.exports={createCaptureController};
