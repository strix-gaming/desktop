const {trustedFrame}=require('./desktop-controls.cjs');
// Already shipped as electron-updater's runtime dependency; no new download service.
const {CancellationToken}=require('builder-util-runtime');
function installUpdater(electron,win,origin,updater){
 const {app,ipcMain}=electron;
 const contents=win.webContents;
 let state={status:'idle',version:app.getVersion(),progress:0};
 let connected=false,checking=false,downloading=false,installing=false,disposed=false,downloadToken=null,installRequest=null;
 const send=patch=>{
  if(disposed)return;
  state={...state,...patch};
  if(!win.isDestroyed()&&!contents.isDestroyed()&&contents.getURL().startsWith(origin+'/'))contents.send('strix:update-state',state);
 };
 const waiting=()=>send({status:'available',progress:0,message:connected?'O download continua depois da chamada.':''});
 const failedInstall=message=>{installing=false;installRequest=null;send({message});};
 updater.autoRunAppAfterInstall=true;updater.autoDownload=false;updater.autoInstallOnAppQuit=false;updater.allowPrerelease=true;updater.allowDowngrade=false;
 const download=async()=>{
  if(disposed||connected||downloading||installing||state.status!=='available')return;
  downloading=true;const token=new CancellationToken();downloadToken=token;
  send({status:'downloading',progress:0,message:''});
  try{await updater.downloadUpdate(token);}
  catch{if(!disposed){if(token.cancelled){if(state.status!=='ready')waiting();}else if(state.status!=='ready')send({status:'error',progress:0,message:'Não foi possível baixar a atualização. Tente novamente.'});}}
  finally{
   downloading=false;if(downloadToken===token)downloadToken=null;
   // A very short call may finish before the cancelled request settles.
   if(!disposed&&token.cancelled&&!connected&&state.status==='available')void download();
  }
 };
 const check=async()=>{
  if(disposed||checking||downloading||installing||state.status==='ready'||!app.isPackaged)return state;
  checking=true;send({status:'checking',progress:0,message:''});
  try{await updater.checkForUpdates();}
  catch{send({status:'error',message:'Não foi possível consultar atualizações.'});}
  finally{checking=false;}
  return state;
 };
 const listeners={
  'update-available':info=>{send({status:'available',version:info.version,progress:0,message:connected?'O download começa depois da chamada.':''});void download();},
  'update-not-available':()=>send({status:'current',version:app.getVersion(),progress:0,message:''}),
  'download-progress':info=>{if(!downloadToken?.cancelled&&state.status==='downloading')send({status:'downloading',progress:Math.max(0,Math.min(100,Math.round(Number(info.percent)||0)))});},
  'update-cancelled':()=>{if(state.status!=='ready')waiting();},
  'update-downloaded':info=>send({status:'ready',version:info.version,progress:100,message:''}),
  'error':()=>{if(disposed)return;if(installing)failedInstall('Não foi possível reiniciar. Tente novamente.');else if(!downloadToken?.cancelled&&state.status!=='ready')send({status:'error',message:'Atualização indisponível no momento. Sua Strix continua funcionando.'});}
 };
 for(const [event,listener]of Object.entries(listeners))updater.on(event,listener);
 const setCall=active=>{
  if(disposed)return;connected=active;
  if(connected&&downloadToken&&state.status!=='ready'){downloadToken.cancel();waiting();}
  else if(!connected)void download();
 };
 const call=(event,value)=>{if(trustedFrame(event,contents,origin))setCall(value?.connected===true||value?.busy===true);};
 const navigation=(_event,_url,inPlace,isMainFrame)=>{if(isMainFrame&&!inPlace)setCall(false);};
 const gone=()=>setCall(false);
 const loaded=()=>send({});
 ipcMain.on('strix:call-state',call);
 contents.on('did-start-navigation',navigation);
 contents.on('render-process-gone',gone);
 contents.on('did-finish-load',loaded);
 ipcMain.handle('strix:updater',async(event,action)=>{
  if(disposed||!trustedFrame(event,contents,origin))throw Error('Origem não autorizada.');
  if(action==='check')return check();
  if(action==='install'){
   if(connected)throw Error('Saia da chamada antes de reiniciar para atualizar.');
   if(state.status!=='ready')throw Error('A atualização ainda não está pronta.');
   if(!installing){
    installing=true;send({message:''});
    installRequest=new Promise((resolve,reject)=>setImmediate(()=>{
     if(disposed){installing=false;installRequest=null;reject(Error('A janela foi fechada antes de reiniciar.'));return;}
     if(connected){const message='Saia da chamada antes de reiniciar para atualizar.';failedInstall(message);reject(Error(message));return;}
     try{updater.quitAndInstall(true,true);if(!installing)throw Error('restart failed');resolve(state);}
     catch{const message='Não foi possível reiniciar. Tente novamente.';failedInstall(message);reject(Error(message));}
    }));
   }
   return installRequest||state;
  }
  return state;
 });
 // Metadata is small and safe to check in a call. Downloads still wait or pause.
 const first=setTimeout(()=>void check(),30000),repeat=setInterval(()=>void check(),4*60*60*1000);
 first.unref?.();repeat.unref?.();
 win.on('closed',()=>{
  if(disposed)return;disposed=true;downloadToken?.cancel();clearTimeout(first);clearInterval(repeat);
  ipcMain.removeHandler('strix:updater');ipcMain.removeListener('strix:call-state',call);
  contents.removeListener('did-start-navigation',navigation);contents.removeListener('render-process-gone',gone);contents.removeListener('did-finish-load',loaded);
  for(const [event,listener]of Object.entries(listeners))if(event!=='error')updater.removeListener(event,listener);
 });
 return {check};
}
module.exports={installUpdater};
