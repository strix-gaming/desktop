const path=require('node:path');
function openAppWindow(win,url,directory){
 // Paint an offline-capable local shell before the remote app can delay first paint.
 let navigating=false;
 const load=()=>{if(navigating||win.isDestroyed())return;navigating=true;win.show();void win.loadURL(url).catch(()=>{if(!win.isDestroyed())void win.loadFile(path.join(directory,'offline.html')).catch(()=>{});});};
 win.once('ready-to-show',load);
 void win.loadFile(path.join(directory,'startup.html')).catch(load);
 return load;
}
module.exports={openAppWindow};
