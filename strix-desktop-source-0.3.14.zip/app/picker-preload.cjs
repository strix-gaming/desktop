const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('strixCapture',{onSources:callback=>ipcRenderer.on('strix:sources',(_e,s)=>callback(s)),choose:id=>ipcRenderer.send('strix:choose-source',id)});
