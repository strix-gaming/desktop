const {trustedFrame}=require('./desktop-controls.cjs');
function installStartup({app,ipcMain},win,origin,platform=process.platform){
 const supported=platform==='win32'&&app.isPackaged;
 const options={path:process.execPath,args:[],name:'app.strix.desktop'};
 const read=()=>{if(!supported)return {supported:false,enabled:false};const state=app.getLoginItemSettings(options);return {supported:true,enabled:state.openAtLogin&&state.executableWillLaunchAtLogin!==false};};
 const receive=(event,value)=>{if(!trustedFrame(event,win.webContents,origin))throw Error('Origem não autorizada');if(value!==undefined){if(!supported||typeof value!=='boolean')throw Error('Configuração indisponível');app.setLoginItemSettings({...options,openAtLogin:value,enabled:value});}return read();};
 ipcMain.handle('strix:startup',receive);
 win.on('closed',()=>ipcMain.removeHandler('strix:startup'));
 return {read};
}
module.exports={installStartup};
