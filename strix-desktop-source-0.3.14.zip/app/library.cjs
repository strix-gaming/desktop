const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const {createHash} = require('node:crypto');
const {execFile} = require('node:child_process');
const {trustedFrame} = require('./desktop-controls.cjs');

const MAX_ITEMS = 256;
const MAX_METADATA = 1024 * 1024;
const ID_PATTERN = /^library:[a-f0-9]{32}$/;
const steamCoverUrl = appId => 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/' + appId + '/library_600x900.jpg';
const unavailable = () => ({ok:false, error:'Este item não está mais disponível. Atualize a biblioteca.'});
const cleanName = value => String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 100);
const keyFor = value => path.resolve(value).toLowerCase();
const localPath = value => typeof value === 'string' && path.isAbsolute(value) && !/^(?:\\\\|\/\/)/.test(value) && !value.includes('\0');
const inside = (root, file) => {const relative = path.relative(root, file); return relative === '' || (!relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative));};
const idFor = value => 'library:' + createHash('sha256').update(value).digest('hex').slice(0, 32);

// Valve's local KeyValues files are data, never JavaScript or executable commands.
function parseVdf(text) {
  if (typeof text !== 'string' || Buffer.byteLength(text) > MAX_METADATA) throw new Error('Metadata inválida');
  const tokens = []; let i = 0;
  while (i < text.length) {
    if (/\s/.test(text[i])) {i++; continue;}
    if (text.slice(i, i + 2) === '//') {while (i < text.length && text[i] !== '\n') i++; continue;}
    if (text[i] === '{' || text[i] === '}') {tokens.push({brace:text[i++]}); continue;}
    let value = '';
    if (text[i] === '"') {
      i++; let closed = false;
      while (i < text.length) {
        const c = text[i++];
        if (c === '"') {closed = true; break;}
        if (c === '\\' && ['\\', '"'].includes(text[i])) value += text[i++]; else value += c;
      }
      if (!closed) throw new Error('Metadata incompleta');
    } else {while (i < text.length && !/[\s{}]/.test(text[i])) value += text[i++];}
    tokens.push({value});
    if (tokens.length > 40000) throw new Error('Metadata extensa');
  }
  let cursor = 0;
  function object(depth, nested) {
    if (depth > 16) throw new Error('Metadata profunda');
    const result = Object.create(null);
    while (cursor < tokens.length) {
      const token = tokens[cursor++];
      if (token.brace === '}' && nested) return result;
      if (token.value === undefined) throw new Error('Metadata inválida');
      const next = tokens[cursor++];
      if (!next || next.brace === '}') throw new Error('Metadata inválida');
      result[token.value] = next.brace === '{' ? object(depth + 1, true) : next.value;
    }
    if (nested) throw new Error('Metadata incompleta');
    return result;
  }
  return object(0, false);
}

async function textFile(file) {
  const stat = await fs.stat(file);
  if (!stat.isFile() || stat.size > MAX_METADATA) throw new Error('Metadata inválida');
  return fs.readFile(file, 'utf8');
}
async function directory(value) {try {const real = await fs.realpath(value); return (await fs.stat(real)).isDirectory() ? real : null;} catch {return null;}}
async function entries(value) {try {return (await fs.readdir(value, {withFileTypes:true})).sort((a,b) => a.name.localeCompare(b.name));} catch {return [];}}

async function steamRecord(manifest, library, cacheRoots) {
  try {
    const match = /^appmanifest_([1-9]\d{0,9})\.acf$/i.exec(path.basename(manifest));
    if (!match || !inside(library, await fs.realpath(manifest))) return null;
    const state = parseVdf(await textFile(manifest)).AppState;
    if (!state || state.appid !== match[1] || !/^\d+$/.test(state.StateFlags || '') || !(Number(state.StateFlags) & 4)) return null;
    if (typeof state.installdir !== 'string' || !state.installdir || /[\\/]/.test(state.installdir) || ['.', '..'].includes(state.installdir)) return null;
    const common = path.join(library, 'steamapps', 'common');
    const installed = await directory(path.join(common, state.installdir));
    if (!installed || !inside(common, installed)) return null;
    const name = cleanName(state.name); if (!name) return null;
    return {id:idFor('steam:' + state.appid), name, kind:'game', source:'Steam', type:'steam', appId:state.appid, installed, manifest, library, cacheRoots};
  } catch {return null;}
}

async function discoverSteam(roots) {
  const clients = [];
  for (const root of roots.slice(0, 8)) {if (localPath(root)) {const real = await directory(root); if (real && !clients.includes(real)) clients.push(real);}}
  const libraries = new Set(clients);
  for (const root of clients) {
    try {
      const file = path.join(root, 'steamapps', 'libraryfolders.vdf');
      if (!inside(root, await fs.realpath(file))) continue;
      const folders = parseVdf(await textFile(file)).libraryfolders;
      for (const [index, data] of Object.entries(folders || {})) {
        if (!/^\d+$/.test(index)) continue;
        const candidate = typeof data === 'string' ? data : data?.path;
        if (!localPath(candidate) || libraries.size >= 16) continue;
        const real = await directory(candidate); if (real) libraries.add(real);
      }
    } catch {}
  }
  const records = new Map(); const cacheRoots = clients.map(root => path.join(root, 'appcache', 'librarycache'));
  for (const library of libraries) {
    for (const entry of (await entries(path.join(library, 'steamapps'))).slice(0, 2048)) {
      if (records.size >= MAX_ITEMS) break;
      if (!entry.isFile() || !/^appmanifest_[1-9]\d{0,9}\.acf$/i.test(entry.name)) continue;
      const record = await steamRecord(path.join(library, 'steamapps', entry.name), library, cacheRoots);
      if (record && !records.has(record.id)) records.set(record.id, record);
    }
  }
  return [...records.values()];
}

async function shortcutRecord(file, root, readShortcut) {
  try {
    const real = await fs.realpath(file); if (!inside(root, real) || !/\.lnk$/i.test(real)) return null;
    const stat = await fs.stat(real); if (!stat.isFile() || stat.size > MAX_METADATA) return null;
    const signature = createHash('sha256').update(await fs.readFile(real)).digest('hex');
    const details = await readShortcut(real);
    if (!details || !localPath(details.target) || !/\.exe$/i.test(details.target)) return null;
    // A shell/document shortcut is not an installed app entry.
    if (/^(?:unins\d*|uninstall|cmd|powershell|pwsh|wscript|cscript|mshta|rundll32|regsvr32|explorer|msiexec|schtasks|reg|regedit|wsl|bash)\.exe$/i.test(path.basename(details.target))) return null;
    const target = await fs.realpath(details.target);
    if (!(await fs.stat(target)).isFile()) return null;
    const name = cleanName(path.basename(file, path.extname(file)));
    if (!name || /\b(uninstall|desinstalar|uninstaller)\b/i.test(name)) return null;
    const args = typeof details.args === 'string' ? details.args : '';
    if (args.length > 4096) return null;
    const identity = keyFor(target) + '\0' + args;
    return {id:idFor('shortcut:' + identity), name, kind:'app', source:'Menu Iniciar', type:'shortcut', file:real, root, target, args, signature};
  } catch {return null;}
}

async function discoverApps(roots, platform, readShortcut) {
  const found = new Map(); let visited = 0;
  async function walk(folder, root, depth) {
    if (depth > (platform === 'darwin' ? 2 : 5) || visited >= 2048 || found.size >= MAX_ITEMS) return;
    for (const entry of await entries(folder)) {
      if (++visited > 2048 || found.size >= MAX_ITEMS) break;
      const file = path.join(folder, entry.name);
      // Do not follow links/junctions out of the explicit application roots.
      if (entry.isSymbolicLink()) continue;
      if (platform === 'darwin' && entry.isDirectory() && /\.app$/i.test(entry.name)) {
        const real = await directory(file);
        if (!real || !inside(root, real)) continue;
        try {if (!(await fs.stat(path.join(real, 'Contents', 'Info.plist'))).isFile()) continue;} catch {continue;}
        const id = idFor('app:' + keyFor(real));
        found.set(id, {id, name:cleanName(entry.name.slice(0,-4)), kind:'app', source:'Aplicativos', type:'app', file:real, root});
      } else if (platform === 'win32' && entry.isFile() && /\.lnk$/i.test(entry.name)) {
        const record = await shortcutRecord(file, root, readShortcut);
        if (record && !found.has(record.id)) found.set(record.id, record);
      } else if (entry.isDirectory()) {
        const real = await directory(file); if (real && inside(root, real)) await walk(real, root, depth + 1);
      }
    }
  }
  for (const value of roots.slice(0, 4)) {if (localPath(value)) {const root = await directory(value); if (root) await walk(root, root, 0);}}
  return [...found.values()];
}

function createLibrary({platform = process.platform, roots, readShortcut = () => null, getAssets = async () => ({}), openPath, openSteam, now = Date.now, cacheMs = 60000}) {
  const supported = platform === 'win32' || platform === 'darwin';
  let cache = null, pending = null, disposed = false, lastScanAt = -Infinity; const allowlist = new Map(), launching = new Set();
  async function scan() {
    if (!supported) return {supported:false, items:[], scannedAt:now()};
    const locations = typeof roots === 'function' ? await roots() : roots || {};
    const [games, apps] = await Promise.all([
      discoverSteam(locations.steam || []),
      discoverApps(platform === 'win32' ? locations.startMenu || [] : locations.applications || [], platform, readShortcut)
    ]);
    const records = [...games, ...apps].slice(0, MAX_ITEMS);
    const items = []; let assetBytes = 0;
    // Bounded concurrency and an aggregate image budget keep discovery inexpensive.
    let next = 0;
    await Promise.all(Array.from({length:Math.min(4, records.length)}, async () => {
      while (next < records.length && !disposed) {
        const record = records[next++];
        const item = {id:record.id, name:record.name, kind:record.kind, source:record.source};
        // Public identity only: artwork can load independently of scan/IPC budgets.
        if (record.type === 'steam') {item.steamAppId = record.appId; item.coverUrl = steamCoverUrl(record.appId);}
        try {
          const assets = await getAssets(record);
          for (const field of ['cover','icon']) {
            const value = assets?.[field];
            if (typeof value === 'string' && /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value) && value.length <= 600000 && assetBytes + value.length <= 8 * 1024 * 1024) {
              item[field] = value; assetBytes += value.length;
            }
          }
        } catch {}
        items.push(item);
      }
    }));
    if (disposed) return {supported, items:[], scannedAt:now()};
    allowlist.clear(); records.forEach(record => allowlist.set(record.id, record));
    items.sort((a,b) => a.name.localeCompare(b.name, 'pt-BR'));
    return {supported, items, scannedAt:now()};
  }
  return {
    async getLibrary(options) {
      if (disposed) return {supported, items:[], scannedAt:now()};
      if (pending) return structuredClone(await pending);
      const refresh = options?.refresh === true && now() - lastScanAt >= 2000;
      if (cache && !refresh && now() - cache.scannedAt < cacheMs) return structuredClone(cache);
      lastScanAt = now();
      pending = scan().then(result => {cache = result; return result;}).finally(() => {pending = null;});
      return structuredClone(await pending);
    },
    async launchLibraryItem(id, authorized = () => true) {
      if (disposed || !supported || typeof id !== 'string' || !ID_PATTERN.test(id) || !authorized()) return unavailable();
      const record = allowlist.get(id); if (!record || launching.has(id)) return unavailable();
      launching.add(id);
      try {
        let valid = false;
        if (record.type === 'steam') {
          const fresh = await steamRecord(record.manifest, record.library, record.cacheRoots);
          valid = fresh?.id === record.id && fresh.installed === record.installed;
        } else if (record.type === 'shortcut') {
          const fresh = await shortcutRecord(record.file, record.root, readShortcut);
          valid = fresh?.id === record.id && fresh.target === record.target && fresh.args === record.args && fresh.signature === record.signature;
        } else {
          const real = await directory(record.file);
          valid = real === record.file && inside(record.root, real) && (await fs.stat(path.join(real, 'Contents', 'Info.plist'))).isFile();
        }
        if (!valid || disposed || !authorized()) return unavailable();
        // Only main-process records supply a path or Steam app ID; the renderer supplies neither.
        if (record.type === 'steam') await openSteam(record.appId);
        else if (await openPath(record.file)) return {ok:false, error:'Não foi possível abrir este aplicativo.'};
        return {ok:true};
      } catch {return unavailable();}
      finally {launching.delete(id);}
    },
    dispose() {disposed = true; allowlist.clear(); cache = null;}
  };
}

async function registrySteamRoots(env) {
  const binary = path.join(env.SystemRoot || 'C:\\Windows', 'System32', 'reg.exe');
  const queries = [['HKCU\\Software\\Valve\\Steam', 'SteamPath'], ['HKLM\\SOFTWARE\\WOW6432Node\\Valve\\Steam', 'InstallPath'], ['HKLM\\SOFTWARE\\Valve\\Steam', 'InstallPath']];
  const results = await Promise.all(queries.map(([key, value]) => new Promise(resolve => {
    execFile(binary, ['query', key, '/v', value], {timeout:2000, maxBuffer:16384, windowsHide:true, shell:false}, (error, stdout) => {
      if (error) return resolve(null);
      const match = String(stdout).match(/REG_(?:EXPAND_)?SZ\s+([^\r\n]+)/i);
      resolve(match?.[1]?.trim() || null);
    });
  })));
  return results.filter(localPath);
}
async function defaultRoots(platform, app, env = process.env) {
  const home = app.getPath('home') || os.homedir();
  if (platform === 'darwin') return {steam:[path.join(home, 'Library', 'Application Support', 'Steam')], applications:['/Applications', path.join(home, 'Applications')]};
  if (platform !== 'win32') return {};
  const steam = ['ProgramFiles(x86)', 'ProgramFiles'].filter(key => env[key]).map(key => path.join(env[key], 'Steam'));
  steam.push(...await registrySteamRoots(env));
  const startMenu = [env.APPDATA, env.ProgramData || env.PROGRAMDATA].filter(Boolean).map(root => path.join(root, 'Microsoft', 'Windows', 'Start Menu', 'Programs'));
  return {steam:[...new Set(steam)], startMenu};
}

function assetLoader({app, nativeImage}) {
  const coverCache=path.join(app.getPath('userData'),'library-covers');
  async function localImage(file, root, width) {
    try {
      if (!inside(root, await fs.realpath(file))) return undefined;
      const stat = await fs.stat(file); if (!stat.isFile() || stat.size > 8 * 1024 * 1024) return undefined;
      const image = nativeImage.createFromPath(file); if (image.isEmpty()) return undefined;
      return image.resize({width, quality:'good'}).toDataURL();
    } catch {return undefined;}
  }
  return async record => {
    if (record.type !== 'steam') {
      let timer;
      try {
        const icon = await Promise.race([app.getFileIcon(record.type === 'shortcut' ? record.target : record.file, {size:'large'}), new Promise(resolve => {timer = setTimeout(() => resolve(null), 1500); timer.unref?.();})]);
        return icon && !icon.isEmpty() ? {icon:icon.resize({width:64, height:64, quality:'good'}).toDataURL()} : {};
      } finally {clearTimeout(timer);}
    }
    const assets = {};
    for (const root of record.cacheRoots) {
      for (const [field, names, width] of [
        ['cover', [`${record.appId}_library_600x900.jpg`, `${record.appId}_library_600x900_2x.jpg`, `${record.appId}_header.jpg`, `${record.appId}/library_600x900.jpg`, `${record.appId}/header.jpg`], 240],
        ['icon', [`${record.appId}_icon.jpg`, `${record.appId}_icon.png`, `${record.appId}/icon.jpg`], 64]
      ]) {
        if (assets[field]) continue;
        for (const name of names) {assets[field] = await localImage(path.join(root, name), root, width); if (assets[field]) break;}
      }
    }
    if(!assets.cover){
      for(const root of record.cacheRoots){
        const candidates=[...(await entries(root)).filter(entry=>entry.isFile()&&entry.name.startsWith(record.appId+'_')).map(entry=>entry.name),...(await entries(path.join(root,record.appId))).filter(entry=>entry.isFile()).map(entry=>path.join(record.appId,entry.name))];
        for(const name of candidates.filter(name=>/(?:library_600x900|header).*\.(?:jpg|png|webp)$/i.test(name)).slice(0,20)){
          assets.cover=await localImage(path.join(root,name),root,240);if(assets.cover)break;
        }
        if(assets.cover)break;
      }
    }
    if(!assets.cover)assets.cover=await localImage(path.join(coverCache,record.appId+'.jpg'),coverCache,240);
    // Remote artwork is fetched by the interface with bounded concurrency.
    // Discovery never waits on external CDNs or shares a global failure cooldown.
    return assets;
  };
}

function installLibrary(electron, win, origin, platform = process.platform, options = {}) {
  const {app, shell, ipcMain} = electron;
  const service = createLibrary({platform, roots:() => defaultRoots(platform, app), readShortcut:file => shell.readShortcutLink(file), getAssets:options.getAssets||assetLoader(electron), openPath:file => shell.openPath(file), openSteam:appId => shell.openExternal('steam://run/' + appId), ...options});
  const contents=win.webContents;
  const authorized = event => !win.isDestroyed() && trustedFrame(event, contents, origin);
  ipcMain.handle('strix:get-library', async (event, options) => {
    if (!authorized(event)) throw new Error('Origem não autorizada');
    const result = await service.getLibrary({refresh:options?.refresh === true});
    if (!authorized(event)) throw new Error('Origem não autorizada');
    return result;
  });
  ipcMain.handle('strix:launch-library', (event, id) => {
    if (!authorized(event)) throw new Error('Origem não autorizada');
    return service.launchLibraryItem(id, () => authorized(event));
  });
  win.once('closed', () => {service.dispose(); ipcMain.removeHandler('strix:get-library'); ipcMain.removeHandler('strix:launch-library');});
  return service;
}

module.exports = {parseVdf, createLibrary, installLibrary, assetLoader};
