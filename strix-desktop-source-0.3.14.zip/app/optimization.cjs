const {trustedFrame}=require('./desktop-controls.cjs');
const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {execFile}=require('node:child_process');
const HIGH='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c';
const GUID=/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/i;
const SETTINGS=Object.freeze({gameMode:'ms-settings:gaming-gamemode',graphics:'ms-settings:display-advancedgraphics',startup:'ms-settings:startupapps',power:'ms-settings:powersleep'});
function createPowerSession({run,load,save,remove}){
 let queue=Promise.resolve();const serial=fn=>{const next=queue.then(fn,fn);queue=next.catch(()=>{});return next;};
 const active=async()=>{const id=(await run(['/getactivescheme'])).match(GUID)?.[0]?.toLowerCase();if(!id)throw Error('Não foi possível ler o plano de energia.');return id;};
 const record=async()=>{const value=await load();if(!value)return null;if(!GUID.test(value.previous)||value.previous.length!==36||value.selected!==HIGH)throw Error('Registro de energia inválido.');return value;};
 const restore=async()=>{const saved=await record();if(saved){if(await active()===saved.selected)await run(['/setactive',saved.previous]);await remove();}return {active:false};};
 return {
  status:()=>serial(async()=>{const saved=await record();return {active:!!saved&&await active()===saved.selected};}),
  restore:()=>serial(restore),
  set:enabled=>serial(async()=>{if(typeof enabled!=='boolean')throw Error('Valor inválido.');if(!enabled)return restore();const saved=await record(),current=await active();if(saved&&current===HIGH)return {active:true};if(saved)await remove();if(current===HIGH)throw Error('O Windows já está em alto desempenho.');if(!(await run(['/list'])).toLowerCase().includes(HIGH))throw Error('Este PC não oferece o plano de alto desempenho. Use as opções de energia do Windows.');await save({previous:current,selected:HIGH});try{await run(['/setactive',HIGH]);}catch(error){await restore().catch(()=>{});throw error;}if(await active()!==HIGH)throw Error('O Windows não confirmou a mudança de energia.');return {active:true};})
 };
}
function installOptimization({app,ipcMain,shell,powerMonitor},win,origin,platform=process.platform){
 const supported=platform==='win32',file=path.join(app.getPath('userData'),'power-session.json');
 const run=args=>new Promise((resolve,reject)=>execFile(path.join(process.env.SystemRoot||'C:\\Windows','System32','powercfg.exe'),args,{windowsHide:true,timeout:8000,maxBuffer:32768},(error,stdout)=>error?reject(Error('O Windows não permitiu alterar o plano de energia.')):resolve(stdout)));
 const session=createPowerSession({run,load:async()=>{try{return JSON.parse(await fs.readFile(file,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw e;}},save:async value=>{await fs.writeFile(file+'.tmp',JSON.stringify(value),{mode:0o600});await fs.rename(file+'.tmp',file);},remove:()=>fs.rm(file,{force:true})});
 const ready=supported?session.restore().then(()=>null,error=>error.message):Promise.resolve(null);
 const handle=async(event,action,value)=>{if(!trustedFrame(event,win.webContents,origin))throw Error('Origem não autorizada');if(!supported)return {supported:false};const recoveryError=await ready;
  if(action==='status')return {supported:true,...await session.status(),totalMemory:os.totalmem(),freeMemory:os.freemem(),onBattery:powerMonitor.isOnBatteryPower(),recoveryError};
  if(action==='power'){if(typeof value!=='boolean')throw Error('Valor inválido');if(value&&powerMonitor.isOnBatteryPower())throw Error('Conecte o notebook à energia antes de ativar.');return {supported:true,...await session.set(value)};}
  if(action==='settings'){if(!Object.hasOwn(SETTINGS,value))throw Error('Ajuste inválido');await shell.openExternal(SETTINGS[value]);return {ok:true};}
  throw Error('Ação inválida');
 };
 ipcMain.handle('strix:optimization',handle);
 let exiting=false;const quit=event=>{if(!supported||exiting)return;event.preventDefault();exiting=true;void ready.then(()=>session.restore()).catch(()=>{}).finally(()=>app.quit());};app.on('before-quit',quit);
 win.on('closed',()=>{ipcMain.removeHandler('strix:optimization');app.removeListener('before-quit',quit);if(supported)void ready.then(()=>session.restore()).catch(()=>{});});
 return {session};
}
module.exports={createPowerSession,installOptimization,SETTINGS};
