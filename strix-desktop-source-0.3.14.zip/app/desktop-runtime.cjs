const path = require('node:path');
const fs = require('node:fs');
const {IDLE, sanitizeCall, trustedFrame, canCommand, windowBounds} = require('./desktop-controls.cjs');
let quitting = false;
function statePath(app) { return path.join(app.getPath('userData'), 'window-state.json'); }
function savedWindow(app, screen) {
  try {
    const saved = JSON.parse(fs.readFileSync(statePath(app), 'utf8'));
    return {...windowBounds(saved, screen.getAllDisplays()), maximized:saved.maximized === true};
  } catch { return windowBounds(null, []); }
}
function installDesktopControls(electron, win, origin) {
  const {app, ipcMain, Tray, Menu, nativeImage, globalShortcut} = electron;
  const contents=win.webContents;
  let disposed=false,state = {...IDLE}, tray, saveTimer;
  const lastShortcut=new Map();
  const shortcuts = [['CommandOrControl+Shift+M','microphone'], ['CommandOrControl+Shift+D','deafen']];
  const registered = new Set();
  const visible = () => !win.isDestroyed() && win.isVisible() && !win.isMinimized();
  const sendVisibility = () => {
    if (!disposed && !win.isDestroyed() && !contents.isDestroyed() && contents.getURL().startsWith(origin + '/'))
      contents.send('strix:window-visible', visible());
  };
  const show = () => {if (win.isDestroyed()) return; if (win.isMinimized()) win.restore(); win.show(); win.focus();};
  const command = (action,source='tray') => {
    if (disposed || contents.isDestroyed() || !canCommand(action, state) || win.isDestroyed() || source==='shortcut'&&!state.globalShortcuts) return;
    try {if (new URL(contents.getURL()).origin !== origin) return;} catch {return;}
    // Repeated OS events extend the quiet period; holding a gaming key never retoggles.
    if(source==='shortcut'){const now=Date.now(),last=lastShortcut.get(action);lastShortcut.set(action,now);if(last!==undefined&&now-last<650)return;}
    contents.send('strix:call-command', action, source);
  };
  const updateMenu = () => {
    if (disposed || !tray || tray.isDestroyed?.()) return;
    tray.setToolTip(state.connected ? `Strix · ${state.deaf ? 'Fone silenciado' : state.mic ? 'Microfone ativo' : 'Microfone silenciado'}` : 'Strix');
    tray.setContextMenu(Menu.buildFromTemplate([
      {label:'Abrir Strix', click:show}, {type:'separator'},
      {label:state.connected ? 'Em chamada' : 'Fora de chamada', enabled:false},
      {label:state.mic ? 'Silenciar microfone' : 'Ativar microfone', enabled:canCommand('microphone',state), click:()=>command('microphone')},
      {label:state.deaf ? 'Ouvir chamada' : 'Silenciar fone e microfone', enabled:state.connected, click:()=>command('deafen')},
      {label:'Sair da chamada', enabled:state.connected, click:()=>command('leave')},
      ...(state.connected&&state.globalShortcuts ? [{type:'separator'}, ...shortcuts.map(([key,action])=>({
        label:`${action==='microphone'?'Microfone':'Fone'}: Ctrl+Shift+${action==='microphone'?'M':'D'}${registered.has(key)?'':' (indisponível)'}`, enabled:false
      }))] : []),
      {type:'separator'}, {label:'Encerrar Strix',click:()=>app.quit()}
    ]));
  };
  const setCall = next => {
    if(disposed||contents.isDestroyed())return;
    const changed = state.connected !== next.connected;
    const shortcutsChanged=changed||state.globalShortcuts!==next.globalShortcuts;
    state = next;
    if (shortcutsChanged) {
      lastShortcut.clear();
      for (const [key,action] of shortcuts) {
        if (state.connected&&state.globalShortcuts) {if (globalShortcut.register(key,()=>command(action,'shortcut'))) registered.add(key);}
        else {globalShortcut.unregister(key); registered.delete(key);}
      }
    }
    if (changed) {
      // Keep signaling heartbeats alive while gaming; restore throttling afterward.
      contents.setBackgroundThrottling(!state.connected);
    }
    updateMenu();
  };
  const receive = (event, payload) => {
    if (trustedFrame(event, contents, origin)) setCall(sanitizeCall(payload));
  };
  const save = () => {
    if (win.isDestroyed()) return;
    try {
      fs.mkdirSync(app.getPath('userData'), {recursive:true});
      fs.writeFileSync(statePath(app), JSON.stringify({...win.getNormalBounds(),maximized:win.isMaximized()}));
    } catch { /* A read-only disk must not prevent opening or closing the app. */ }
  };
  const scheduleSave = () => {clearTimeout(saveTimer); saveTimer = setTimeout(save, 400);};
  try {
    const icon = nativeImage.createFromPath(path.join(__dirname,'icon.png')).resize({width:20,height:20});
    tray = new Tray(icon); tray.on('click', show); updateMenu();
  } catch { /* Without a tray, closing the window must still close the application. */ }
  ipcMain.on('strix:call-state', receive);
  contents.on('did-start-navigation', (_event, _url, inPlace, isMainFrame) => {
    if (isMainFrame && !inPlace) setCall({...IDLE});
  });
  contents.on('render-process-gone', () => setCall({...IDLE}));
  contents.on('did-finish-load', sendVisibility);
  for (const event of ['show','hide','minimize','restore']) win.on(event,sendVisibility);
  for (const event of ['resize','move','maximize','unmaximize']) win.on(event,scheduleSave);
  win.on('close', event => {
    save();
    if (!quitting && state.connected && tray) {event.preventDefault(); win.hide();}
  });
  win.on('closed', () => {
    disposed=true;
    clearTimeout(saveTimer);
    ipcMain.removeListener('strix:call-state',receive);
    for (const [key] of shortcuts) globalShortcut.unregister(key);
    tray?.destroy();
  });
}
function installLifecycle(app, globalShortcut) {
  app.on('before-quit', () => {quitting = true;});
  app.on('will-quit', () => globalShortcut.unregisterAll());
}
module.exports = {savedWindow, installDesktopControls, installLifecycle};
