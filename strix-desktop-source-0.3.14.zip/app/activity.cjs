const {execFile}=require('node:child_process');
const path=require('node:path');
const {trustedFrame}=require('./desktop-controls.cjs');
const empty=()=>({game:null,music:null});
function clean(value,scope){
 const text=v=>typeof v==='string'?v.replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,160):'';
 const game=scope.games?text(value?.game):'';
 const title=scope.spotify?text(value?.music?.title):'',artist=scope.spotify?text(value?.music?.artist):'';
 return {game:game||null,music:title&&artist?{title,artist}:null};
}
function createReader(run){let pending=null,last=0,cached=empty(),key='';return async function read(value){
 const scope={games:value?.games===true,spotify:value?.spotify===true};
 if(!scope.games&&!scope.spotify)return empty();
 const next=JSON.stringify(scope);if(pending){await pending;return read(value);}
 if(next===key&&Date.now()-last<15000)return cached;
 key=next;pending=run(scope).then(v=>cached=clean(v,scope)).catch(()=>cached=empty()).finally(()=>{last=Date.now();pending=null;});
 await pending;return cached;
};}
function installActivity({app,ipcMain},win,origin){
 const binary=app.isPackaged?path.join(process.resourcesPath,'strix-activity.exe'):path.join(__dirname,'../native/bin/strix-activity.exe');
 const read=createReader(scope=>new Promise((resolve,reject)=>execFile(binary,[...(scope.games?['--games']:[]),...(scope.spotify?['--spotify']:[])],{timeout:4000,maxBuffer:16384,windowsHide:true},(error,stdout)=>{if(error)return reject(error);try{resolve(JSON.parse(stdout));}catch(e){reject(e);}})));
 ipcMain.removeHandler('strix:activity');ipcMain.handle('strix:activity',(event,scope)=>{
  if(process.platform!=='win32'||!trustedFrame(event,win.webContents,origin))throw Error('Atividade indisponível');
  return read(scope);
 });
}
module.exports={clean,createReader,installActivity};
