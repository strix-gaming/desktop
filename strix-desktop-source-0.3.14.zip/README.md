# Strix Desktop 0.3.13 — Windows x64

Shell Electron da Strix. A interface é carregada de https://strix-gaming.web.app.

## Compilar no Windows

Requisitos: Node.js 24, Visual Studio Build Tools com C++/Windows SDK e PowerShell.

```powershell
npm ci --no-audit --no-fund
npm ci --prefix app --omit=dev --no-audit --no-fund
node --test tests/*.cjs
./native/build.ps1
node integration/native-activity.cjs
npx electron integration/electron-capture.cjs
npx electron integration/electron-fullscreen.cjs
npm run build:windows -- --publish never
```

O instalador NSIS e os metadados de atualização são gerados em `release/`. As dependências ficam fixadas nos dois lockfiles. O Electron é baixado oficialmente pelo builder; não há dependência de cache ou caminho local.

O workflow GitHub Actions compila, verifica e publica um prerelease após disparo manual. O atualizador dos aplicativos existentes aceita prereleases. Executar esse workflow publica uma atualização real; o comando de build local acima não publica.

Instalação por usuário sem elevação. O executável não tem assinatura Authenticode. Build e testes automatizados não substituem instalação/upgrade e teste de call em Windows físico.

## Biblioteca local de jogos e aplicativos

A biblioteca descobre jogos instalados do Steam a partir dos manifests locais, incluindo as bibliotecas adicionais cadastradas no próprio Steam. No Windows, também lê atalhos de executáveis nos Menus Iniciar do usuário e do sistema. No macOS, lê bundles `.app` em `/Applications` e `~/Applications`, com até dois níveis de subpastas. Não varre o disco inteiro, não segue pastas vinculadas para fora dessas raízes e não procura executáveis arbitrários. Linux retorna `supported: false`. Aplicativos da Microsoft Store sem atalho de executável, outros launchers e pastas diferentes dessas não estão cobertos nesta versão.

Os ícones vêm do sistema; as capas do Steam usam somente o cache local disponível. Não há download de capas, telemetria da biblioteca ou envio dessa lista a um servidor pelo módulo nativo. Ausência de uma imagem é um resultado válido. Cada descoberta fica limitada a 256 itens, ícones de 64 px, capas de 240 px e até 8 MiB agregados em imagens retornadas.

Contrato da ponte isolada:

```ts
getLibrary(options?: { refresh?: boolean }): Promise<{
  supported: boolean;
  items: Array<{
    id: string;
    name: string;
    kind: 'game' | 'app';
    source: string;
    icon?: string; // data URL de imagem local
    cover?: string;
  }>;
  scannedAt: number;
}>;
launchLibraryItem(id: string): Promise<{ ok: boolean; error?: string }>;
```

A descoberta começa quando a interface solicita a biblioteca, usa cache de 60 segundos e compartilha uma única varredura entre solicitações simultâneas. `refresh: true` permite atualização manual com intervalo mínimo de dois segundos. As imagens permanecem apenas no cache em memória da janela.

A interface recebe identificadores opacos, nunca caminhos ou argumentos de execução. O processo principal mantém uma lista permitida e confere novamente a origem da janela e a existência/identidade do item antes de abrir. Atalhos modificados desde a descoberta são rejeitados. Abrir exige chamar explicitamente `launchLibraryItem`; descobrir ou atualizar a biblioteca nunca inicia jogos. Os testes usam pastas temporárias e lançadores simulados, sem abrir aplicativos reais.

Essas APIs fazem parte da distribuição desktop 0.3.12. Versões anteriores precisam instalar a atualização nativa; recarregar a interface web não adiciona a ponte. Detecção e abertura em um Windows físico ainda precisam de validação na distribuição correspondente.
