// Reads only opted-in Spotify metadata and an explicit game allowlist. No audio or titles of windows.
#include <windows.h>
#include <tlhelp32.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.Data.Json.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <cwctype>
using namespace winrt;
using namespace Windows::Data::Json;
std::wstring lower(std::wstring s){std::transform(s.begin(),s.end(),s.begin(),::towlower);return s;}
int main(int argc,char**argv){
 init_apartment(apartment_type::multi_threaded);
 bool games=false,music=false;for(int i=1;i<argc;i++){games|=std::string(argv[i])=="--games";music|=std::string(argv[i])=="--spotify";}
 JsonObject out;out.Insert(L"game",JsonValue::CreateNullValue());out.Insert(L"music",JsonValue::CreateNullValue());
 if(games){
  const std::pair<const wchar_t*,const wchar_t*> known[]={
   {L"cs2.exe",L"Counter-Strike 2"},{L"valorant-win64-shipping.exe",L"VALORANT"},
   {L"league of legends.exe",L"League of Legends"},{L"fortniteclient-win64-shipping.exe",L"Fortnite"},
   {L"rocketleague.exe",L"Rocket League"},{L"dota2.exe",L"Dota 2"},{L"r5apex.exe",L"Apex Legends"},
   {L"overwatch.exe",L"Overwatch 2"},{L"eldenring.exe",L"Elden Ring"},{L"gta5.exe",L"Grand Theft Auto V"},
   {L"gta5_enhanced.exe",L"Grand Theft Auto V"},{L"minecraft.windows.exe",L"Minecraft"},
   {L"robloxplayerbeta.exe",L"Roblox"},{L"destiny2.exe",L"Destiny 2"},{L"terraria.exe",L"Terraria"},
   {L"stardew valley.exe",L"Stardew Valley"},{L"witcher3.exe",L"The Witcher 3"},
   {L"cyberpunk2077.exe",L"Cyberpunk 2077"},{L"helldivers2.exe",L"Helldivers 2"},
   {L"deadlock.exe",L"Deadlock"},{L"rustclient.exe",L"Rust"},{L"rainbowsix.exe",L"Rainbow Six Siege"}};
  HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  if(snapshot!=INVALID_HANDLE_VALUE){PROCESSENTRY32W entry{};entry.dwSize=sizeof(entry);const wchar_t*chosen=nullptr;
   if(Process32FirstW(snapshot,&entry))do{auto name=lower(entry.szExeFile);for(auto &item:known)if(name==item.first){if(!chosen||entry.th32ProcessID==foreground)chosen=item.second;}}while(Process32NextW(snapshot,&entry));
   CloseHandle(snapshot);if(chosen)out.Insert(L"game",JsonValue::CreateStringValue(chosen));
  }
 }
 if(music)try{
  using namespace Windows::Media::Control;
  auto manager=GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();
  for(auto const& session:manager.GetSessions()){
   auto id=lower(std::wstring(session.SourceAppUserModelId()));
   // Spotify's classic executable or its Store identity; never unrelated media apps.
   if(id!=L"spotify.exe" && id.rfind(L"spotifyab.spotifymusic_",0)!=0)continue;
   if(session.GetPlaybackInfo().PlaybackStatus()!=GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing)continue;
   auto properties=session.TryGetMediaPropertiesAsync().get();
   if(properties.Title().empty()||properties.Artist().empty())continue;
   JsonObject track;track.Insert(L"title",JsonValue::CreateStringValue(properties.Title()));track.Insert(L"artist",JsonValue::CreateStringValue(properties.Artist()));out.Insert(L"music",track);break;
  }
 }catch(...){/* A missing or unavailable media session means no activity. */}
 std::cout<<to_string(out.Stringify());return 0;
}
