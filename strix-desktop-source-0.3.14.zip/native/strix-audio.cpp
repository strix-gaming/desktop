// Strix: WASAPI process-loopback capture. No files or audio drivers are installed.
// Requires Windows build 20348+. PCM output is 48 kHz, stereo, signed 16-bit LE.
#define NOMINMAX
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <audioclientactivationparams.h>
#include <wrl.h>
#include <avrt.h>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <vector>
using namespace Microsoft::WRL;

class Activation final : public RuntimeClass<RuntimeClassFlags<ClassicCom>, IActivateAudioInterfaceCompletionHandler, FtmBase> {
public:
 HANDLE ready=CreateEventW(nullptr,FALSE,FALSE,nullptr);
 HRESULT result=E_PENDING;
 ComPtr<IAudioClient> client;
 ~Activation(){if(ready)CloseHandle(ready);}
 STDMETHOD(ActivateCompleted)(IActivateAudioInterfaceAsyncOperation* operation) override {
  HRESULT activation=E_FAIL;ComPtr<IUnknown> unknown;
  result=operation->GetActivateResult(&activation,&unknown);
  if(SUCCEEDED(result))result=activation;
  if(SUCCEEDED(result))result=unknown.As(&client);
  SetEvent(ready);return S_OK;
 }
};
static int fail(HRESULT hr){fprintf(stderr,"ERROR %08lx\n",static_cast<unsigned long>(hr));fflush(stderr);return 1;}
static bool writeAll(HANDLE out,const BYTE* data,DWORD bytes){while(bytes){DWORD written=0;if(!WriteFile(out,data,bytes,&written,nullptr)||!written)return false;data+=written;bytes-=written;}return true;}
int wmain(int argc,wchar_t** argv){
 if(argc!=3||wcscmp(argv[1],L"--exclude")!=0)return fail(E_INVALIDARG);
 wchar_t* end=nullptr;DWORD pid=wcstoul(argv[2],&end,10);if(!pid||!end||*end)return fail(E_INVALIDARG);
 HRESULT hr=CoInitializeEx(nullptr,COINIT_MULTITHREADED);if(FAILED(hr))return fail(hr);
 const HANDLE stop=CreateEventW(nullptr,TRUE,FALSE,nullptr),samples=CreateEventW(nullptr,FALSE,FALSE,nullptr);
 if(!stop||!samples)return fail(HRESULT_FROM_WIN32(GetLastError()));
 // Closing stdin stops capture if the parent exits or explicitly cancels.
 std::thread([stop]{char b;DWORD read;while(ReadFile(GetStdHandle(STD_INPUT_HANDLE),&b,1,&read,nullptr)&&read){}SetEvent(stop);}).detach();
 auto activation=Make<Activation>();if(!activation||!activation->ready)return fail(E_OUTOFMEMORY);
 AUDIOCLIENT_ACTIVATION_PARAMS params{};params.ActivationType=AUDIOCLIENT_ACTIVATION_TYPE_PROCESS_LOOPBACK;
 params.ProcessLoopbackParams.TargetProcessId=pid;
 params.ProcessLoopbackParams.ProcessLoopbackMode=PROCESS_LOOPBACK_MODE_EXCLUDE_TARGET_PROCESS_TREE;
 PROPVARIANT variant{};variant.vt=VT_BLOB;variant.blob.cbSize=sizeof(params);variant.blob.pBlobData=reinterpret_cast<BYTE*>(&params);
 ComPtr<IActivateAudioInterfaceAsyncOperation> operation;
 hr=ActivateAudioInterfaceAsync(VIRTUAL_AUDIO_DEVICE_PROCESS_LOOPBACK,__uuidof(IAudioClient),&variant,activation.Get(),&operation);
 if(FAILED(hr))return fail(hr);
 HANDLE initial[]={stop,activation->ready};DWORD waited=WaitForMultipleObjects(2,initial,FALSE,5000);
 if(waited!=WAIT_OBJECT_0+1)return fail(HRESULT_FROM_WIN32(ERROR_TIMEOUT));
 if(FAILED(activation->result))return fail(activation->result);
 auto client=activation->client;
 WAVEFORMATEX format{};format.wFormatTag=WAVE_FORMAT_PCM;format.nChannels=2;format.nSamplesPerSec=48000;
 format.wBitsPerSample=16;format.nBlockAlign=4;format.nAvgBytesPerSec=192000;
 hr=client->Initialize(AUDCLNT_SHAREMODE_SHARED,AUDCLNT_STREAMFLAGS_LOOPBACK|AUDCLNT_STREAMFLAGS_EVENTCALLBACK|AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM|AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,0,0,&format,nullptr);
 if(FAILED(hr))return fail(hr);
 ComPtr<IAudioCaptureClient> capture;hr=client->GetService(IID_PPV_ARGS(&capture));if(FAILED(hr))return fail(hr);
 hr=client->SetEventHandle(samples);if(FAILED(hr))return fail(hr);
 hr=client->Start();if(FAILED(hr))return fail(hr);
 DWORD task=0;HANDLE priority=AvSetMmThreadCharacteristicsW(L"Audio",&task);
 fprintf(stderr,"READY 48000 2 16\n");fflush(stderr);
 HANDLE events[]={stop,samples};std::vector<BYTE> silence;bool running=true;
 while(running){
  DWORD event=WaitForMultipleObjects(2,events,FALSE,1000);
  if(event==WAIT_OBJECT_0||event==WAIT_FAILED)break;
  if(event!=WAIT_OBJECT_0+1)continue;
  UINT32 frames=0;
  while(SUCCEEDED(hr=capture->GetNextPacketSize(&frames))&&frames){
   BYTE* data=nullptr;DWORD flags=0;UINT64 position=0,time=0;
   hr=capture->GetBuffer(&data,&frames,&flags,&position,&time);if(FAILED(hr)){running=false;break;}
   const DWORD bytes=frames*format.nBlockAlign;
   if(flags&AUDCLNT_BUFFERFLAGS_SILENT){silence.assign(bytes,0);data=silence.data();}
   const bool written=bytes==0||writeAll(GetStdHandle(STD_OUTPUT_HANDLE),data,bytes);
   capture->ReleaseBuffer(frames);
   if(!written){running=false;break;}
  }
  if(FAILED(hr))running=false;
 }
 client->Stop();if(priority)AvRevertMmThreadCharacteristics(priority);
 return FAILED(hr)?fail(hr):0;
}
