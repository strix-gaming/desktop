const electron=require('electron');const {app,BrowserWindow}=electron;
const {installPermissions}=require('../app/permissions.cjs');const http=require('node:http'),assert=require('node:assert/strict');
const deadline=setTimeout(()=>{console.error('Fullscreen test timed out');app.exit(1);},25000);
app.whenReady().then(async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><body style="margin:0;background:black;color:white"><div id="viewer">Strix stream</div></body></html>');});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
 const owner=new BrowserWindow({show:true,webPreferences:{sandbox:true,contextIsolation:true}});
 const permissions=installPermissions(electron,owner,origin);
 owner.webContents.setWindowOpenHandler(()=>({action:'allow',overrideBrowserWindowOptions:{show:true,autoHideMenuBar:true,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}}}));
 const created=new Promise(resolve=>owner.webContents.once('did-create-window',(child,details)=>{permissions.allowStreamWindow(child,details.url);resolve(child);}));await owner.loadURL(origin+'/app');
 await owner.webContents.executeJavaScript(`window.viewer=window.open('${origin}/stream-window.html','','popup=yes,width=1100,height=700');true`,true);const child=await created;if(child.webContents.isLoading())await new Promise(resolve=>child.webContents.once('did-finish-load',resolve));
 const enter=new Promise(resolve=>child.once('enter-full-screen',resolve));
 const result=await child.webContents.executeJavaScript(`(async()=>{await document.getElementById('viewer').requestFullscreen();return !!document.fullscreenElement;})()`,true);
 await enter;assert.equal(result,true);assert.equal(child.isFullScreen(),true,'HTML fullscreen must remove native window chrome');assert.equal(owner.isFullScreen(),false,'opener must remain windowed');
 console.log('PASS: detached stream HTML fullscreen enters native window fullscreen; opener stays windowed');
 const leave=new Promise(resolve=>child.once('leave-full-screen',resolve));await child.webContents.executeJavaScript('document.exitFullscreen()',true);await leave;assert.equal(child.isFullScreen(),false);console.log('PASS: exit restores detached window');child.destroy();owner.destroy();server.close();clearTimeout(deadline);app.exit(0);
}).catch(error=>{console.error(error);app.exit(1);});
