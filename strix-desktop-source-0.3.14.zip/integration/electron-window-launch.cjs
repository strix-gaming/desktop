const {app,BrowserWindow}=require('electron'),{createServer}=require('node:http'),assert=require('node:assert/strict'),path=require('node:path');
const {openAppWindow}=require('../app/window-launch.cjs');
let server,win;
app.whenReady().then(async()=>{
 let remoteDone=false;
 server=createServer((_req,res)=>setTimeout(()=>{remoteDone=true;res.end('<!doctype html><title>Strix launch QA</title>Ready');},2000));
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 win=new BrowserWindow({show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 const shown=new Promise(resolve=>win.once('show',()=>{assert.equal(remoteDone,false,'Window should show before remote response');resolve();}));
 const loaded=new Promise(resolve=>win.webContents.on('did-finish-load',()=>{if(win.webContents.getURL().startsWith('http://'))resolve();}));
 openAppWindow(win,`http://127.0.0.1:${server.address().port}`,path.join(__dirname,'../app'));
 await shown;await loaded;assert.equal(win.isVisible(),true);assert.equal(await win.webContents.executeJavaScript('document.title'),'Strix launch QA');
 console.log('PASS: real Electron window shows local shell before delayed network and reaches remote page.');win.destroy();server.close();app.exit(0);
}).catch(error=>{console.error(error);server?.close();app.exit(1);});
setTimeout(()=>{console.error('Launch QA timed out');app.exit(1);},20000).unref();
