const electron=require('electron'),{app,BrowserWindow}=electron;
const {installPermissions}=require('../app/permissions.cjs');
const http=require('node:http'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const data=fs.mkdtempSync(path.join(os.tmpdir(),'strix-output-integration-'));app.setPath('userData',data);
const deadline=setTimeout(()=>{console.error('Audio output test timed out');app.exit(1);},25000);
app.whenReady().then(async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><body>Strix audio output</body></html>');});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
 const owner=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true}});
 const permissions=installPermissions({...electron,dialog:{showMessageBox:async()=>({response:1})}},owner,origin,'win32');
 await owner.loadURL(origin+'/app');
 await permissions.prepare();
 const playback=await owner.webContents.executeJavaScript(`(${async function(){
  const audio=document.createElement('audio');
  if(typeof audio.setSinkId!=='function')throw new Error('HTMLMediaElement.setSinkId is unavailable');
  const context=new AudioContext(),source=context.createOscillator(),destination=context.createMediaStreamDestination();
  source.connect(destination);source.start();
  const stream=destination.stream,track=stream.getAudioTracks()[0];
  let ended=false;track.addEventListener('ended',()=>{ended=true;});
  audio.muted=true;audio.srcObject=stream;
  const snapshot=()=>({sinkId:audio.sinkId,sameStream:audio.srcObject===stream,sameTrack:audio.srcObject?.getAudioTracks()[0]===track,trackState:track.readyState,active:stream.active,ended});
  try{
   await audio.setSinkId('');const initial=snapshot();
   let invalidSinkError=null;
   try{await audio.setSinkId('strix-integration-nonexistent-output-device');}catch(error){invalidSinkError=error.name;}
   const afterFailure=snapshot();
   await audio.setSinkId('');const recovered=snapshot();
   return {initial,invalidSinkError,afterFailure,recovered};
  }finally{
   audio.srcObject=null;source.stop();source.disconnect();track.stop();await context.close();
  }
 }.toString()})()`);
 assert.equal(playback.invalidSinkError,'NotFoundError','a nonexistent output must reject without replacing the stream');
 const expected={sinkId:'',sameStream:true,sameTrack:true,trackState:'live',active:true,ended:false};
 for(const phase of ['initial','afterFailure','recovered'])assert.deepEqual(playback[phase],expected,phase);
 console.log('PASS: Electron selects default output, rejects an unknown sink, and restores default while preserving the live MediaStream and track');
 owner.destroy();server.close();clearTimeout(deadline);app.exit(0);
}).catch(error=>{console.error(error);app.exit(1);});
