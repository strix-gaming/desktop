const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {createCaptureController}=require('../app/capture-controller.cjs');
function setup(){
 const ipc=new EventEmitter();const handlers=new Map();ipc.handle=(name,fn)=>handlers.set(name,fn);ipc.removeHandler=name=>handlers.delete(name);ipc.invoke=(name,...args)=>handlers.get(name)(...args);
 const sent=[];const frame={url:'https://strix-gaming.web.app/app'},owner=new EventEmitter();owner.isDestroyed=()=>false;owner.webContents=new EventEmitter();Object.assign(owner.webContents,{isDestroyed:()=>false,mainFrame:frame,getURL:()=>frame.url,send:(...args)=>sent.push(args)});
 let picker,rejectLoad;class Window extends EventEmitter{constructor(){super();picker=this;this.webContents=new EventEmitter();this.webContents.mainFrame={};this.webContents.send=()=>{};this.closed=false;}isDestroyed(){return this.closed;}destroy(){if(!this.closed){this.closed=true;this.emit('closed');rejectLoad?.(Error('ERR_ABORTED'));}}loadFile(){return new Promise((_r,reject)=>rejectLoad=reject);}}
 const source={id:'screen:1',name:'Tela',thumbnail:{toDataURL:()=>''}};
 const grants=[],controller=createCaptureController({BrowserWindow:Window,desktopCapturer:{getSources:async()=>[source]},ipcMain:ipc},owner,'https://strix-gaming.web.app',value=>grants.push(value),'win32');
 return {controller,ipc,owner,frame,sent,get picker(){return picker;},get rejectLoad(){return rejectLoad;},grants,request:{frame,securityOrigin:'https://strix-gaming.web.app',userGesture:true,audioRequested:true}};
}
test('X before picker load rejects capture exactly once and a second attempt can open',async()=>{
 const h=setup(),results=[];const first=h.controller.handler(h.request,x=>results.push(x));await new Promise(setImmediate);h.picker.destroy();await first;assert.deepEqual(results,[null]);assert.equal(h.ipc.listenerCount('strix:choose-source'),0);
 const second=h.controller.handler(h.request,x=>results.push(x));await new Promise(setImmediate);h.picker.destroy();await second;assert.equal(results.length,2);
});
test('valid selection grants once even if closing rejects load; spoofed IPC is ignored',async()=>{
 const h=setup(),results=[];const task=h.controller.handler(h.request,x=>results.push(x));await new Promise(setImmediate);
 h.ipc.emit('strix:choose-source',{sender:{},senderFrame:{}},'screen:1');assert.equal(results.length,0);
 h.ipc.emit('strix:choose-source',{sender:h.picker.webContents,senderFrame:h.picker.webContents.mainFrame},'screen:1');await task;
 assert.equal(results.length,1);assert.equal(results[0].video.id,'screen:1');assert.deepEqual(h.grants,[{audio:true}]);
});
test('load failure, navigation, concurrent requests and callback failure do not double-complete',async()=>{
 const h=setup(),results=[];const first=h.controller.handler(h.request,x=>results.push(x));await new Promise(setImmediate);
 await h.controller.handler(h.request,x=>results.push(x));assert.deepEqual(results,[null]);h.rejectLoad(Error('load failed'));await first;assert.equal(results.length,2);
 const second=h.controller.handler(h.request,x=>results.push(x));await new Promise(setImmediate);h.owner.webContents.emit('did-start-navigation',{},'about:blank',false,true);await second;assert.equal(results.length,3);
});
test('inline selection enumerates once without a second window and validates source, frame and request',async()=>{
 const h=setup(),event={sender:h.owner.webContents,senderFrame:h.frame},results=[];
 assert.equal(await h.ipc.invoke('strix:prepare-capture',{sender:{},senderFrame:h.frame}),false);
 assert.equal(await h.ipc.invoke('strix:prepare-capture',event),true);
 await h.controller.handler(h.request,value=>results.push(value));assert.equal(h.picker,undefined);
 const [channel,payload]=h.sent.find(([name])=>name==='strix:capture-sources');assert.equal(payload.sources[0].id,'screen:1');assert.equal(payload.sources[0].kind,'screen');
 assert.equal(await h.ipc.invoke('strix:select-capture',event,'stale','screen:1'),false);
 assert.equal(await h.ipc.invoke('strix:select-capture',event,payload.requestId,'invented'),false);
 assert.equal(await h.ipc.invoke('strix:select-capture',{sender:{},senderFrame:h.frame},payload.requestId,'screen:1'),false);
 assert.equal(await h.ipc.invoke('strix:select-capture',event,payload.requestId,'screen:1'),true);
 assert.equal(results.length,1);assert.equal(results[0].video.id,'screen:1');assert.equal(await h.ipc.invoke('strix:select-capture',event,payload.requestId,'screen:1'),false);
});
test('inline cancellation, back and navigation complete once and allow retry',async()=>{
 const h=setup(),event={sender:h.owner.webContents,senderFrame:h.frame},results=[];
 for(let attempt=0;attempt<3;attempt++){
  assert.equal(await h.ipc.invoke('strix:prepare-capture',event),true);await h.controller.handler(h.request,value=>results.push(value));
  if(attempt===1)h.owner.webContents.emit('did-start-navigation',{},'about:blank',false,true);else await h.ipc.invoke('strix:cancel-capture',event);
  assert.equal(results.length,attempt+1);assert.equal(results[attempt],null);
 }
 assert.equal(h.picker,undefined);
});
