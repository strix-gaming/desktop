const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {basename}=require('node:path');
const {openAppWindow}=require('../app/window-launch.cjs');
test('shows local shell before waiting for remote network and navigates once',async()=>{
 const win=new EventEmitter(),events=[];win.isDestroyed=()=>false;win.show=()=>events.push('show');win.loadFile=async p=>events.push(basename(p));win.loadURL=async()=>{events.push('remote');};
 const open=openAppWindow(win,'https://strix-gaming.web.app/app','/app');assert.deepEqual(events,['startup.html']);win.emit('ready-to-show');open();await new Promise(setImmediate);assert.deepEqual(events,['startup.html','show','remote']);
});
test('failed shell still opens app and network failures show local recovery',async()=>{
 const win=new EventEmitter(),events=[];win.isDestroyed=()=>false;win.show=()=>events.push('show');win.loadFile=async p=>{events.push(basename(p));if(p.endsWith('startup.html'))throw Error('missing');};win.loadURL=async()=>{events.push('remote');throw Error('offline');};
 openAppWindow(win,'https://strix-gaming.web.app/app','/app');await new Promise(setImmediate);assert.deepEqual(events,['startup.html','show','remote','offline.html']);
});
test('closing while startup loads does not reopen the app',()=>{const win=new EventEmitter();win.isDestroyed=()=>true;win.show=()=>assert.fail('closed window');win.loadFile=async()=>{};openAppWindow(win,'https://strix-gaming.web.app/app','/app');win.emit('ready-to-show');});

test('offline fallback rejection during close is consumed',async()=>{
 const win=new EventEmitter();win.isDestroyed=()=>false;win.show=()=>{};win.loadFile=async()=>{throw Error('ERR_ABORTED');};win.loadURL=async()=>{throw Error('closed');};
 openAppWindow(win,'https://strix-gaming.web.app/app','/app');await new Promise(setImmediate);
});
