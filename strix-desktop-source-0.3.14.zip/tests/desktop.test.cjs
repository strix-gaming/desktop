const {test} = require('node:test');
const assert = require('node:assert/strict');
const {EventEmitter} = require('node:events');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {sanitizeCall,trustedFrame,canCommand,windowBounds} = require('../app/desktop-controls.cjs');
const {installDesktopControls,installLifecycle} = require('../app/desktop-runtime.cjs');

test('rejects subframes, other windows and lookalike origins for native IPC', () => {
  const mainFrame={url:'https://strix-gaming.web.app/app'};
  const wc={mainFrame,isDestroyed:()=>false};
  const event={sender:wc,senderFrame:mainFrame};
  assert.equal(trustedFrame(event,wc,'https://strix-gaming.web.app'),true);
  assert.equal(trustedFrame({...event,senderFrame:{url:mainFrame.url}},wc,'https://strix-gaming.web.app'),false);
  assert.equal(trustedFrame({...event,sender:{}},wc,'https://strix-gaming.web.app'),false);
  mainFrame.url='https://strix-gaming.web.app.evil.test/app';
  assert.equal(trustedFrame(event,wc,'https://strix-gaming.web.app'),false);
});
test('validates renderer payloads and gates microphone commands by call permissions', () => {
  assert.equal(sanitizeCall({connected:'true'}).connected,false);
  const state=sanitizeCall({connected:true,mic:true,canPublish:false,busy:false,extra:'ignored'});
  assert.equal('extra' in state,false);
  assert.equal(canCommand('microphone',state),false);
  assert.equal(canCommand('deafen',state),true);
  assert.equal(canCommand('open-file',state),false);
  assert.equal(canCommand('leave',sanitizeCall(null)),false);
  assert.equal(canCommand('microphone',{...state,canPublish:true,busy:true}),false);
});
test('restores a usable window after a monitor is removed or saved bounds are corrupt', () => {
  const displays=[{workArea:{x:0,y:0,width:1920,height:1040}}];
  assert.deepEqual(windowBounds({x:4000,y:0,width:1000,height:700},displays),{width:1440,height:920});
  assert.deepEqual(windowBounds({x:1800,y:1000,width:1200,height:800},displays),{x:720,y:240,width:1200,height:800});
  assert.deepEqual(windowBounds({x:0,y:NaN,width:1,height:1},displays),{width:1440,height:920});
});

function harness() {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-desktop-test-'));
  const app=new EventEmitter();app.getPath=()=>dir;app.quit=()=>app.emit('before-quit');
  const ipcMain=new EventEmitter();const shortcuts=new Map();const sent=[];const throttling=[];
  const wc=new EventEmitter();wc.mainFrame={url:'https://strix-gaming.web.app/app'};
  Object.assign(wc,{isDestroyed:()=>false,getURL:()=>wc.mainFrame.url,send:(...args)=>sent.push(args),setBackgroundThrottling:value=>throttling.push(value)});
  const win=new EventEmitter();let visible=true,hidden=0;
  Object.assign(win,{webContents:wc,isDestroyed:()=>false,isVisible:()=>visible,isMinimized:()=>false,isMaximized:()=>false,getNormalBounds:()=>({x:20,y:20,width:1440,height:920}),
    show:()=>{visible=true;win.emit('show');},hide:()=>{hidden++;visible=false;win.emit('hide');},focus:()=>{},restore:()=>{}});
  let tray;
  class Tray extends EventEmitter {constructor(){super();tray=this;}setToolTip(value){this.tip=value;}setContextMenu(value){this.menu=value;}destroy(){this.destroyed=true;}}
  const globalShortcut={register:(key,fn)=>{shortcuts.set(key,fn);return true;},unregister:key=>shortcuts.delete(key),unregisterAll:()=>shortcuts.clear()};
  const electron={app,ipcMain,Tray,Menu:{buildFromTemplate:x=>x},nativeImage:{createFromPath:()=>({resize:()=>({})})},globalShortcut};
  installDesktopControls(electron,win,'https://strix-gaming.web.app');
  const update=value=>ipcMain.emit('strix:call-state',{sender:wc,senderFrame:wc.mainFrame},value);
  return {dir,app,electron,wc,win,tray,update,ipcMain,shortcuts,sent,throttling,hidden:()=>hidden,dispose:()=>{win.emit('closed');fs.rmSync(dir,{recursive:true});}};
}
test('call lifecycle: background audio controls, close to tray, hidden rendering and cleanup', () => {
  const h=harness();
  try {
    assert.equal(h.shortcuts.size,0);
    h.update({connected:true,mic:true,canPublish:true,globalShortcuts:true});
    assert.equal(h.shortcuts.size,2);assert.deepEqual(h.throttling,[false]);
    h.shortcuts.get('CommandOrControl+Shift+M')();
    assert.deepEqual(h.sent.at(-1),['strix:call-command','microphone','shortcut']);
    h.shortcuts.get('CommandOrControl+Shift+M')(); // OS key repeat is deduplicated.
    assert.equal(h.sent.filter(x=>x[0]==='strix:call-command').length,1);
    let prevented=false;h.win.emit('close',{preventDefault:()=>{prevented=true;}});
    assert.equal(prevented,true);assert.equal(h.hidden(),1);
    assert.deepEqual(h.sent.at(-1),['strix:window-visible',false]);
    h.update({connected:false});assert.equal(h.shortcuts.size,0);assert.deepEqual(h.throttling,[false,true]);
    prevented=false;h.win.emit('close',{preventDefault:()=>{prevented=true;}});assert.equal(prevented,false);
  } finally {h.dispose();}
  assert.equal(h.ipcMain.listenerCount('strix:call-state'),0);assert.equal(h.tray.destroyed,true);
});
test('navigation and renderer crashes release desktop call state', () => {
  const h=harness();
  try {
    h.update({connected:true});h.wc.emit('did-start-navigation',{},'https://accounts.google.com',false,true);
    assert.equal(h.shortcuts.size,0);
    h.update({connected:true});h.wc.emit('render-process-gone');assert.equal(h.shortcuts.size,0);
    h.ipcMain.emit('strix:call-state',{sender:h.wc,senderFrame:{}},{connected:true});assert.equal(h.shortcuts.size,0);
  } finally {h.dispose();}
});
test('explicit quit closes the application even during an active call', () => {
  const h=harness();
  try {
    installLifecycle(h.app,h.electron.globalShortcut);h.update({connected:true});h.app.quit();
    let prevented=false;h.win.emit('close',{preventDefault:()=>{prevented=true;}});assert.equal(prevented,false);
  } finally {h.dispose();}
});
test('native global shortcuts need opt-in; tray commands retain a deliberate source',()=>{
 const h=harness();
 try{
  h.update({connected:true,mic:true,canPublish:true});assert.equal(h.shortcuts.size,0);
  h.tray.menu.find(row=>row.label==='Silenciar fone e microfone').click();
  assert.deepEqual(h.sent.at(-1),['strix:call-command','deafen','tray']);
  h.update({connected:true,mic:true,canPublish:true,globalShortcuts:true});assert.equal(h.shortcuts.size,2);
  h.shortcuts.get('CommandOrControl+Shift+D')();assert.deepEqual(h.sent.at(-1),['strix:call-command','deafen','shortcut']);
  h.update({connected:true,mic:true,canPublish:true,globalShortcuts:false});assert.equal(h.shortcuts.size,0);
 }finally{h.dispose();}
});
test('native held-key repeat cannot toggle deafen every cooldown period',()=>{
 const h=harness(),now=Date.now;let time=1000;Date.now=()=>time;
 try{
  h.update({connected:true,mic:true,canPublish:true,globalShortcuts:true});const press=h.shortcuts.get('CommandOrControl+Shift+D');press();
  for(time=1100;time<5000;time+=100)press();
  assert.equal(h.sent.filter(event=>event[0]==='strix:call-command').length,1);
  time=5700;press();assert.equal(h.sent.filter(event=>event[0]==='strix:call-command').length,2);
 }finally{Date.now=now;h.dispose();}
});
