const {test}=require('node:test'),assert=require('node:assert/strict'),{EventEmitter}=require('node:events');
const {installCaptureAudio}=require('../app/capture-audio.cjs');
function setup(){const handlers={},ipc=new EventEmitter();ipc.handle=(key,fn)=>handlers[key]=fn;ipc.removeHandler=key=>delete handlers[key];let child,args;
 const frame={url:'https://strix-gaming.web.app/app'},owner=new EventEmitter(),sent=[];owner.isDestroyed=()=>false;owner.webContents=new EventEmitter();Object.assign(owner.webContents,{mainFrame:frame,isDestroyed:()=>false,getURL:()=>frame.url,send:(...m)=>sent.push(m)});
 const event={sender:owner.webContents,senderFrame:frame};const api=installCaptureAudio({app:{isPackaged:false},ipcMain:ipc},owner,'https://strix-gaming.web.app',{supported:true,spawn:(_file,argv)=>{args=argv;child=new EventEmitter();Object.assign(child,{stdout:new EventEmitter(),stderr:new EventEmitter(),stdin:{end(){}},kill(){this.killed=true;}});return child;}});
 return {api,owner,ipc,event,sent,handlers,get args(){return args;},get child(){return child;},start:()=>handlers['strix:capture-audio-start'](event)};
}
test('audio starts only after explicit selection and always excludes the Strix process tree',async()=>{
 const h=setup();await assert.rejects(h.start(),/Selecione/);h.api.grant({audio:true});const pending=h.start();assert.deepEqual(h.args,['--exclude',String(process.pid)]);h.child.stderr.emit('data',Buffer.from('READY 48000 2 16\n'));const {id}=await pending;
 for(let i=0;i<20;i++)h.child.stdout.emit('data',Buffer.alloc(1920));assert.equal(h.sent.length,8,'Backlog is bounded');h.ipc.emit('strix:capture-audio-ack',h.event,id);h.child.stdout.emit('data',Buffer.alloc(1920));assert.equal(h.sent.length,9);
 await assert.rejects(h.start(),/Selecione/);h.handlers['strix:capture-audio-stop'](h.event,id);assert.equal(h.child.killed,true);
});
test('audio opt-out, foreign frames and navigation cannot retain a capture grant',async()=>{
 const h=setup();h.api.grant({audio:false});await assert.rejects(h.start(),/Selecione/);h.api.grant({audio:true});await assert.rejects(h.handlers['strix:capture-audio-start']({sender:{},senderFrame:{}}),/Selecione/);
 const pending=h.start();h.child.stderr.emit('data',Buffer.from('READY 48000 2 16\n'));await pending;h.owner.webContents.emit('did-start-navigation',{},'https://example.com',false,true);assert.equal(h.child.killed,true);await assert.rejects(h.start(),/Selecione/);
});
