const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {EventEmitter} = require('node:events');
const vm = require('node:vm');
const {parseVdf, createLibrary, installLibrary} = require('../app/library.cjs');

async function fixture(t) {
  const root = await fs.realpath(await fs.mkdtemp(path.join(os.tmpdir(), 'strix-library-test-')));
  t.after(() => fs.rm(root, {recursive:true, force:true}));
  const write = async (file, text = '') => {await fs.mkdir(path.dirname(file), {recursive:true}); await fs.writeFile(file, text); return file;};
  const game = async (library, appId, name = 'Counter Test', extra = {}) => {
    const dir = extra.installdir || name;
    if (!/[\\/]/.test(dir)) await fs.mkdir(path.join(library, 'steamapps', 'common', dir), {recursive:true});
    return write(path.join(library, 'steamapps', `appmanifest_${appId}.acf`), `"AppState" { "appid" "${extra.appid || appId}" "name" "${name}" "StateFlags" "${extra.state || '4'}" "installdir" "${dir}" }`);
  };
  const app = async (base, name) => {const file = path.join(base, name + '.app'); await write(path.join(file, 'Contents', 'Info.plist'), '<plist/>'); return file;};
  return {root, write, game, app};
}
const noLaunch = () => {throw new Error('No actual application may be launched by these tests');};

test('Valve parser handles escaped local paths and comments as data without prototype writes', () => {
  const parsed = parseVdf('// comment\n "libraryfolders" { "1" { "path" "D:\\\\SteamLibrary" } "old" "yes" } "__proto__" {"polluted" "no"}');
  assert.equal(parsed.libraryfolders['1'].path, 'D:\\SteamLibrary');
  assert.equal(parsed.__proto__.polluted, 'no');
  assert.equal({}.polluted, undefined);
  assert.throws(() => parseVdf('"x" { "y" "z"'));
  assert.throws(() => parseVdf('x'.repeat(1024 * 1024 + 1)));
  assert.throws(() => parseVdf('"x" {'.repeat(20) + '}'.repeat(20)));
});

test('Steam detects only installed manifests, including configured libraries, and never launches during scan', async t => {
  const f = await fixture(t), steam = path.join(f.root, 'Steam'), other = path.join(f.root, 'Games');
  await f.game(steam, '10'); await f.game(other, '20', 'Adventure'); await f.game(other, '10');
  await f.game(steam, '30', 'Not installed', {state:'2'});
  await f.game(steam, '40', 'Mismatch', {appid:'41'});
  await f.game(steam, '50', 'Traversal', {installdir:'../outside'});
  await f.game(steam, '60', 'Missing folder'); await fs.rm(path.join(steam,'steamapps','common','Missing folder'), {recursive:true});
  await f.write(path.join(steam, 'steamapps', 'libraryfolders.vdf'), `"libraryfolders" { "0" { "path" ${JSON.stringify(steam)} } "1" { "path" ${JSON.stringify(other)} } "2" "relative/path" }`);
  const service = createLibrary({platform:'win32', roots:{steam:[steam]}, openPath:noLaunch, openSteam:noLaunch});
  const result = await service.getLibrary();
  assert.equal(result.supported, true); assert.equal(result.items.length, 2);
  assert.deepEqual(result.items.map(item => item.name), ['Adventure', 'Counter Test']);
  for (const item of result.items) {
    assert.deepEqual(Object.keys(item).sort(), ['coverUrl','id','kind','name','source','steamAppId']);
    assert.match(item.id, /^library:[a-f0-9]{32}$/); assert.equal(item.kind, 'game');
    assert.match(item.steamAppId, /^[1-9]\d{0,9}$/);
    assert.equal(item.coverUrl, `https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/${item.steamAppId}/library_600x900.jpg`);
    assert.equal(JSON.stringify(item).includes(f.root), false);
  }
});

test('Steam cannot escape installation roots using a directory link', async t => {
  const f = await fixture(t), steam = path.join(f.root, 'Steam'), outside = path.join(f.root,'Outside');
  await f.game(steam, '10', 'Linked'); await fs.mkdir(outside);
  await fs.rm(path.join(steam,'steamapps','common','Linked'), {recursive:true});
  await fs.symlink(outside, path.join(steam,'steamapps','common','Linked'), 'dir');
  const service = createLibrary({platform:'darwin', roots:{steam:[steam]}, openPath:noLaunch, openSteam:noLaunch});
  assert.equal((await service.getLibrary()).items.length, 0);
});

test('Windows Start Menu includes executable shortcuts, deduplicates targets, ignores shell/documents and links outside the roots', async t => {
  const f = await fixture(t), menu = path.join(f.root,'Programs'), common = path.join(f.root,'Common'), exe = await f.write(path.join(f.root,'Apps','Editor.exe'));
  const links = new Map();
  for (const [base, name, target] of [[menu,'Editor',exe],[common,'Editor duplicate',exe],[menu,'Uninstall',exe],[menu,'Website','https://example.com'],[menu,'Notes',path.join(f.root,'notes.txt')],[menu,'Shell',await f.write(path.join(f.root,'cmd.exe'))]]) {
    const file = await f.write(path.join(base, name + '.lnk')); links.set(file, {target,args:''});
  }
  const outside = path.join(f.root,'Outside'); await f.write(path.join(outside,'Hidden.lnk')); await fs.symlink(outside,path.join(menu,'Linked'),'dir');
  const service = createLibrary({platform:'win32', roots:{startMenu:[menu,common]}, readShortcut:file => links.get(file), openPath:noLaunch, openSteam:noLaunch});
  const result = await service.getLibrary();
  assert.equal(result.items.length, 1); assert.equal(result.items[0].name, 'Editor'); assert.equal(result.items[0].kind, 'app');
  assert.equal(JSON.stringify(result.items).includes(exe), false);
});

test('macOS discovers local .app bundles without entering bundle contents or symlinked folders', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications'), userApps = path.join(f.root,'UserApplications');
  const editor = await f.app(apps,'Editor'); await f.app(path.join(apps,'Utilities'),'Terminal'); await f.app(userApps,'Music');
  await f.app(path.join(editor,'Contents'),'Hidden helper');
  await fs.mkdir(path.join(apps,'Not an app.app')); const external = path.join(f.root,'Outside'); await f.app(external,'Linked');
  await fs.symlink(external,path.join(apps,'External'),'dir');
  const service = createLibrary({platform:'darwin', roots:{applications:[apps,userApps,apps]}, openPath:noLaunch, openSteam:noLaunch});
  assert.deepEqual((await service.getLibrary()).items.map(item => item.name), ['Editor','Music','Terminal']);
});

test('scan requests coalesce, keep stable opaque IDs, cache for 60 seconds and isolate returned objects', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications'); await f.app(apps,'Editor');
  let scans = 0, time = 100, assets = 0;
  const service = createLibrary({platform:'darwin', roots:async () => {scans++; return {applications:[apps]};}, now:() => time, getAssets:async () => {assets++; return {icon:'data:image/png;base64,YQ=='};}, openPath:noLaunch, openSteam:noLaunch});
  const [a,b] = await Promise.all([service.getLibrary(),service.getLibrary()]);
  assert.equal(scans, 1); assert.equal(assets, 1); assert.equal(a.items[0].id, b.items[0].id);
  a.items[0].name = 'Changed'; assert.equal((await service.getLibrary()).items[0].name,'Editor');
  time += 60001; assert.equal((await service.getLibrary()).items[0].id,b.items[0].id); assert.equal(scans,2);
});

test('images and item count have hard budgets; non-image URLs are never returned', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications');
  await Promise.all(Array.from({length:270},(_,index) => f.app(apps,'App '+String(index).padStart(3,'0'))));
  const image = 'data:image/png;base64,' + 'A'.repeat(500000);
  const service = createLibrary({platform:'darwin', roots:{applications:[apps]}, getAssets:async () => ({icon:'file:///private/data',cover:image}), openPath:noLaunch, openSteam:noLaunch});
  const result = await service.getLibrary();
  assert.equal(result.items.length,256); assert.ok(result.items.every(item => !item.icon));
  assert.ok(result.items.reduce((sum,item) => sum + (item.cover?.length || 0),0) <= 8 * 1024 * 1024);
});

test('manual refresh bypasses cached scans after a short cooldown and concurrent refreshes still coalesce', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications'); await f.app(apps,'Editor');
  let scans = 0, time = 100;
  const service = createLibrary({platform:'darwin', roots:async () => {scans++; return {applications:[apps]};}, now:() => time, openPath:noLaunch, openSteam:noLaunch});
  await service.getLibrary(); await f.app(apps,'New app');
  assert.equal((await service.getLibrary({refresh:true})).items.length,1); assert.equal(scans,1);
  time += 2000;
  assert.equal((await service.getLibrary({refresh:'true'})).items.length,1);
  const results = await Promise.all([service.getLibrary({refresh:true}),service.getLibrary({refresh:true})]);
  assert.ok(results.every(result => result.items.length === 2)); assert.equal(scans,2);
  time += 1999; await service.getLibrary({refresh:true}); assert.equal(scans,2);
});

test('launch accepts only previously scanned IDs and passes solely the stored app path to a mocked launcher', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications'), app = await f.app(apps,'Editor'); const launched = [];
  const service = createLibrary({platform:'darwin', roots:{applications:[apps]}, openPath:async file => {launched.push(file); return '';}, openSteam:noLaunch});
  for (const bad of [app,'steam://run/10',{id:app},'library:'+'a'.repeat(32),null]) assert.equal((await service.launchLibraryItem(bad)).ok,false);
  const [item] = (await service.getLibrary()).items;
  assert.deepEqual(await service.launchLibraryItem(item.id),{ok:true}); assert.deepEqual(launched,[app]);
  await fs.rm(app,{recursive:true}); assert.equal((await service.launchLibraryItem(item.id)).ok,false); assert.equal(launched.length,1);
});

test('Steam launches only a validated numeric ID and revalidates an uninstalled game', async t => {
  const f = await fixture(t), steam = path.join(f.root,'Steam'), manifest = await f.game(steam,'10'); const launched = [];
  const service = createLibrary({platform:'darwin', roots:{steam:[steam]}, openSteam:async id => {launched.push(id);}, openPath:noLaunch});
  const [item] = (await service.getLibrary()).items;
  assert.deepEqual(await service.launchLibraryItem(item.id),{ok:true}); assert.deepEqual(launched,['10']);
  await fs.rm(manifest); assert.equal((await service.launchLibraryItem(item.id)).ok,false); assert.equal(launched.length,1);
});

test('altered shortcut target or arguments cannot be launched using the previous allowlist ID', async t => {
  const f = await fixture(t), menu = path.join(f.root,'Programs'), target = await f.write(path.join(f.root,'Editor.exe'));
  await f.write(path.join(menu,'Editor.lnk')); let args = '--profile original';
  const service = createLibrary({platform:'win32', roots:{startMenu:[menu]}, readShortcut:() => ({target,args}), openPath:noLaunch, openSteam:noLaunch});
  const [item] = (await service.getLibrary()).items; args = '--unexpected new-argument';
  assert.equal((await service.launchLibraryItem(item.id)).ok,false);
});

test('a modified shortcut file is rejected even if its resolved target and arguments are unchanged', async t => {
  const f = await fixture(t), menu = path.join(f.root,'Programs'), target = await f.write(path.join(f.root,'Editor.exe'));
  const shortcut = await f.write(path.join(menu,'Editor.lnk'),'original binary shortcut');
  const service = createLibrary({platform:'win32', roots:{startMenu:[menu]}, readShortcut:() => ({target,args:''}), openPath:noLaunch, openSteam:noLaunch});
  const [item] = (await service.getLibrary()).items;
  await fs.writeFile(shortcut,'changed working-directory or other shortcut metadata');
  assert.equal((await service.launchLibraryItem(item.id)).ok,false);
});

test('authorization is checked again after asynchronous validation; closing disposes every allowed ID', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications'); await f.app(apps,'Editor');
  const service = createLibrary({platform:'darwin', roots:{applications:[apps]}, openPath:noLaunch, openSteam:noLaunch});
  const [item] = (await service.getLibrary()).items; let checks = 0;
  assert.equal((await service.launchLibraryItem(item.id,() => ++checks === 1)).ok,false); assert.equal(checks,2);
  service.dispose(); assert.equal((await service.launchLibraryItem(item.id)).ok,false); assert.equal((await service.getLibrary()).items.length,0);
});

test('IPC exposes library only to the trusted main frame and removes handlers when its window closes', async t => {
  const f = await fixture(t), apps = path.join(f.root,'Applications'); await f.app(apps,'Editor');
  const frame = {url:'https://strix-gaming.web.app/app'}, wc = {mainFrame:frame,isDestroyed:() => false}, win = new EventEmitter(); win.webContents = wc; win.isDestroyed=()=>false;
  const handlers = new Map(), ipcMain = {handle:(name,handler) => handlers.set(name,handler),removeHandler:name => handlers.delete(name)};
  const electron = {app:{},shell:{},ipcMain};
  installLibrary(electron,win,'https://strix-gaming.web.app','darwin',{roots:{applications:[apps]},getAssets:async () => ({}),openPath:noLaunch,openSteam:noLaunch});
  const event = {sender:wc,senderFrame:frame};
  assert.equal((await handlers.get('strix:get-library')(event)).items.length,1);
  for (const bad of [{...event,sender:{}},{...event,senderFrame:{url:frame.url}}]) {
    await assert.rejects(handlers.get('strix:get-library')(bad),/Origem/);
    assert.throws(() => handlers.get('strix:launch-library')(bad,'library:'+'a'.repeat(32)),/Origem/);
  }
  frame.url = 'https://evil.test'; await assert.rejects(handlers.get('strix:get-library')(event),/Origem/);
  win.emit('closed'); assert.equal(handlers.size,0);
});

test('unsupported platforms do no discovery and cannot launch', async () => {
  const service = createLibrary({platform:'linux',roots:() => {throw new Error('must not scan');},openPath:noLaunch,openSteam:noLaunch,now:() => 42});
  assert.deepEqual(await service.getLibrary(),{supported:false,items:[],scannedAt:42});
  assert.equal((await service.launchLibraryItem('library:'+'a'.repeat(32))).ok,false);
});

test('preload exposes narrow library methods, validates IDs and never accepts renderer paths or arguments', async () => {
  let bridge; const calls = [];
  const electron = {contextBridge:{exposeInMainWorld:(name,value) => {bridge=value;}},ipcRenderer:{invoke:async (...args) => {calls.push(args); return {ok:true};}}};
  const source = await fs.readFile(path.join(__dirname,'../app/preload.cjs'),'utf8');
  vm.runInNewContext(source,{require:() => electron,process:{isMainFrame:true,platform:'darwin',argv:[]}});
  await bridge.getLibrary(); await bridge.getLibrary({refresh:true,path:'/private',args:['bad']}); await bridge.launchLibraryItem('library:'+'a'.repeat(32),'ignored argument');
  assert.deepEqual(JSON.parse(JSON.stringify(calls)),[['strix:get-library',{refresh:false}],['strix:get-library',{refresh:true}],['strix:launch-library','library:'+'a'.repeat(32)]]);
  assert.equal((await bridge.launchLibraryItem('/Applications/Anything.app')).ok,false);
  assert.equal(calls.length,3); assert.equal(Object.isFrozen(bridge),true);
});

test('hashed Steam cover cache is recognized without a network request',async t=>{
 const f=await fixture(t),cache=path.join(f.root,'cache');await fs.mkdir(cache,{recursive:true});await fs.writeFile(path.join(cache,'730_hash_library_600x900.jpg'),'image');
 const image={isEmpty:()=>false,resize(){return this;},toDataURL:()=> 'data:image/png;base64,Y292ZXI='};
 const loader=require('../app/library.cjs').assetLoader({app:{getPath:()=>f.root},nativeImage:{createFromPath:()=>image}},()=>assert.fail('cached art must not fetch'));
 assert.equal((await loader({type:'steam',appId:'730',cacheRoots:[cache]})).cover,image.toDataURL());
});
test('library discovery never waits on remote artwork and the renderer receives public cover metadata',async t=>{
 const f=await fixture(t),steam=path.join(f.root,'Steam');await f.game(steam,'730');
 t.mock.method(globalThis,'fetch',async()=>assert.fail('discovery must not fetch external images'));
 const loader=require('../app/library.cjs').assetLoader({app:{getPath:()=>f.root},nativeImage:{}});
 const service=createLibrary({platform:'win32',roots:{steam:[steam]},getAssets:loader,openPath:noLaunch,openSteam:noLaunch});
 const result=await service.getLibrary();assert.equal(result.items[0].cover,undefined);
 assert.equal(result.items[0].steamAppId,'730');assert.match(result.items[0].coverUrl,/\/730\/library_600x900\.jpg$/);
});
test('previously downloaded artwork still works offline from the bounded local cache',async t=>{
 const f=await fixture(t);await f.write(path.join(f.root,'library-covers','730.jpg'),'image');
 const image={isEmpty:()=>false,resize(){return this;},toDataURL:()=> 'data:image/png;base64,Y292ZXI='};
 const loader=require('../app/library.cjs').assetLoader({app:{getPath:()=>f.root},nativeImage:{createFromPath:()=>image}});
 assert.equal((await loader({type:'steam',appId:'730',cacheRoots:[]})).cover,image.toDataURL());
});
test('a missing local cover does not create a cooldown that hides art added before manual refresh',async t=>{
 const f=await fixture(t),cache=path.join(f.root,'cache');
 const image={isEmpty:()=>false,resize(){return this;},toDataURL:()=> 'data:image/png;base64,Y292ZXI='};
 const loader=require('../app/library.cjs').assetLoader({app:{getPath:()=>f.root},nativeImage:{createFromPath:()=>image}});
 const record={type:'steam',appId:'730',cacheRoots:[cache]};assert.equal((await loader(record)).cover,undefined);
 await f.write(path.join(cache,'730_library_600x900.jpg'),'image');assert.equal((await loader(record)).cover,image.toDataURL());
});
test('all Steam games retain public artwork lookup after the aggregate embedded-image budget is exhausted',async t=>{
 const f=await fixture(t),steam=path.join(f.root,'Steam');
 await Promise.all(Array.from({length:20},(_,index)=>f.game(steam,String(index+1),'Game '+index)));
 const image='data:image/png;base64,'+'A'.repeat(500000);
 const service=createLibrary({platform:'win32',roots:{steam:[steam]},getAssets:async()=>({cover:image,icon:image}),openPath:noLaunch,openSteam:noLaunch});
 const result=await service.getLibrary();assert.equal(result.items.length,20);
 assert.ok(result.items.some(item=>!item.cover));
 assert.ok(result.items.every(item=>item.steamAppId&&new URL(item.coverUrl).protocol==='https:'));
 assert.ok(result.items.reduce((sum,item)=>sum+(item.cover?.length||0)+(item.icon?.length||0),0)<=8*1024*1024);
 assert.equal(JSON.stringify(result.items).includes(f.root),false);
});
