# Strix Desktop 0.3.14

Adiciona a área de otimização com leitura de memória, atalhos oficiais do Windows e sessão reversível de alto desempenho em PCs compatíveis e conectados à energia. O plano anterior é restaurado ao encerrar e recuperado na próxima abertura após uma interrupção. Uma mudança manual feita pelo usuário no Windows é preservada. Não altera registro, serviços, antivírus nem fecha outros aplicativos.
