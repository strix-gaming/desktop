# Strix 0.3.6

- O botão Tela cheia da transmissão destacada agora pode colocar a própria janela em fullscreen, sem barra de título.
- Permissão limitada às janelas de transmissão criadas pela Strix; não libera microfone, câmera ou captura em pop-ups.
- Controles e identificação desaparecem após inatividade, inclusive na janela destacada; mover o mouse os revela.
- Indicador de resolução recebido compacto, com dimensões completas na descrição.
