Strix 0.3.19

Nova identidade com o S da Strix no aplicativo, instalador e inicialização. Navegação contínua com preservação das telas, Home organizada em widgets e ajustes de fluidez, glass e chamadas.

Instalador Windows x64 de teste, ainda sem assinatura digital.
