# Strix Desktop 0.3.10

- Atualização em um clique: instala e reabre a Strix automaticamente, mantendo a conta e as preferências. Atualizações não reiniciam uma call ativa.
- Abertura com tela local imediata, sem esperar a primeira resposta da internet para mostrar a janela. Mantém a opção de iniciar com o Windows.
- A interface recebe uma notificação compacta com ação direta, acesso permanente às atualizações, prévia local de transmissão pausada em segundo plano e reorganização de canais.

Instalador Windows x64 sem assinatura Authenticode. A ordem dos aplicativos no logon é controlada pelo Windows.
