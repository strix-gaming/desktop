Strix Desktop 0.3.3 — versão de testes

- Corrige encerramento do aplicativo ao fechar o seletor de transmissão pelo X.
- Captura de áudio estéreo do computador no Windows 11, excluindo os processos da Strix para evitar retorno da call.
- Cancelar a seleção permite tentar novamente; o compartilhamento anterior é mantido ao desistir de trocar a janela.

Áudio usa WASAPI nativo, sem instalar drivers. A fonte é o som do computador, não apenas a janela selecionada. Precisa de teste em um PC Windows real com um segundo participante para validar áudio e desempenho. Instalador sem assinatura digital e sem atualização automática.

Atualizador integrado: procura versões no GitHub, baixa fora de chamadas e pede para reiniciar. A versão 0.3.2 precisa executar este instalador uma vez; conta e dados são preservados. Downloads diferenciais podem reduzir o tamanho das próximas atualizações quando suportados.
