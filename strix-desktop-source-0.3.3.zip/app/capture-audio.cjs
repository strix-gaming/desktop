const path=require('node:path'),fs=require('node:fs'),os=require('node:os');
const {spawn}=require('node:child_process');
const {randomUUID}=require('node:crypto');
const {trustedFrame}=require('./desktop-controls.cjs');
function installCaptureAudio({app,ipcMain},win,origin,deps={}){
 const launch=deps.spawn||spawn;
 const helper=app.isPackaged?path.join(process.resourcesPath,'strix-audio.exe'):path.join(__dirname,'..','native','bin','strix-audio.exe');
 const supported=deps.supported??(process.platform==='win32'&&Number(os.release().split('.')[2])>=20348&&fs.existsSync(helper));
 const sessions=new Map();let grant=0;
 const trusted=event=>!win.isDestroyed()&&trustedFrame(event,win.webContents,origin);
 const stop=id=>{const s=sessions.get(id);if(!s)return;sessions.delete(id);s.closed=true;clearTimeout(s.timeout);s.child.stdin.end();s.child.kill();s.reject?.(new Error('Captura de áudio cancelada.'));};
 const cleanup=()=>{grant=0;for(const id of sessions.keys())stop(id);};
 ipcMain.handle('strix:capture-audio-start',async event=>{
  if(!trusted(event)||!grant||Date.now()-grant>30000)throw Error('Selecione uma tela antes de capturar o som.');
  grant=0;if(!supported)throw Error('Áudio do computador requer Windows 11 e o instalador atualizado.');
  if(sessions.size>=2)throw Error('Encerre a transmissão anterior antes de iniciar outra.');
  const id=randomUUID(),child=launch(helper,['--exclude',String(process.pid)],{stdio:['pipe','pipe','pipe'],windowsHide:true});
  return await new Promise((resolve,reject)=>{
   const s={child,closed:false,ready:false,inflight:0,remainder:Buffer.alloc(0),reject,timeout:null};sessions.set(id,s);
   const failed=message=>{if(s.closed)return;const wasReady=s.ready;s.reject=null;stop(id);if(wasReady&&trusted(event))win.webContents.send('strix:capture-audio-ended',id);reject(Error(message));};
   s.timeout=setTimeout(()=>failed('O Windows não iniciou a captura de áudio.'),7000);
   let status='';child.stderr.on('data',chunk=>{status=(status+chunk.toString()).slice(-1024);if(!s.ready&&status.includes('READY 48000 2 16')){s.ready=true;s.reject=null;clearTimeout(s.timeout);resolve({id,sampleRate:48000,channels:2});}});
   child.stdout.on('data',chunk=>{
    if(s.closed||!s.ready||!trusted(event))return;
    const bytes=Buffer.concat([s.remainder,chunk]),length=bytes.length-bytes.length%4;s.remainder=bytes.subarray(length);
    // Bound renderer IPC backlog. Discard stale sound rather than accumulating delay.
    for(let offset=0;offset<length;offset+=7680){if(s.inflight>=8)break;const part=bytes.subarray(offset,Math.min(offset+7680,length));s.inflight++;win.webContents.send('strix:capture-audio-data',{id,pcm:part});}
   });
   child.on('error',()=>failed('Não foi possível iniciar o áudio do computador.'));
   child.on('exit',()=>failed('A captura de áudio do Windows foi encerrada.'));
  });
 });
 ipcMain.handle('strix:capture-audio-stop',(event,id)=>{if(trusted(event)&&typeof id==='string')stop(id);});
 const ack=(event,id)=>{if(trusted(event)){const s=sessions.get(id);if(s)s.inflight=Math.max(0,s.inflight-1);}};ipcMain.on('strix:capture-audio-ack',ack);
 win.webContents.on('did-start-navigation',(_e,_url,_inPlace,isMainFrame)=>{if(isMainFrame)cleanup();});
 win.webContents.on('render-process-gone',cleanup);
 win.on('closed',()=>{cleanup();ipcMain.removeHandler('strix:capture-audio-start');ipcMain.removeHandler('strix:capture-audio-stop');ipcMain.removeListener('strix:capture-audio-ack',ack);});
 return {grant({audio}){grant=audio?Date.now():0;},supported};
}
module.exports={installCaptureAudio};
