const {contextBridge, ipcRenderer} = require('electron');
// Never expose IPC itself, Electron objects, paths, or arbitrary channel names.
if (process.isMainFrame) {
  contextBridge.exposeInMainWorld('strixDesktop', Object.freeze({
    version: '0.3.3',
    updateStatus:()=>ipcRenderer.invoke('strix:updater','status'),
    checkUpdate:()=>ipcRenderer.invoke('strix:updater','check'),
    installUpdate:()=>ipcRenderer.invoke('strix:updater','install'),
    onUpdate(callback){const listener=(_event,value)=>callback(value);ipcRenderer.on('strix:update-state',listener);return()=>ipcRenderer.removeListener('strix:update-state',listener);},
    windowChrome:process.platform==='win32'?'overlay':undefined,
    cancelCapture:()=>ipcRenderer.invoke('strix:cancel-capture'),
    nativeCaptureAudio:process.platform==='win32',
    startCaptureAudio:()=>ipcRenderer.invoke('strix:capture-audio-start'),
    stopCaptureAudio:id=>ipcRenderer.invoke('strix:capture-audio-stop',id),
    onCaptureAudio(callback){
      const data=(_event,value)=>{try{callback(value);}finally{ipcRenderer.send('strix:capture-audio-ack',value.id);}};
      const ended=(_event,id)=>callback({id,ended:true});
      ipcRenderer.on('strix:capture-audio-data',data);ipcRenderer.on('strix:capture-audio-ended',ended);
      return()=>{ipcRenderer.removeListener('strix:capture-audio-data',data);ipcRenderer.removeListener('strix:capture-audio-ended',ended);};
    },
    reviewPermissions:()=>ipcRenderer.invoke('strix:review-permissions'),
    getStartup:()=>ipcRenderer.invoke('strix:startup'),
    setStartup:value=>typeof value==='boolean'?ipcRenderer.invoke('strix:startup',value):Promise.reject(new Error('Valor inválido')),
    updateCallState(value) {
      if (!value || typeof value !== 'object') return;
      ipcRenderer.send('strix:call-state', {
        connected:value.connected === true, mic:value.mic === true, deaf:value.deaf === true,
        canPublish:value.canPublish === true, busy:value.busy === true
      });
    },
    onCommand(callback) {
      if (typeof callback !== 'function') return () => {};
      const listener = (_event, command) => {
        if (['microphone','deafen','leave'].includes(command)) callback(command);
      };
      ipcRenderer.on('strix:call-command', listener);
      return () => ipcRenderer.removeListener('strix:call-command', listener);
    },
    onVisibility(callback) {
      if (typeof callback !== 'function') return () => {};
      const listener = (_event, visible) => callback(visible === true);
      ipcRenderer.on('strix:window-visible', listener);
      return () => ipcRenderer.removeListener('strix:window-visible', listener);
    }
  }));
}
