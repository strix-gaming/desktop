Correção da seleção e do áudio da transmissão no Windows.

- Fechar o seletor com X ou Cancelar encerra somente a seleção. É possível tentar novamente sem reiniciar a Strix.
- O aplicativo informa sua capacidade de áudio a partir do Windows e do módulo instalado; a tela mostra a versão em execução e orienta a atualização se houver incompatibilidade.
- Captura estéreo do computador com exclusão dos processos da Strix, para não retransmitir a própria chamada.
- Atualização pelo menu Configurações → Windows; quem usa 0.3.3 pode verificar e instalar fora da chamada. Instalador direto disponível abaixo.

Validação inclui testes automatizados de cancelamento e nova tentativa no Electron real, executados no Windows. A qualidade e o som entre computadores ainda dependem da validação com os dispositivos usados na chamada. Distribuição de teste sem assinatura de desenvolvedor.
