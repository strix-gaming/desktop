const fs=require('node:fs');
const path=require('node:path');
const {trustedFrame}=require('./desktop-controls.cjs');
function installPermissions({app,dialog,ipcMain,systemPreferences},win,origin,platform=process.platform){
 const filename=path.join(app.getPath('userData'),'permissions.json');
 let grants={},pending;
 try{const saved=JSON.parse(fs.readFileSync(filename,'utf8'));if(saved.origin===origin)grants=saved.grants||{};}catch{}
 const persist=()=>{try{fs.mkdirSync(path.dirname(filename),{recursive:true});fs.writeFileSync(filename+'.tmp',JSON.stringify({origin,grants}));fs.renameSync(filename+'.tmp',filename);}catch{/* Keep the choice for this session even when disk is full. */}};
 const isOrigin=url=>{try{return new URL(url).origin===origin;}catch{return false;}};
 const trusted=(wc,url,details={})=>wc===win.webContents&&details.isMainFrame!==false&&isOrigin(url)&&isOrigin(wc.getURL());
 async function prepare(force=false){
  if(pending)return pending;
  if(!force&&typeof grants.media==='boolean')return grants.media;
  pending=(async()=>{const {response}=await dialog.showMessageBox(win,{type:'question',title:'Prepare sua Strix',message:'Usar microfone e câmera nas chamadas?',detail:'Sua escolha fica salva neste aplicativo. A Strix só liga o microfone ao entrar em uma chamada; a câmera continua desligada até você ativá-la. Você pode revisar isso em Áudio → Permissões.',buttons:['Agora não','Permitir'],defaultId:1,cancelId:0});grants.media=response===1;persist();return grants.media;})();
  try{return await pending;}finally{pending=undefined;}
 }
 const ses=win.webContents.session;
 ses.setPermissionCheckHandler((wc,permission,url,details={})=>{
  if(!trusted(wc,url,details))return false;
  if(permission==='fullscreen'||permission==='display-capture')return true;
  return ['media','notifications'].includes(permission)&&grants[permission]===true;
 });
 ses.setPermissionRequestHandler((wc,permission,callback,details={})=>{
  void (async()=>{
   if(!trusted(wc,details.requestingUrl||wc?.getURL(),details))return false;
   // The capture handler still requires a gesture and explicit source selection.
   if(permission==='fullscreen'||permission==='display-capture')return true;
   if(permission==='media'){
    if(!await prepare())return false;
    if(platform==='darwin')for(const type of details.mediaTypes||[])if(['audio','video'].includes(type)&&!await systemPreferences.askForMediaAccess(type==='audio'?'microphone':'camera'))return false;
    return true;
   }
   if(permission==='notifications'){
    if(typeof grants.notifications!=='boolean'){const {response}=await dialog.showMessageBox(win,{type:'question',title:'Notificações Strix',message:'Receber notificações da Strix?',buttons:['Agora não','Permitir'],defaultId:1,cancelId:0});grants.notifications=response===1;persist();}
    return grants.notifications;
   }
   return false;
  })().then(value=>callback(value),()=>callback(false));
 });
 const review=async()=>{await prepare(true);};
 ipcMain.handle('strix:review-permissions',async event=>{if(!trustedFrame(event,win.webContents,origin))throw Error('Origem não autorizada');await review();});
 win.on('closed',()=>ipcMain.removeHandler('strix:review-permissions'));
 return {prepare,review};
}
module.exports={installPermissions};
