$ErrorActionPreference = 'Stop'
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$vs = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (!$vs) { throw 'Visual C++ build tools missing' }
New-Item -ItemType Directory -Force native/bin | Out-Null
$dev = Join-Path $vs 'Common7\Tools\VsDevCmd.bat'
cmd /c "`"$dev`" -arch=x64 && cl /nologo /std:c++17 /EHsc /O2 /MT /DWIN32_LEAN_AND_MEAN native\strix-audio.cpp /Fo:native\bin\strix-audio.obj /Fe:native\bin\strix-audio.exe /link Mmdevapi.lib Ole32.lib Avrt.lib"
if ($LASTEXITCODE -ne 0) { throw 'Native audio compilation failed' }
