// Real Electron/Chromium test. HTTPS pages are local protocol fixtures; no provider,
// microphone or system-audio capture. The oscillator is never started or resumed.
const {app,BrowserWindow,session}=require('electron');
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {prepareGameAudioExtension,installGameAudioExtension}=require('../app/game-audio.cjs');
const {approvedGameURLs}=require('../app/game-permissions.cjs');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'strix-game-audio-'));app.setPath('userData',path.join(temp,'profile'));
// Keep Electron alive while the fixture deliberately replaces its last window.
app.on('window-all-closed',()=>{});
const origin='https://strix-gaming.web.app',approved=approvedGameURLs[1],foreign=approved.replace('index.html','not-in-catalogue.html');
let owner,detached;const deadline=setTimeout(()=>{console.error('Game audio integration timed out');app.exit(1);},40000);
const near=(actual,expected,message)=>assert.ok(Math.abs(actual-expected)<1e-6,message||`${actual} differs from ${expected}`);
const probe=`(() => {
 const nativeGain=BaseAudioContext.prototype.createGain;
 window.qaGains=[];
 BaseAudioContext.prototype.createGain=function(...args){const gain=nativeGain.apply(this,args);qaGains.push(gain);return gain;};
 const volume=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'volume');
 window.qaActualVolume=media=>volume.get.call(media);
})();`;
const inline=`window.qaContext=new AudioContext();window.qaOscillator=qaContext.createOscillator();qaOscillator.connect(qaContext.destination);window.qaAudio=new Audio();window.qaVideo=document.createElement('video');window.qaInitial={gains:window.qaGains?.map(g=>g.gain.value)||[],audio:window.qaActualVolume?qaActualVolume(qaAudio):qaAudio.volume,video:window.qaActualVolume?qaActualVolume(qaVideo):qaVideo.volume,node:typeof require};`;
app.whenReady().then(async()=>{
 const directory=path.join(temp,'extension');prepareGameAudioExtension(directory,origin);
 // Observe native gain nodes before the production script runs, without changing
 // output or graph behavior. This proves the FIRST inline game script sees .15.
 fs.writeFileSync(path.join(directory,'qa-probe.js'),probe);
 const manifest=JSON.parse(fs.readFileSync(path.join(directory,'manifest.json'),'utf8'));
 manifest.content_scripts[0].js.unshift('qa-probe.js');fs.writeFileSync(path.join(directory,'manifest.json'),JSON.stringify(manifest));
 const ses=session.fromPartition('persist:strix-game-audio-'+Date.now());
 const serve=request=>new Response(request.url.startsWith(origin+'/')?
  `<html><body><div id="wrapper"></div><script>${inline}</script></body></html>`:
  `<html><body><script>${inline}</script></body></html>`,{headers:{'content-type':'text/html'}});
 await ses.protocol.handle('https',serve);
 assert.equal(await installGameAudioExtension(ses,directory),true);
 owner=new BrowserWindow({show:false,webPreferences:{session:ses,sandbox:true,contextIsolation:true,nodeIntegration:false,nodeIntegrationInSubFrames:false}});
 await owner.loadURL(origin+'/app');
 assert.equal(await owner.webContents.executeJavaScript('qaInitial.audio'),1,'call page HTML audio stays 100%');
 assert.deepEqual(await owner.webContents.executeJavaScript('qaInitial.gains'),[],'call graph has no injected master');
 const loadFrame=async(url,window=owner)=>{
  await window.webContents.executeJavaScript(`new Promise(resolve=>{document.querySelector('iframe')?.remove();const frame=document.createElement('iframe');frame.src=${JSON.stringify(url)};frame.sandbox='allow-scripts allow-same-origin';frame.onload=resolve;document.getElementById('wrapper').append(frame);})`);
  return window.webContents.mainFrame.frames[0];
 };
 let frame=await loadFrame(approved),initial=await frame.executeJavaScript('qaInitial');
 assert.equal(initial.gains.length,1);near(initial.gains[0],.15,'first inline game connection already goes through 15% master');
 assert.equal(initial.audio,.15,'first new Audio is attenuated');assert.equal(initial.video,.15,'first DOM media is attenuated');assert.equal(initial.node,'undefined');
 async function command(value,window=owner){return window.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const frame=document.querySelector('iframe'),timer=setTimeout(()=>{window.removeEventListener('message',receive);reject(Error('No native game audio acknowledgement'));},1500);function receive(event){if(event.source===frame.contentWindow&&event.origin===${JSON.stringify(new URL(approved).origin)}&&event.data?.type==='strix-game-audio:ready'&&event.data.version===1&&(${JSON.stringify(value.type)}!=='strix-game-audio:set'||(event.data.volume===${JSON.stringify(value.volume)}&&event.data.muted===${JSON.stringify(value.muted)}))){clearTimeout(timer);window.removeEventListener('message',receive);resolve(event.data);}}window.addEventListener('message',receive);frame.contentWindow.postMessage(${JSON.stringify(value)},${JSON.stringify(new URL(approved).origin)});})`);}
 assert.equal((await command({type:'strix-game-audio:get'})).volume,.15);
 await command({type:'strix-game-audio:set',volume:.4,muted:false});
 near(await frame.executeJavaScript('qaGains[0].gain.value'),.4);
 assert.equal(await frame.executeJavaScript('qaActualVolume(qaAudio)'),.4);
 await frame.executeJavaScript(`window.dispatchEvent(new MessageEvent('message',{data:{type:'strix-game-audio:set',volume:1,muted:false},origin:${JSON.stringify(origin)},source:window.parent}));`);
 near(await frame.executeJavaScript('qaGains[0].gain.value'),.4,'game cannot impersonate its parent');
 await command({type:'strix-game-audio:set',volume:.4,muted:true});assert.equal(await frame.executeJavaScript('qaGains[0].gain.value'),0);
 await command({type:'strix-game-audio:set',volume:.4,muted:false});near(await frame.executeJavaScript('qaGains[0].gain.value'),.4);
 assert.equal(await owner.webContents.executeJavaScript('qaAudio.volume'),1,'volume changes never touch the call');
 frame=await loadFrame(foreign);initial=await frame.executeJavaScript('qaInitial');assert.equal(initial.audio,1);assert.deepEqual(initial.gains,[]);
 // Also prove the exact shipped extension source, without a preceding probe,
 // injects into a sandboxed cross-origin subframe with Node entirely disabled.
 const shippedDirectory=path.resolve(__dirname,'../app/game-audio-extension');
 owner.destroy();
 const shippedSession=session.fromPartition('persist:strix-game-audio-shipped-'+Date.now());
 await shippedSession.protocol.handle('https',serve);
 assert.equal(await installGameAudioExtension(shippedSession,shippedDirectory),true);
 owner=new BrowserWindow({show:false,webPreferences:{session:shippedSession,sandbox:true,contextIsolation:true,nodeIntegration:false,nodeIntegrationInSubFrames:false}});
 await owner.loadURL(origin+'/app');await loadFrame(approved);
 assert.equal((await command({type:'strix-game-audio:get'})).volume,.15,'unmodified shipped script acknowledges native control');
 assert.equal((await command({type:'strix-game-audio:set',volume:.4,muted:false})).volume,.4);
 detached=new BrowserWindow({show:false,webPreferences:{session:shippedSession,sandbox:true,contextIsolation:true,nodeIntegration:false,nodeIntegrationInSubFrames:false}});
 await detached.loadURL(origin+'/stream-window.html');await loadFrame(approved,detached);
 assert.equal((await command({type:'strix-game-audio:get'},detached)).volume,.15,'detached game starts at 15% in the same session');
 assert.equal((await command({type:'strix-game-audio:set',volume:.2,muted:false},detached)).volume,.2);
 assert.equal((await command({type:'strix-game-audio:get'})).volume,.4,'detached volume does not change main game volume');
 assert.equal(await detached.webContents.executeJavaScript('qaAudio.volume'),1,'detached Strix document audio is untouched');
 detached.destroy();detached=null;
 console.log('PASS: document_start MAIN injection in cross-origin sandboxed frame; first native WebAudio gain and HTMLMedia .15; adjustable .4; mute; Strix and unapproved frames unchanged; Node unavailable; detached game has independent volume.');
 fs.writeFileSync(path.resolve(__dirname,'../game-audio-validation.json'),JSON.stringify({passed:true,firstInlineGain:.15,updatedGain:.4,muting:true,shippedExtension:true,detachedIsolation:true,callUntouched:true}));
 owner.destroy();clearTimeout(deadline);app.exit(0);
}).catch(error=>{console.error(error);detached?.destroy();owner?.destroy();clearTimeout(deadline);app.exit(1);});
