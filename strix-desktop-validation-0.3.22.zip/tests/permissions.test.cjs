const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{EventEmitter}=require('node:events');const {installPermissions}=require('../app/permissions.cjs');
function setup(dir,response=1){let checks,requests,review,calls=0;const frame={url:'https://strix-gaming.web.app/app'},wc={mainFrame:frame,getURL:()=>frame.url,isDestroyed:()=>false,session:{setPermissionCheckHandler:f=>checks=f,setPermissionRequestHandler:f=>requests=f}},win=new EventEmitter();win.webContents=wc;const api=installPermissions({app:{getPath:()=>dir},dialog:{showMessageBox:async()=>{calls++;return {response};}},ipcMain:{handle:(name,fn)=>review=fn,removeHandler(){}},systemPreferences:{}},win,'https://strix-gaming.web.app','win32');return {api,wc,frame,checkWindow:(other,p,url,details={})=>checks(other,p,url,details),requestWindow:(other,p,details={})=>new Promise(resolve=>requests(other,p,resolve,details)),get calls(){return calls;},check:(permission,url=frame.url,details={})=>checks(wc,permission,url,details),request:(permission,details={})=>new Promise(resolve=>requests(wc,permission,resolve,{requestingUrl:frame.url,...details})),review:()=>review({sender:wc,senderFrame:frame})};}
test('media is asked once, concurrent calls reuse the choice, and consent survives restart',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-consent-'));try{const h=setup(dir);assert.equal(h.check('media'),false);await Promise.all([h.api.prepare(),h.request('media'),h.request('media')]);assert.equal(h.calls,1);assert.equal(h.check('media'),true);await h.request('media',{mediaTypes:['audio']});assert.equal(h.calls,1);const restarted=setup(dir);await restarted.api.prepare();assert.equal(restarted.calls,0);assert.equal(restarted.check('media'),true);}finally{fs.rmSync(dir,{recursive:true});}});
test('denials persist, cannot leak to subframes or other origins, and review can revoke consent',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-consent-'));try{const allowed=setup(dir);await allowed.api.prepare();assert.equal(allowed.check('media','https://evil.test'),false);assert.equal(allowed.check('media',allowed.frame.url,{isMainFrame:false}),false);assert.equal(await allowed.request('media',{isMainFrame:false}),false);assert.equal(await allowed.request('geolocation'),false);const denied=setup(dir,0);await denied.review();assert.equal(denied.check('media'),false);assert.equal(await denied.request('media'),false);assert.equal(denied.calls,1);assert.equal(denied.check('display-capture'),true);assert.equal(denied.check('display-capture','https://evil.test'),false);}finally{fs.rmSync(dir,{recursive:true});}});

test('only registered stream windows may enter fullscreen; other privileges and navigated windows stay denied',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-popout-'));try{const h=setup(dir),child=new EventEmitter();let url='https://strix-gaming.web.app/stream-window.html';const wc={getURL:()=>url};child.webContents=wc;assert.equal(h.checkWindow(wc,'fullscreen',url),false);h.api.allowStreamWindow(child,url);assert.equal(h.checkWindow(wc,'fullscreen',url),true);assert.equal(h.checkWindow(wc,'fullscreen','https://strix-gaming.web.app'),true);assert.equal(await h.requestWindow(wc,'fullscreen',{requestingUrl:url}),true);for(const p of ['media','display-capture','notifications','geolocation','speaker-selection']){assert.equal(h.checkWindow(wc,p,url),false);assert.equal(await h.requestWindow(wc,p,{requestingUrl:url}),false);}assert.equal(h.checkWindow(wc,'fullscreen',url,{isMainFrame:false}),false);assert.equal(await h.requestWindow(wc,'fullscreen',{requestingUrl:url,isMainFrame:false}),false);url='https://strix-gaming.web.app/app';assert.equal(h.checkWindow(wc,'fullscreen',url),false);url='https://evil.test/stream-window.html';assert.equal(await h.requestWindow(wc,'fullscreen',{requestingUrl:url}),false);url='https://strix-gaming.web.app/stream-window.html';child.emit('closed');assert.equal(h.checkWindow(wc,'fullscreen',url),false);assert.equal(h.calls,0);}finally{fs.rmSync(dir,{recursive:true});}});

test('speaker selection requires existing media consent and remains scoped to trusted main frame',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-output-'));try{const h=setup(dir);assert.equal(h.check('speaker-selection'),false);assert.equal(await h.request('speaker-selection'),false);assert.equal(h.calls,0);await h.api.prepare();assert.equal(h.check('speaker-selection'),true);assert.equal(await h.request('speaker-selection'),true);assert.equal(h.calls,1);assert.equal(h.check('speaker-selection','https://evil.test'),false);assert.equal(await h.request('speaker-selection',{requestingUrl:'https://evil.test'}),false);assert.equal(h.check('speaker-selection',h.frame.url,{isMainFrame:false}),false);assert.equal(await h.request('speaker-selection',{isMainFrame:false}),false);const denied=setup(dir,0);await denied.review();assert.equal(denied.check('speaker-selection'),false);assert.equal(await denied.request('speaker-selection'),false);assert.equal(denied.calls,1);}finally{fs.rmSync(dir,{recursive:true});}});

const {approvedGameURLs,supplementalGamePermissionURLs,isApprovedGameURL}=require('../app/game-permissions.cjs');
test('game controls are restricted to exact catalogue documents in known subframes',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-games-'));try{
  const h=setup(dir);
  for(const url of [...approvedGameURLs,...supplementalGamePermissionURLs]){const details={isMainFrame:false,requestingUrl:url};assert.equal(h.check('pointerLock',new URL(url).origin,details),true);assert.equal(await h.request('pointerLock',details),true);assert.equal(await h.request('fullscreen',details),true);assert.equal(isApprovedGameURL(url+'#play'),true);}
  const url=approvedGameURLs[0],details={isMainFrame:false,requestingUrl:url};
  for(const permission of ['media','display-capture','notifications','speaker-selection','clipboard-read','clipboard-sanitized-write','keyboardLock','automatic-fullscreen','fileSystem','geolocation','openExternal']){assert.equal(h.check(permission,new URL(url).origin,details),false,permission);assert.equal(await h.request(permission,details),false,permission);}
  for(const bad of [url+'?redirect=https://evil.test',url.replace('https:','http:'),url.replace('www.onlinegames.io','www.onlinegames.io.evil.test'),url.replace('www.onlinegames.io','evil@www.onlinegames.io'),url.replace('index.html','other.html'),'https://www.onlinegames.io/',null]){assert.equal(isApprovedGameURL(bad),false);assert.equal(await h.request('pointerLock',{...details,requestingUrl:bad}),false);}
  for(const bad of [{requestingUrl:url},{isMainFrame:true,requestingUrl:url},{isMainFrame:false}])assert.equal(await h.request('pointerLock',bad),false);
  assert.equal(h.check('pointerLock','https://evil.test',details),false);
  const foreign={getURL:()=>h.frame.url};assert.equal(h.checkWindow(foreign,'pointerLock',new URL(url).origin,details),false);
  h.frame.url='https://accounts.google.com/';assert.equal(await h.request('pointerLock',details),false);
  assert.equal(h.calls,0,'games must not display or inherit media consent');
 }finally{fs.rmSync(dir,{recursive:true});}
});
test('registered popouts permit only game controls and revoke access after navigation or close',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-games-'));try{
  const h=setup(dir),child=new EventEmitter();let childURL='https://strix-gaming.web.app/stream-window.html',destroyed=false;
  const wc={getURL:()=>childURL,isDestroyed:()=>destroyed};child.webContents=wc;const game=approvedGameURLs[1],details={isMainFrame:false,requestingUrl:game};
  assert.equal(await h.requestWindow(wc,'pointerLock',details),false);h.api.allowStreamWindow(child,childURL);
  assert.equal(await h.requestWindow(wc,'pointerLock',details),true);assert.equal(await h.requestWindow(wc,'fullscreen',details),true);
  assert.equal(await h.requestWindow(wc,'media',details),false);assert.equal(await h.requestWindow(wc,'pointerLock',{isMainFrame:true,requestingUrl:childURL}),false);
  childURL='https://strix-gaming.web.app/app';assert.equal(await h.requestWindow(wc,'pointerLock',details),false);
  childURL='https://evil.test/stream-window.html';assert.equal(await h.requestWindow(wc,'pointerLock',details),false);
  childURL='https://strix-gaming.web.app/stream-window.html';destroyed=true;assert.equal(await h.requestWindow(wc,'pointerLock',details),false);
  destroyed=false;child.emit('closed');assert.equal(await h.requestWindow(wc,'pointerLock',details),false);
 }finally{fs.rmSync(dir,{recursive:true});}
});

test('supplemental provider grants stay document-scoped and never include game audio or media privileges',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'strix-supplemental-games-'));try{
  const h=setup(dir);
  for(const url of supplementalGamePermissionURLs){
   assert.equal(approvedGameURLs.includes(url),false);
   assert.equal(await h.request('pointerLock',{isMainFrame:false,requestingUrl:url}),true);
   for(const permission of ['media','display-capture','clipboard-read','keyboardLock','automatic-fullscreen'])assert.equal(await h.request(permission,{isMainFrame:false,requestingUrl:url}),false);
   for(const bad of [url+'other/',url+'?game=other',url.replace('https:','http:')])assert.equal(isApprovedGameURL(bad),false);
  }
 }finally{fs.rmSync(dir,{recursive:true});}
});
