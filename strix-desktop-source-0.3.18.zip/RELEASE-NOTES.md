Strix Desktop 0.3.18

Convites diretos pela lista de amigos, sem exigir servidor. Ao aceitar um convite com link de lobby Steam, a Strix solicita a entrada nesse grupo. O jogo controla acesso, vagas e validade do lobby; a Strix não detecta automaticamente o lobby de todos os jogos. Tags menores e controles de transmissão mais legíveis na interface web.

Instalador de teste sem assinatura. CI Windows validado; sem prova física de entrada em um lobby real.
