# Strix Desktop 0.3.13

- A biblioteca publica somente o identificador público Steam e uma URL oficial de capa, sem caminhos de instalação. A interface pode recuperar a arte de qualquer jogo Steam detectado, mesmo quando o limite de imagens incorporadas do IPC foi atingido.
- A detecção lê capas locais e o cache já existente, sem esperar downloads externos. Falhas de rede de um título não bloqueiam a descoberta nem a recuperação dos demais.
- A interface web atualizada valida a imagem, tenta capas verticais antes de imagens horizontais, permite repetir falhas na atualização manual e exibe os jogos com capas válidas primeiro.

Compatibilidade: a interface mantém o contrato do instalador 0.3.12; a recuperação ampla por Steam appID requer 0.3.13. Não inclui novas fontes de detecção de jogos fora do Steam. Testes locais não substituem a validação do instalador em um Windows físico.
